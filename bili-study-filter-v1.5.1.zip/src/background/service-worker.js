/* B站学习净化器 · 后台：角标与安装引导 */
'use strict';

chrome.runtime.onInstalled.addListener(function (details) {
  try {
    chrome.action.setBadgeBackgroundColor({ color: '#00aeec' });
  } catch (e) { /* ignore */ }
  if (details.reason === 'install') {
    try { chrome.runtime.openOptionsPage(); } catch (e) { /* ignore */ }
  }
});

chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  if (!msg || msg.type !== 'blf:badge') return;
  const tabId = sender && sender.tab && sender.tab.id;
  if (typeof tabId !== 'number') return;
  const count = Math.max(0, Number(msg.count) || 0);
  try {
    chrome.action.setBadgeText({ tabId: tabId, text: count > 0 ? (count > 99 ? '99+' : String(count)) : '' });
    chrome.action.setBadgeBackgroundColor({ tabId: tabId, color: count > 0 ? '#00aeec' : '#3dd68c' });
  } catch (e) { /* ignore */ }
});

if (chrome.tabs && chrome.tabs.onUpdated) {
  chrome.tabs.onUpdated.addListener(function (tabId, info) {
    if (info.status === 'loading') {
      try { chrome.action.setBadgeText({ tabId: tabId, text: '' }); } catch (e) { /* ignore */ }
    }
  });
}

chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  if (msg && msg.type === 'blf:open-options') {
    try { chrome.runtime.openOptionsPage(); } catch (e) { /* ignore */ }
    if (sendResponse) sendResponse({ ok: true });
  }
});
