/* B站学习净化器 · MAIN world 桥：以页面身份请求 B 站搜索接口（带 Cookie / Origin） */
(function () {
  'use strict';
  if (window.__BLF_BRIDGE_READY__) return;
  window.__BLF_BRIDGE_READY__ = true;

  const ALLOWED_HOST = 'api.bilibili.com';
  const ALLOWED_PATHS = new Set([
    '/x/web-interface/search/type',
    '/x/web-interface/nav',
    '/x/relation/followings',
    '/x/relation/tags',
    '/x/v3/fav/folder/created/list-all',
    '/x/v3/fav/resource/list',
    '/x/web-interface/history/cursor'
  ]);

  function reply(id, payload) {
    window.postMessage(Object.assign({ __blf: 'res', id: id }, payload), '*');
  }

  window.addEventListener('message', async function (event) {
    if (event.source !== window) return;
    const data = event.data;
    if (!data || data.__blf !== 'req' || (data.type !== 'search' && data.type !== 'api') || !data.id || !data.url) return;

    let url;
    try {
      url = new URL(String(data.url));
    } catch (e) {
      reply(data.id, { ok: false, code: 'bad-url', message: 'URL 无效' });
      return;
    }
    if (url.protocol !== 'https:' || url.hostname !== ALLOWED_HOST || !ALLOWED_PATHS.has(url.pathname)) {
      reply(data.id, { ok: false, code: 'forbidden', message: '仅允许访问白名单内的 B 站接口' });
      return;
    }

    try {
      const res = await fetch(url.href, {
        method: 'GET',
        credentials: 'include',
        cache: 'no-store',
        headers: { Accept: 'application/json, text/plain, */*' }
      });
      const text = await res.text();
      let json = null;
      try { json = JSON.parse(text); } catch (e) { json = null; }
      if (!json) {
        reply(data.id, {
          ok: false,
          httpStatus: res.status,
          code: res.status === 412 ? -412 : 'non-json',
          message: res.status === 412 ? 'B 站风控拦截' : '返回内容不是 JSON'
        });
        return;
      }
      reply(data.id, {
        ok: res.ok && json.code === 0,
        httpStatus: res.status,
        code: json.code,
        message: json.message || '',
        data: json.code === 0 ? json.data : null
      });
    } catch (err) {
      reply(data.id, {
        ok: false,
        code: 'network',
        message: (err && err.message) || '网络请求失败'
      });
    }
  });
})();
