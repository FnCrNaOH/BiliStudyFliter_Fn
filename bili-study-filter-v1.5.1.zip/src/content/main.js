/* B站学习净化器 · 内容脚本：识别视频卡片、应用干预、聚合同题、驱动面板 */
(function (root) {
  'use strict';
  const BLF = (root.BLF = root.BLF || {});
  const U = BLF.U;
  const S = {
    settings: null,
    profile: null,
    diversity: null,
    mutedDomains: new Set(),
    mutedTopics: new Set(),
    items: new Map(),
    records: new Map(),
    clusters: { groups: [], byId: Object.create(null) },
    stats: { scanned: 0, flagged: 0, clusters: 0, revealed: 0, hidden: 0 },
    daily: null,
    paused: false,
    started: false,
    context: 'other',
    baseTopic: '',
    pageTopic: '',
    mainBvid: '',
    lastSize: 0,
    lastHref: '',
    lastSettingsJson: '',
    lastBadgeCount: -1,
    pageRevealed: 0,
    scanTimer: null,
    clusterTimer: null,
    saveTimer: null,
    statTimer: null,
    badgeTimer: null,
    urlTimer: null,
    observer: null,
    shelves: [],
    shelvesSuppressed: false,
    applying: false,
    cardCountCache: new WeakMap(),
    studyPool: null,
    studyPoolLoading: false,
    studyPoolError: '',
    studyPoolProgress: '',
    studyHero: null,
    studyHeroSig: '',
    heroCursor: 0,
    fillAssigned: new Map(),
    studyTimer: null,
    emptyShelfTimer: null,
    homeRemoved: new Set()
  };

  const CONTEXT_LABEL = {
    feed: '首页推荐',
    recommend: '相关推荐',
    search: '搜索结果',
    popular: '热门',
    space: 'UP 空间',
    vertical: '竖屏专区',
    other: 'B站'
  };

  const CLUSTER_CONTEXTS = { feed: true, recommend: true, space: true };

  function isTarget() {
    return /(^|\.)bilibili\.com$/i.test(location.hostname) || !!root.__BLF_DEMO__;
  }

  function detectContext() {
    if (root.__BLF_DEMO__) return root.__BLF_DEMO_CONTEXT__ || 'feed';
    if (location.hostname === 'search.bilibili.com') return 'search';
    const p = location.pathname;
    if (p.indexOf('/search') === 0) return 'search';
    if (p.indexOf('/video/') === 0) return 'recommend';
    if (p.indexOf('/v/vertical') === 0) return 'vertical';
    if (p.indexOf('/v/popular') === 0) return 'popular';
    if (p.indexOf('/space') === 0) return 'space';
    if (p === '/' || p.indexOf('/index') === 0) return 'feed';
    return 'other';
  }

  function detectTopic() {
    if (root.__BLF_DEMO__) return root.__BLF_DEMO_TOPIC__ || '信息论';
    try {
      if (location.hostname === 'search.bilibili.com' || location.pathname.indexOf('/search') === 0) {
        const kw = new URLSearchParams(location.search).get('keyword') || '';
        return BLF.Topic.fromSearchQuery(kw);
      }
      if (location.pathname.indexOf('/video/') === 0) {
        const h1 = document.querySelector('h1.video-title, h1[title], .video-title');
        let raw = '';
        if (h1) raw = h1.getAttribute('title') || h1.textContent || '';
        if (!raw) {
          raw = document.title.replace(/[_\-|]\s*哔哩哔哩.*$/i, '').trim();
        }
        return BLF.Topic.fromTitle(raw);
      }
    } catch (e) { /* ignore */ }
    return '';
  }

  function mainBvid() {
    const m = location.pathname.match(/\/video\/(BV[0-9A-Za-z]+|av\d+)/i);
    return m ? m[1] : '';
  }

  function parseBvid(href) {
    const m = String(href || '').match(/\/video\/(BV[0-9A-Za-z]+|av\d+)/i);
    return m ? m[1] : '';
  }

  function clearCache() {
    S.cardCountCache = new WeakMap();
  }

  function distinctBvids(el) {
    if (!el) return 0;
    if (S.cardCountCache.has(el)) return S.cardCountCache.get(el);
    const set = new Set();
    const anchors = el.querySelectorAll('a[href*="/video/"]');
    for (let i = 0; i < anchors.length; i++) {
      if (anchors[i].closest('[data-blf-fill], .blf-study-hero')) continue;
      const b = parseBvid(anchors[i].getAttribute('href'));
      if (b) {
        set.add(b);
        if (set.size > 1) break;
      }
    }
    S.cardCountCache.set(el, set.size);
    return set.size;
  }

  function ignoredAnchor(a) {
    if (!a || !a.closest) return true;
    if (a.closest('#bilibili-player, .bpx-player-container, #playerWrap, .video-player, .danmaku-wrap, .bpx-player-dm-wrap, #comment, .comments, .reply-list, .bili-comments, .bili-footer, .international-footer, .bili-header, .mini-header, .nav-wrapper, .search-input, .bili-header__bar, [class*="search-suggest"], [class*="suggest-panel"], [class*="search-panel"]')) {
      return true;
    }
    if (a.closest('[data-blf-badge]')) return true;
    if (a.closest('[data-blf-fill], .blf-study-hero')) return true;
    return false;
  }

  function anchorScore(a) {
    let score = 0;
    const text = U.cleanText(a.textContent || '');
    if (text.length > 4) score += 10;
    if (text.length > 10) score += 5;
    if (a.getAttribute('title')) score += 12;
    if (a.closest('h3, [class*="info--tit"], [class*="video-title"], [class*="title"]')) score += 15;
    if (a.closest('[class*="author"], [class*="owner"], [class*="up-name"], [class*="upinfo"]')) score -= 40;
    if (a.querySelector('img')) score -= 12;
    if (a.querySelector('.bili-video-card__stats__duration, [class*="duration"]')) score -= 10;
    const r = a.getBoundingClientRect();
    if (r.width > 140) score += 3;
    return score;
  }

  function findCard(anchor, bvid) {
    const preferred = anchor.closest('.bili-video-card, .video-page-card-small, .video-page-card, .video-card, .video-list-item, .feed-card, article');
    if (preferred && preferred.tagName !== 'A' && distinctBvids(preferred) <= 1) return preferred;

    let el = anchor;
    for (let depth = 0; el && el.parentElement && el.parentElement !== document.body && depth < 9; depth++) {
      const parent = el.parentElement;
      if (distinctBvids(parent) > 1) break;
      el = parent;
      const cls = String(el.className || '');
      if (el.tagName === 'ARTICLE' || el.tagName === 'LI' || /(^|\s)(bili-video-card|feed-card|video-card|video-list-item)(\s|$)/.test(cls)) break;
    }
    if (el.tagName === 'A' && el.parentElement) el = el.parentElement;
    if (!el || el === document.body || el === document.documentElement) return null;
    if (distinctBvids(el) > 1) return null;
    return el;
  }

  function pickTitle(card, anchor, bvid) {
    let best = '';
    const sels = ['.bili-video-card__info--tit', '[class*="info--tit"]', '[class*="video-title"]', '[class*="title"]'];
    for (let i = 0; i < sels.length; i++) {
      const el = card.querySelector(sels[i]);
      if (!el) continue;
      if (el.closest('[class*="author"], [class*="owner"]')) continue;
      const t = U.cleanText(el.getAttribute('title') || el.textContent || '');
      if (t.length > best.length) best = t;
    }
    if (!best) {
      const anchors = card.querySelectorAll('a[href*="/video/"]');
      for (let i = 0; i < anchors.length; i++) {
        const a = anchors[i];
        if (parseBvid(a.getAttribute('href')) !== bvid) continue;
        const t = U.cleanText(a.getAttribute('title') || a.textContent || '');
        if (t.length > best.length && t.length < 160) best = t;
      }
    }
    if (!best) {
      const img = card.querySelector('img[alt]');
      if (img && img.alt && img.alt.length > 2) best = U.cleanText(img.alt);
    }
    if (!best) best = U.cleanText(anchor.getAttribute('title') || anchor.textContent || '');
    best = best.replace(/^广告\s*[·|]?\s*/, '').replace(/\s+/g, ' ').trim();
    return best.slice(0, 160);
  }

  function pickAuthor(card) {
    const a = card.querySelector('a[href*="/space.bilibili.com/"]');
    let mid = 0;
    if (a) {
      const m = (a.getAttribute('href') || '').match(/space\.bilibili\.com\/(\d+)/);
      if (m) mid = Number(m[1]) || 0;
    }
    let name = '';
    const nameEl = card.querySelector('.bili-video-card__info--author, [class*="info--author"], [class*="up-name"], [class*="author"]');
    if (nameEl) name = U.cleanText(nameEl.getAttribute('title') || nameEl.textContent || '');
    if (!name && a) name = U.cleanText(a.textContent || '');
    name = name.replace(/^UP主\s*[:：]?\s*/, '').replace(/\s+/g, ' ').trim().slice(0, 50);
    return { author: name, mid: mid };
  }

  function pickDuration(card) {
    const sels = ['.bili-video-card__stats__duration', '[class*="stats__duration"]', '[class*="duration"]', '[class*="Duration"]', '.so-imgTag_rb', '.length', '[class*="video-time"]'];
    for (let i = 0; i < sels.length; i++) {
      const el = card.querySelector(sels[i]);
      if (!el) continue;
      const text = U.cleanText(el.textContent || '');
      const m = text.match(/\d{1,3}:\d{1,2}(?::\d{1,2})?/);
      if (m) return U.parseDuration(m[0]);
    }
    const text = U.cleanText(card.textContent || '');
    const matches = text.match(/(?:^|\s)(\d{1,3}:\d{1,2}(?::\d{1,2})?)(?=\s|$)/g);
    if (matches && matches.length) {
      const last = matches[matches.length - 1].trim();
      return U.parseDuration(last);
    }
    return 0;
  }

  function pickStats(card) {
    let views = 0;
    let danmaku = 0;
    let likes = 0;
    const texts = card.querySelectorAll('.bili-video-card__stats--text');
    if (texts.length >= 1) {
      views = U.parseCount(texts[0].textContent);
      if (texts.length >= 2) danmaku = U.parseCount(texts[1].textContent);
    }
    const iconText = card.querySelector('.bili-video-card__info--icon-text');
    if (iconText) {
      const lm = (iconText.textContent || '').match(/([\d.]+[万亿]?)\s*点赞/);
      if (lm) likes = U.parseCount(lm[1]);
    }
    if (!views) {
      const text = U.cleanText(card.textContent || '');
      const vm = text.match(/([\d.]+[万亿]?)\s*(?:播放|观看)/);
      if (vm) views = U.parseCount(vm[1]);
      const dm = text.match(/([\d.]+[万亿]?)\s*弹幕/);
      if (dm) danmaku = U.parseCount(dm[1]);
      const lm = text.match(/([\d.]+[万亿]?)\s*点赞/);
      if (lm) likes = U.parseCount(lm[1]);
    }
    return { views: views, danmaku: danmaku, likes: likes };
  }

  function pickDate(card) {
    const el = card.querySelector('.bili-video-card__info--date, [class*="info--date"], [class*="publish-time"], [class*="pubdate"]');
    const text = U.cleanText(el ? el.textContent : '') || '';
    if (!text) return 0;
    const now = new Date();
    let m = text.match(/(\d{4})-(\d{2})-(\d{2})/);
    if (m) {
      const d = new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]));
      return Math.floor(d.getTime() / 1000);
    }
    m = text.match(/(\d{1,2})月(\d{1,2})日/);
    if (m) {
      let year = now.getFullYear();
      const d = new Date(year, Number(m[1]) - 1, Number(m[2]));
      if (d.getTime() > now.getTime() + 86400000) d.setFullYear(year - 1);
      return Math.floor(d.getTime() / 1000);
    }
    m = text.match(/(\d+)\s*天前/);
    if (m) return Math.floor((now.getTime() - Number(m[1]) * 86400000) / 1000);
    m = text.match(/(\d+)\s*小时前/);
    if (m) return Math.floor((now.getTime() - Number(m[1]) * 3600000) / 1000);
    if (text.indexOf('昨天') !== -1) return Math.floor((now.getTime() - 86400000) / 1000);
    if (text.indexOf('前天') !== -1) return Math.floor((now.getTime() - 2 * 86400000) / 1000);
    return 0;
  }

  function pickVertical(card) {
    let el = card;
    for (let i = 0; i < 4 && el && el.getAttribute; i++, el = el.parentElement) {
      if (el.style && el.style.getPropertyValue) {
        const v = el.style.getPropertyValue('--cover-radio');
        if (v && parseFloat(v) >= 100) return true;
      }
      const cls = String(el.className || '');
      if (/(^|[\s_-])(vertical|story|portrait|shorts?)([\s_-]|$)/i.test(cls)) return true;
    }
    const cover = card.querySelector('.bili-video-card__image--wrap, .bili-video-card__cover, [class*="image--wrap"], img');
    if (cover) {
      const r = cover.getBoundingClientRect();
      if (r.width > 10 && r.height / r.width >= 1.18) return true;
    }
    return false;
  }

  function isAd(card) {
    if (card.querySelector('.bili-video-card__stats--ad, .bili-video-card__info--ad, .bili-video-card__info--creative-ad, .vui_icon.bili-video-card__stats--icon, [class*="ad-badge"], [class*="ad_badge"]')) return true;
    if (card.closest('[data-ad], [data-adid], [data-ad-id]')) return true;
    const stats = card.querySelectorAll('.bili-video-card__stats--text');
    for (let i = 0; i < stats.length; i++) {
      if (/^(广告|推广|赞助|商业推广)$/.test(U.cleanText(stats[i].textContent || ''))) return true;
    }
    return false;
  }

  function extractItem(card, anchor, bvid) {
    if (isAd(card)) return null;
    const title = pickTitle(card, anchor, bvid);
    if (!title || title.length < 2) return null;
    if (/^(广告|投稿|视频)$/.test(title)) return null;
    const author = pickAuthor(card);
    const durationSec = pickDuration(card);
    const stats = pickStats(card);
    const vertical = pickVertical(card);
    const pubdate = pickDate(card);
    return {
      id: bvid,
      bvid: bvid,
      title: title,
      author: author.author,
      mid: author.mid,
      durationSec: durationSec,
      views: stats.views,
      danmaku: stats.danmaku,
      likes: stats.likes,
      favorites: 0,
      pubdate: pubdate,
      isVertical: vertical,
      context: S.context,
      tags: '',
      description: '',
      url: 'https://www.bilibili.com/video/' + bvid
    };
  }

  function collectCandidates() {
    clearCache();
    const anchors = document.querySelectorAll('a[href*="/video/BV"], a[href*="/video/av"]');
    const byBvid = new Map();
    for (let i = 0; i < anchors.length; i++) {
      const a = anchors[i];
      if (ignoredAnchor(a)) continue;
      const bvid = parseBvid(a.getAttribute('href'));
      if (!bvid || bvid === S.mainBvid) continue;
      const score = anchorScore(a);
      const prev = byBvid.get(bvid);
      if (!prev || score > prev.score) byBvid.set(bvid, { anchor: a, bvid: bvid, score: score });
    }
    const out = [];
    byBvid.forEach(function (entry) {
      const card = findCard(entry.anchor, entry.bvid);
      if (!card) return;
      out.push({ anchor: entry.anchor, card: card, bvid: entry.bvid });
    });
    return out;
  }

  function scheduleCluster() {
    clearTimeout(S.clusterTimer);
    S.clusterTimer = setTimeout(recluster, 420);
  }

  function scheduleScan() {
    clearTimeout(S.scanTimer);
    S.scanTimer = setTimeout(scan, 360);
  }

  function applyPageBackground() {
    if (!S.settings || !S.settings.appearance) return;
    const ap = S.settings.appearance;
    const root = document.documentElement;
    const body = document.body;
    const app = document.querySelector('#app') || document.querySelector('main');
    const container = document.querySelector('.feed2 .container.is-version8, .feed2 .container, .container.is-version8');
    const oldLayer = document.getElementById('blf-page-bg');
    if (oldLayer) oldLayer.remove();
    const clear = function () {
      root.classList.remove('blf-page-bg');
      [root, body, app, container].forEach(function (el) {
        if (!el) return;
        ['background-image', 'background-color', 'background-attachment', 'background-size', 'background-position', 'background-repeat', 'backdrop-filter', '-webkit-backdrop-filter'].forEach(function (prop) {
          el.style.removeProperty(prop);
        });
      });
    };
    if (!ap || ap.background === 'none') {
      clear();
      return;
    }
    root.classList.add('blf-page-bg');
    let base = '';
    if (ap.background === 'color') {
      const c = ap.color || '#eef4fb';
      base = 'linear-gradient(' + c + ', ' + c + ')';
    } else if (ap.background === 'image' && ap.imageUrl) {
      const safe = String(ap.imageUrl).replace(/["\\\\\\n\\r]/g, '');
      base = 'url("' + safe + '")';
    } else {
      base = ap.gradient || 'linear-gradient(135deg, #eef4fb, #dfeaf7)';
    }
    const layers = [];
    if (ap.dim) layers.push('linear-gradient(rgba(8,12,22,' + ap.dim + '), rgba(8,12,22,' + ap.dim + '))');
    if (ap.opacity != null && ap.opacity < 1) {
      const a = Math.max(0, 1 - ap.opacity);
      layers.push('linear-gradient(rgba(255,255,255,' + a + '), rgba(255,255,255,' + a + '))');
    }
    layers.push(base);
    const setBg = function (el) {
      if (!el) return;
      el.style.setProperty('background-image', layers.join(', '), 'important');
      el.style.setProperty('background-color', 'transparent', 'important');
      el.style.setProperty('background-attachment', 'fixed', 'important');
      el.style.setProperty('background-size', 'cover', 'important');
      el.style.setProperty('background-position', 'center center', 'important');
      el.style.setProperty('background-repeat', 'no-repeat', 'important');
    };
    setBg(root);
    setBg(body);
    setBg(app);
    setBg(container);
    if (app && ap.blur) {
      app.style.setProperty('backdrop-filter', 'blur(' + ap.blur + 'px)', 'important');
      app.style.setProperty('-webkit-backdrop-filter', 'blur(' + ap.blur + 'px)', 'important');
    }
  }

  function homeCleanEnabled() {
    return !!(S.settings && S.settings.enabled && !S.paused && S.context === 'feed' &&
      S.settings.homeClean && (S.settings.homeClean.live || S.settings.homeClean.ads || S.settings.homeClean.reflow !== false));
  }

  function homeScope() {
    return document.querySelector('.feed2') ||
      document.querySelector('.bili-feed4-layout') ||
      document.querySelector('main') ||
      document.body;
  }

  function restoreHomeRemoved() {
    S.homeRemoved.forEach(function (el) {
      if (el && el.classList) el.classList.remove('blf-home-removed');
    });
    S.homeRemoved.clear();
  }

  function hideHomeTarget(el, scope, force) {
    if (!el || !el.classList) return;
    if (el === scope || el === document.body || el === document.documentElement) return;
    if (el.closest && el.closest('#blf-extension-host, .blf-study-hero, [data-blf-fill]')) return;
    if (el.classList.contains('blf-home-removed')) return;
    if (!force && !el.classList.contains('feed-card') && el.querySelectorAll && el.querySelectorAll('.feed-card').length > 1) return;
    el.classList.add('blf-home-removed');
    S.homeRemoved.add(el);
  }

  function homeCardTarget(el, scope) {
    if (!el || !scope || !scope.contains(el)) return null;
    const card = el.closest('.feed-card, .col_3, .video-list-item') ||
      el.closest('.floor-single-card, [class*="live-card"], [class*="live-room"], [class*="ad-card"], [data-ad], .bili-video-card') ||
      el;
    if (!card || card === scope || card === document.body) return null;
    return card;
  }

  function applyReflow() {
    const container = studyContainer() || document.querySelector('.feed2 .container');
    document.querySelectorAll('.blf-reflow').forEach(function (el) {
      if (el !== container) el.classList.remove('blf-reflow');
    });
    if (!S.settings || !S.settings.enabled || S.paused || S.context !== 'feed' ||
        !S.settings.homeClean || S.settings.homeClean.reflow === false || !container) {
      if (container) container.classList.remove('blf-reflow');
      return;
    }
    container.classList.add('blf-reflow');
  }

  function cleanHome() {
    if (!homeCleanEnabled()) {
      restoreHomeRemoved();
      document.querySelectorAll('.blf-reflow').forEach(function (el) { el.classList.remove('blf-reflow'); });
      return;
    }
    const scope = homeScope();
    if (!scope) return;
    const hc = S.settings.homeClean;

    if (hc.live) {
      scope.querySelectorAll('.feed-card').forEach(function (card) {
        if (card.querySelector('.floor-single-card')) hideHomeTarget(card, scope);
      });
      scope.querySelectorAll('a[href*="live.bilibili.com/"], [data-live-id], [data-roomid], [data-room-id], [class*="live-card"], [class*="live-room"]').forEach(function (el) {
        if (el.closest('#blf-extension-host, .blf-study-hero, [data-blf-fill]')) return;
        const card = homeCardTarget(el, scope);
        if (!card) return;
        if (el.matches('a[href*="live.bilibili.com/"]') ||
            el.closest('[class*="live-card"], [class*="live-room"], [data-live-id], [data-roomid], [data-room-id]') ||
            card.querySelector('a[href*="live.bilibili.com/"]')) {
          hideHomeTarget(card, scope);
        }
      });
    }

    if (hc.ads) {
      const banner = document.querySelector('.bili-header__banner');
      if (banner) hideHomeTarget(banner, scope, true);
      document.querySelectorAll('.recommended-swipe').forEach(function (el) {
        hideHomeTarget(el, scope, true);
      });
      const adSelectors = [
        '.bili-video-card__info--ad', '.bili-video-card__info--creative-ad',
        '.vui_icon.bili-video-card__stats--icon',
        '.video-card-ad-small', '.ad-floor-cover', '.palette-button-wrap',
        '[data-ad]', '[data-adid]', '[data-ad-id]',
        '[class*="ad-card"]', '[class*="ad-banner"]', '[class*="advertisement"]',
        '[class*="commercial"]', '[class*="sponsor"]'
      ];
      adSelectors.forEach(function (sel) {
        scope.querySelectorAll(sel).forEach(function (el) {
          const card = homeCardTarget(el, scope);
          if (card) hideHomeTarget(card, scope);
        });
      });
      scope.querySelectorAll('.feed-card').forEach(function (card) {
        const stats = card.querySelectorAll('.bili-video-card__stats--text');
        for (let i = 0; i < stats.length; i++) {
          const t = U.cleanText(stats[i].textContent || '');
          if (/^(广告|推广|赞助|商业推广)$/.test(t)) {
            hideHomeTarget(card, scope);
            break;
          }
        }
      });
      scope.querySelectorAll('a[href*="cm.bilibili.com"], a[href*="ad.bilibili.com"], a[href*="doubleclick.net"]').forEach(function (el) {
        const card = homeCardTarget(el, scope);
        if (card) hideHomeTarget(card, scope);
      });
    }

    const remove = [];
    S.records.forEach(function (record, id) {
      if (record.card && record.card.closest && record.card.closest('.blf-home-removed')) remove.push(id);
    });
    remove.forEach(removeRecord);
    applyReflow();
    scheduleEmptyShelves();
  }

  function scan() {
    if (!S.settings || !S.settings.enabled || S.paused) return;
    cleanHome();
    prune();
    const candidates = collectCandidates();
    let added = 0;
    const order = candidates.slice().sort(function (a, b) {
      const ra = a.card.getBoundingClientRect();
      const rb = b.card.getBoundingClientRect();
      return ra.top - rb.top;
    });
    for (let i = 0; i < order.length; i++) {
      const c = order[i];
      if (S.records.has(c.bvid)) {
        const existing = S.records.get(c.bvid);
        if (existing.card === c.card && isFlagged(existing)) {
          const badgeGone = !existing.badge || !existing.badge.isConnected;
          const styleGone = (existing.action === 'blur' && !c.card.classList.contains('blf-blur')) ||
            (existing.action === 'dim' && !c.card.classList.contains('blf-dim')) ||
            (existing.action === 'hide' && !c.card.classList.contains('blf-hide'));
          if (!c.card.classList.contains('blf-card') || styleGone || badgeGone) applyRecord(existing);
        }
        continue;
      }
      if (c.card.dataset && c.card.dataset.blfBvid && c.card.dataset.blfBvid !== c.bvid) {
        const old = S.records.get(c.card.dataset.blfBvid);
        if (old) removeRecord(c.card.dataset.blfBvid);
      }
      if (c.card.dataset && c.card.dataset.blfBvid) {
        const old = S.records.get(c.card.dataset.blfBvid);
        if (old) removeRecord(c.card.dataset.blfBvid);
      } else {
        S.records.forEach(function (rec, id) {
          if (rec.card === c.card && id !== c.bvid) removeRecord(id);
        });
      }
      const orphanBadge = c.card.querySelector('.blf-badge');
      if (orphanBadge) orphanBadge.remove();
      const item = extractItem(c.card, c.anchor, c.bvid);
      if (!item) continue;
      const decision = BLF.Scoring.analyze(item, S.settings);
      const record = {
        id: item.id,
        bvid: item.bvid,
        card: c.card,
        item: item,
        decision: decision,
        cluster: null,
        revealed: false,
        forcedHidden: false,
        badge: null,
        action: 'ok',
        counted: false,
        revealCounted: false
      };
      S.records.set(item.id, record);
      if (decision.severity === 'high' || decision.severity === 'medium') {
        record.counted = true;
        bump('flagged', 1);
        if (decision.severity === 'high') bump('blocked', 1);
      }
      applyRecord(record);
      added++;
    }
    if (added) scheduleCluster();
    processShelves();
    S.stats.scanned = S.records.size;
    updateStats();
    updatePageTopic();
    updateDiversity();
    renderStudyHero();
    maybeLoadStudyPool();
  }

  function prune() {
    const remove = [];
    S.records.forEach(function (record, id) {
      if (!record.card || !record.card.isConnected) remove.push(id);
    });
    remove.forEach(removeRecord);
  }

  function removeRecord(id) {
    const record = S.records.get(id);
    if (!record) return;
    clearRecordVisual(record);
    S.fillAssigned.delete(id);
    S.records.delete(id);
  }

  function clearRecordVisual(record) {
    clearStudyVisual(record);
    const card = record.card;
    if (card) {
      card.classList.remove('blf-card', 'blf-blur', 'blf-dim', 'blf-hide', 'blf-revealed', 'blf-cluster-loser', 'blf-cluster-best');
      if (record.badge && record.badge.parentNode) record.badge.parentNode.removeChild(record.badge);
      record.badge = null;
    }
  }

  function clearAllRecords() {
    resetCollapsedSections();
    S.clusterSig = '';
    S.records.forEach(clearRecordVisual);
    S.records.clear();
    S.items.clear();
    S.clusters = { groups: [], byId: Object.create(null) };
    S.lastSize = 0;
    S.stats = { scanned: 0, flagged: 0, clusters: 0, revealed: 0, hidden: 0 };
    S.pageRevealed = 0;
  }

  function badgeFor(record) {
    const d = record.decision;
    const cluster = record.cluster;
    const labels = (d.labels || []).filter(function (l) {
      return l.severity === 'high' || l.severity === 'medium';
    });
    let primary = labels[0] || null;

    if (cluster && cluster.size >= 3) {
      if (cluster.isBest && !primary) {
        primary = { text: '同题最佳', tone: 'green' };
      } else if (!cluster.isBest && (!primary || (primary.severity !== 'high' && primary.severity !== 'medium'))) {
        primary = { text: '同题', tone: 'blue' };
      }
    }
    if (!primary && S.settings.focusMode && d.shortNonKnowledge) {
      primary = { text: '专注模式', tone: 'blue' };
    }
    if (!primary && record.revealed) {
      primary = { text: '已展开', tone: 'gray' };
    }
    return primary;
  }

  function studyHomeEnabled() {
    return !!(S.settings && S.settings.studyFeed && S.settings.studyFeed.enabled &&
      S.settings.enabled && !S.paused);
  }

  function studyContainer() {
    let container = document.querySelector('.feed2 .container.is-version8, .feed2 .container, .container.is-version8');
    if (container && container.querySelector('.feed-card')) return container;
    const first = document.querySelector('.feed-card');
    if (first && first.parentElement && first.parentElement !== document.body) return first.parentElement;
    return null;
  }

  function studyCover(url) {
    const raw = String(url || '');
    if (!raw) return '';
    if (raw.indexOf('//') === 0) return 'https:' + raw;
    return raw;
  }

  function studyImage(item, eager) {
    const src = studyCover(item.cover);
    return '<span class="blf-study-cover__ph">B</span>' +
      (src ? '<img src="' + U.escapeHtml(src) + '" alt="" loading="' + (eager ? 'eager' : 'lazy') +
        '" referrerpolicy="no-referrer">' : '');
  }

  function studyCard(item, eager) {
    const dur = item.durationSec ? U.formatDuration(item.durationSec) : '';
    const topic = item.studyTopicLabel || '科技';
    const meta = [item.author, item.views ? U.formatCount(item.views) + ' 播放' : '']
      .filter(Boolean).map(U.escapeHtml).join(' · ');
    return '<a class="blf-study-card" href="https://www.bilibili.com/video/' + U.escapeHtml(item.bvid) + '"' +
      ' target="_blank" rel="noopener" title="' + U.escapeHtml(item.title) + '">' +
      '<span class="blf-study-cover">' + studyImage(item, eager) +
        '<span class="blf-study-cover__topic">' + U.escapeHtml(topic) + '</span>' +
        (dur ? '<span class="blf-study-cover__dur">' + U.escapeHtml(dur) + '</span>' : '') +
      '</span>' +
      '<span class="blf-study-body"><span class="blf-study-title">' + U.escapeHtml(item.title) + '</span>' +
        '<span class="blf-study-meta">' + meta + '</span>' +
      '</span></a>';
  }

  function studyHeroItems() {
    const pool = S.studyPool || [];
    if (!pool.length) return [];
    const n = Math.min(4, pool.length);
    const start = (S.heroCursor * n) % pool.length;
    const out = [];
    for (let i = 0; i < n; i++) out.push(pool[(start + i) % pool.length]);
    return out;
  }

  function studyHeroHead() {
    return '<div class="blf-study-head"><div>' +
      '<div class="blf-study-kicker">学习净化 · 首页科技补充</div>' +
      '<h2>今天看点硬核的</h2>' +
      '<p>计算机 · 电子信息 · 科技史 · 10 分钟以上，按收藏率和时长挑的。</p>' +
      '</div><div class="blf-study-actions">' +
      '<button type="button" data-blf-study-action="next">换一批</button>' +
      '<button type="button" data-blf-study-action="settings">设置</button>' +
      '</div></div>';
  }

  function studyHeroBody() {
    if (S.studyPoolLoading && (!S.studyPool || !S.studyPool.length)) {
      let cards = '';
      for (let i = 0; i < 4; i++) {
        cards += '<div class="blf-study-card blf-study-skeleton"><span class="blf-study-cover"></span>' +
          '<span class="blf-study-body"><span class="blf-study-title"></span><span class="blf-study-meta"></span></span></div>';
      }
      return '<div class="blf-study-grid">' + cards + '</div>' +
        '<div class="blf-study-status">正在挑选科技视频 · ' +
        U.escapeHtml(S.studyPoolProgress || '连接 B 站搜索') + '</div>';
    }
    if (S.studyPoolError && (!S.studyPool || !S.studyPool.length)) {
      return '<div class="blf-study-empty"><b>科技学习池没加载出来</b>' +
        '<span>' + U.escapeHtml(S.studyPoolError) + '</span>' +
        '<button type="button" data-blf-study-action="retry">重试</button></div>';
    }
    const items = studyHeroItems();
    if (!items.length) {
      return '<div class="blf-study-empty"><b>还没有科技补充</b>' +
        '<span>点一下，从 B 站找几条计算机 / 电子信息 / 科技长视频。</span>' +
        '<button type="button" data-blf-study-action="load">加载科技推荐</button></div>';
    }
    return '<div class="blf-study-grid">' + items.map(function (it, i) {
      return studyCard(it, i < 2);
    }).join('') + '</div>';
  }

  function applyStudyCarousel() {
    const hide = studyHomeEnabled() && S.context === 'feed' &&
      S.settings.studyFeed.hideCarousel;
    const swipes = document.querySelectorAll('.recommended-swipe');
    for (let i = 0; i < swipes.length; i++) {
      swipes[i].classList.toggle('blf-study-hide', hide);
    }
    const banner = document.querySelector('.bili-header__banner');
    if (banner) banner.classList.toggle('blf-study-hide', studyHomeEnabled() &&
      S.context === 'feed' && !!S.settings.studyFeed.hideBanner);
  }

  function removeStudyHero() {
    if (S.studyHero && S.studyHero.parentNode) S.studyHero.parentNode.removeChild(S.studyHero);
    S.studyHero = null;
    S.studyHeroSig = '';
    applyStudyCarousel();
  }

  function renderStudyHero() {
    if (!studyHomeEnabled() || S.context !== 'feed' || !S.settings.studyFeed.hero) {
      removeStudyHero();
      return;
    }
    const container = studyContainer();
    if (!container) {
      removeStudyHero();
      return;
    }
    let hero = S.studyHero;
    if (!hero || !hero.isConnected || hero.parentElement !== container) {
      if (hero && hero.parentNode) hero.parentNode.removeChild(hero);
      hero = document.createElement('section');
      hero.className = 'blf-study-hero';
      hero.setAttribute('data-blf-study', '1');
      const carousel = container.querySelector('.recommended-swipe');
      container.insertBefore(hero, carousel || container.firstChild);
      S.studyHero = hero;
      S.studyHeroSig = '';
    }
    const ids = (S.studyPool || []).map(function (i) { return i.bvid; }).join(',');
    const sig = [ids, S.heroCursor, S.studyPoolLoading ? '1' : '0', S.studyPoolError,
      S.studyPoolProgress, S.settings.studyFeed.hideCarousel ? '1' : '0'].join('|');
    if (sig === S.studyHeroSig) {
      applyStudyCarousel();
      return;
    }
    S.studyHeroSig = sig;
    hero.innerHTML = studyHeroHead() + studyHeroBody();
    applyStudyCarousel();
  }

  async function ensureStudyPool(force) {
    if (!studyHomeEnabled() || S.context !== 'feed' || S.studyPoolLoading) return;
    if (S.studyPool && !force) return;
    S.studyPoolLoading = true;
    S.studyPoolError = '';
    S.studyPoolProgress = '';
    renderStudyHero();
    try {
      const result = await BLF.StudyFeed.getPool(S.settings, {
        force: !!force,
        onProgress: function (p) {
          S.studyPoolProgress = p.label + ' ' + p.index + '/' + p.total;
          renderStudyHero();
        }
      });
      if (S.context !== 'feed') return;
      S.studyPool = Array.isArray(result.items) ? result.items : [];
      S.heroCursor = 0;
      S.fillAssigned.clear();
      if (!S.studyPool.length) S.studyPoolError = '暂时没有找到合适的科技长视频';
    } catch (e) {
      if (S.context !== 'feed') return;
      S.studyPoolError = (e && e.message) || '加载失败';
      if (!S.studyPool) S.studyPool = [];
    } finally {
      S.studyPoolLoading = false;
      S.studyPoolProgress = '';
      renderStudyHero();
      S.records.forEach(function (r) { applyRecord(r); });
      refreshEmptyShelves();
      if (force) {
        if (S.studyPoolError) BLF.UI.toast(S.studyPoolError, 'error');
        else BLF.UI.toast('科技学习池已更新 · ' + (S.studyPool || []).length + ' 条');
      }
    }
  }

  function maybeLoadStudyPool() {
    if (!studyHomeEnabled() || S.context !== 'feed') return;
    if (S.studyPool || S.studyPoolLoading || S.studyTimer) return;
    if (!S.settings.studyFeed.hero && !S.settings.studyFeed.replaceBlocked) return;
    S.studyTimer = setTimeout(function () {
      S.studyTimer = null;
      ensureStudyPool(false);
    }, 700);
  }

  function studyPoolKey(sf) {
    if (!sf) return '';
    return JSON.stringify({
      topics: sf.topics, minDuration: sf.minDuration,
      poolSize: sf.poolSize, cacheHours: sf.cacheHours
    });
  }

  function fillSlotOf(card) {
    if (!card) return null;
    let el = card;
    for (let depth = 0; el && el !== document.body && depth < 8; depth++) {
      const cls = String(el.className || '');
      if (el.classList && (el.classList.contains('feed-card') ||
          el.classList.contains('col_3') || el.classList.contains('video-list-item') ||
          /(^|\s)video-page-card(?:-small)?(\s|$)/.test(cls))) return el;
      el = el.parentElement;
    }
    return card.parentElement || card;
  }

  function clearStudyVisual(record) {
    if (!record) return;
    if (record.fill && record.fill.parentNode) record.fill.parentNode.removeChild(record.fill);
    record.fill = null;
    if (record.veil && record.veil.parentNode) record.veil.parentNode.removeChild(record.veil);
    record.veil = null;
    if (record.slot) {
      record.slot.classList.remove('blf-fill-slot', 'blf-collapse-slot');
    }
  }

  function fillItemFor(record) {
    const pool = S.studyPool || [];
    if (!pool.length) return null;
    const current = S.fillAssigned.get(record.id);
    if (current) {
      const found = pool.find(function (it) { return it.bvid === current; });
      if (found) return found;
    }
    const used = new Set();
    S.records.forEach(function (r) {
      if (r.item && r.item.bvid) used.add(r.item.bvid);
    });
    S.fillAssigned.forEach(function (bvid, id) {
      if (id !== record.id) used.add(bvid);
    });
    if (S.settings && S.settings.studyFeed && S.settings.studyFeed.hero) {
      studyHeroItems().forEach(function (it) { used.add(it.bvid); });
    }
    let item = pool.find(function (it) { return !used.has(it.bvid); });
    if (!item) item = pool[parseInt(U.hashString(record.id), 16) % pool.length];
    if (item) S.fillAssigned.set(record.id, item.bvid);
    return item || null;
  }

  function studyFillHtml(record) {
    if (S.studyPoolLoading && (!S.studyPool || !S.studyPool.length)) {
      return '<div class="blf-fill-loading"><span></span>正在挑选科技补位…</div>';
    }
    if (S.studyPoolError && (!S.studyPool || !S.studyPool.length)) {
      return '<div class="blf-fill-loading"><b>补位加载失败</b><button type="button" data-blf-fill-load="' +
        U.escapeHtml(record.id) + '">重试</button></div>';
    }
    const item = fillItemFor(record);
    if (!item) {
      return '<div class="blf-fill-loading"><b>这个位置可以换成学习内容</b><button type="button" data-blf-fill-load="' +
        U.escapeHtml(record.id) + '">加载科技补位</button></div>';
    }
    const topic = item.studyTopicLabel || '科技';
    return '<a class="blf-fill-link" href="https://www.bilibili.com/video/' + U.escapeHtml(item.bvid) + '"' +
      ' target="_blank" rel="noopener" title="' + U.escapeHtml(item.title) + '">' +
      '<span class="blf-fill-cover">' + studyImage(item, false) +
        '<span class="blf-fill-topic">学习补位 · ' + U.escapeHtml(topic) + '</span>' +
        (item.durationSec ? '<span class="blf-fill-dur">' + U.formatDuration(item.durationSec) + '</span>' : '') +
      '</span>' +
      '<span class="blf-fill-body"><span class="blf-fill-title">' + U.escapeHtml(item.title) + '</span>' +
        '<span class="blf-fill-meta">' + U.escapeHtml(item.author || '') + ' · ' +
          U.formatCount(item.views || 0) + ' 播放</span></span></a>' +
      '<div class="blf-fill-foot"><span>用一个学习视频补上空位</span>' +
        '<button type="button" data-blf-fill-next="' + U.escapeHtml(record.id) + '">换一个</button></div>';
  }

  function renderStudyFill(record) {
    if (!record || !record.card) return;
    const sf = S.settings && S.settings.studyFeed;
    const container = studyContainer();
    const inMainFeed = !!(container && container.contains(record.card));
    const want = !!(sf && sf.enabled && sf.replaceBlocked && S.settings.enabled && !S.paused &&
      S.context === 'feed' && inMainFeed && record.action === 'hide' && !record.revealed);
    const slot = fillSlotOf(record.card);
    if (!slot || slot === record.card && want) {
      if (record.fill && record.fill.parentNode) record.fill.parentNode.removeChild(record.fill);
      record.fill = null;
      if (slot) slot.classList.remove('blf-fill-slot');
      if (record.action === 'hide' && slot && slot !== record.card) slot.classList.add('blf-collapse-slot');
      else if (slot) slot.classList.remove('blf-collapse-slot');
      return;
    }
    if (record.slot && record.slot !== slot) {
      record.slot.classList.remove('blf-fill-slot', 'blf-collapse-slot');
    }
    record.slot = slot;
    if (!want) {
      if (record.fill && record.fill.parentNode) record.fill.parentNode.removeChild(record.fill);
      record.fill = null;
      slot.classList.remove('blf-fill-slot');
      slot.classList.toggle('blf-collapse-slot', record.action === 'hide');
      return;
    }
    slot.classList.remove('blf-collapse-slot');
    slot.classList.add('blf-fill-slot');
    let fill = record.fill;
    if (!fill || !fill.isConnected) {
      fill = document.createElement('div');
      fill.className = 'blf-fill-card';
      fill.setAttribute('data-blf-fill', '1');
      slot.appendChild(fill);
      record.fill = fill;
    }
    fill.innerHTML = studyFillHtml(record);
  }

  function nextFill(recordId) {
    const record = S.records.get(recordId);
    const pool = S.studyPool || [];
    if (!record || !pool.length) {
      ensureStudyPool(true);
      return;
    }
    const current = S.fillAssigned.get(record.id);
    let idx = pool.findIndex(function (it) { return it.bvid === current; });
    if (idx < 0) idx = 0;
    const used = new Set();
    S.records.forEach(function (r) { if (r.item) used.add(r.item.bvid); });
    S.fillAssigned.forEach(function (bvid, id) { if (id !== record.id) used.add(bvid); });
    if (S.settings && S.settings.studyFeed && S.settings.studyFeed.hero) {
      studyHeroItems().forEach(function (it) { used.add(it.bvid); });
    }
    let chosen = null;
    for (let i = 1; i < pool.length; i++) {
      const it = pool[(idx + i) % pool.length];
      if (!used.has(it.bvid)) { chosen = it; break; }
    }
    if (!chosen) chosen = pool[(idx + 1) % pool.length];
    S.fillAssigned.set(record.id, chosen.bvid);
    renderStudyFill(record);
  }

  function renderStudyVeil(record) {
    if (!record || !record.card) return;
    const want = record.action === 'blur' && S.settings && S.settings.enabled && !S.paused;
    if (!want) {
      if (record.veil && record.veil.parentNode) record.veil.parentNode.removeChild(record.veil);
      record.veil = null;
      return;
    }
    let veil = record.veil;
    if (!veil || !veil.isConnected) {
      veil = document.createElement('div');
      veil.className = 'blf-veil';
      veil.setAttribute('data-blf-veil', '1');
      veil.setAttribute('aria-hidden', 'true');
      record.card.appendChild(veil);
      record.veil = veil;
    }
    veil.innerHTML = '<span class="blf-veil__mark">学习净化</span><span class="blf-veil__hint">点击展开</span>';
  }

  function onStudyClick(event) {
    const studyBtn = event.target && event.target.closest ? event.target.closest('[data-blf-study-action]') : null;
    if (studyBtn) {
      event.preventDefault();
      event.stopImmediatePropagation();
      const action = studyBtn.getAttribute('data-blf-study-action');
      if (action === 'next') {
        S.heroCursor++;
        S.fillAssigned.clear();
        S.records.forEach(function (r) { applyRecord(r); });
        renderStudyHero();
      } else if (action === 'settings') {
        openOptions();
      } else if (action === 'retry' || action === 'load') {
        ensureStudyPool(true);
      }
      return;
    }
    const fillBtn = event.target && event.target.closest ? event.target.closest('[data-blf-fill-next]') : null;
    if (fillBtn) {
      event.preventDefault();
      event.stopImmediatePropagation();
      nextFill(fillBtn.getAttribute('data-blf-fill-next'));
      return;
    }
    const loadBtn = event.target && event.target.closest ? event.target.closest('[data-blf-fill-load]') : null;
    if (loadBtn) {
      event.preventDefault();
      event.stopImmediatePropagation();
      ensureStudyPool(true);
    }
  }

  function applyRecord(record) {
    if (!record || !record.card) return;
    const card = record.card;
    const nextSlot = fillSlotOf(card);
    if (record.slot && record.slot !== nextSlot) clearStudyVisual(record);
    record.slot = nextSlot;
    const action = computeAction(record);
    record.action = action;
    const primary = badgeFor(record);
    const needsCard = action !== 'ok' || !!primary;
    if (needsCard) card.classList.add('blf-card');
    else card.classList.remove('blf-card');
    card.classList.remove('blf-blur', 'blf-dim', 'blf-hide', 'blf-revealed', 'blf-cluster-loser', 'blf-cluster-best');
    card.style.setProperty('--blf-blur', (S.settings.thresholds.blurStrength || 7) + 'px');
    card.dataset.blfBvid = record.bvid;
    card.dataset.blfAction = action;

    if (action === 'blur') card.classList.add('blf-blur');
    else if (action === 'dim') card.classList.add('blf-dim');
    else if (action === 'hide') card.classList.add('blf-hide');

    if (record.revealed && action === 'ok') card.classList.add('blf-revealed');
    if (record.cluster && S.settings.rules.homogeneity) {
      if (!record.cluster.isBest) card.classList.add('blf-cluster-loser');
      else if (record.cluster.size >= 3) card.classList.add('blf-cluster-best');
    }

    renderBadge(record);
    renderStudyVeil(record);
    renderStudyFill(record);
    scheduleEmptyShelves();
  }

  function renderBadge(record) {
    if (!record || !record.card) return;
    const primary = badgeFor(record);
    const card = record.card;
    const shouldShow = !!primary && S.settings.ui.showBadges !== false;
    if (!shouldShow) {
      if (record.badge && record.badge.parentNode) record.badge.parentNode.removeChild(record.badge);
      record.badge = null;
      if (record.action === 'ok' || record.action === 'badge') card.classList.remove('blf-card');
      return;
    }
    let badge = record.badge;
    if (!badge) {
      badge = document.createElement('div');
      badge.className = 'blf-badge';
      badge.setAttribute('data-blf-badge', '1');
      badge.addEventListener('click', function (event) {
        event.preventDefault();
        event.stopImmediatePropagation();
        const btn = event.target && event.target.closest
          ? event.target.closest('.blf-badge__btn[data-blf-action]')
          : null;
        if (btn) {
          const act = btn.getAttribute('data-blf-action');
          if (act === 'reveal') revealRecord(record.id);
          else if (act === 'collapse') collapseRecord(record.id);
          return;
        }
        openRecordPopover(record);
      }, true);
      badge.addEventListener('mousedown', function (event) { event.stopPropagation(); }, true);
      record.badge = badge;
    }
    if (badge.parentNode !== card) card.appendChild(badge);
    card.classList.add('blf-card');

    let text = primary.text;
    const cluster = record.cluster;
    let countHtml = '';
    if (cluster && cluster.size >= 3) {
      if (text !== '同题' && text !== '同题最佳') {
        countHtml = '<span class="blf-badge__count">×' + cluster.size + '</span>';
      } else {
        countHtml = '<span class="blf-badge__count">×' + cluster.size + '</span>';
      }
    }
    const showBtn = record.action === 'blur' || record.action === 'dim' || record.action === 'hide' || record.revealed;
    let btnHtml = '';
    if (showBtn) {
      btnHtml = '<button class="blf-badge__btn" data-blf-action="' + (record.revealed ? 'collapse' : 'reveal') + '">' +
        (record.revealed ? '收起' : '展开') + '</button>';
    }
    badge.dataset.tone = primary.tone || 'gray';
    badge.classList.toggle('blf-badge--muted', !primary.severity && record.action === 'badge');
    badge.classList.toggle('blf-badge--best', primary.text === '同题最佳');
    badge.innerHTML = '<span class="blf-badge__dot"></span>' +
      '<span class="blf-badge__text">' + U.escapeHtml(text) + countHtml + '</span>' +
      btnHtml;
    const why = (record.decision.reasons || []).join(' · ');
    badge.title = why.slice(0, 220);
    badge.style.pointerEvents = 'auto';
  }

  function shelfCandidate(el) {
    if (!el || el === document.body || el === document.documentElement) return false;
    if (el.closest('#blf-extension-host, .bili-video-card, .bili-video-card__info--tit')) return false;
    if (el.tagName === 'A' || el.tagName === 'IMG' || el.tagName === 'BUTTON') return false;
    const cls = String(el.className || '');
    if (!/(vertical|story|short)/i.test(cls)) return false;
    if (/(card|image|cover|info|player|danmaku|header|nav|comment|badge|icon|title)/i.test(cls)) return false;
    if (el.closest('.blf-card')) return false;
    const anchors = el.querySelectorAll('a[href*="/video/"]');
    const ids = new Set();
    for (let i = 0; i < anchors.length; i++) {
      const b = parseBvid(anchors[i].getAttribute('href'));
      if (b) ids.add(b);
      if (ids.size >= 2) break;
    }
    if (ids.size < 2) return false;
    if (el.classList.contains('blf-shelf-collapsed')) return true;
    const r = el.getBoundingClientRect();
    if (r.width < 260 || r.height < 100) return false;
    if (r.width > window.innerWidth * 0.98 && r.height > window.innerHeight * 0.7) return false;
    return true;
  }

  function processShelves() {
    const wanted = [];
    if (S.settings && S.settings.enabled && !S.paused && S.settings.rules.collapseShelves && !S.shelvesSuppressed) {
      const nodes = document.querySelectorAll('[class*="vertical"], [class*="story-mode"], [class*="short-video"], [class*="shorts"]');
      const candidates = [];
      for (let i = 0; i < nodes.length; i++) {
        if (shelfCandidate(nodes[i])) candidates.push(nodes[i]);
      }
      candidates.sort(function (a, b) {
        let da = 0; let db = 0;
        for (let x = a; x; x = x.parentElement) da++;
        for (let x = b; x; x = x.parentElement) db++;
        return da - db;
      });
      candidates.forEach(function (el) {
        if (wanted.some(function (outer) { return outer.contains(el); })) return;
        wanted.push(el);
      });
    }
    S.shelves.forEach(function (el) {
      if (wanted.indexOf(el) === -1) el.classList.remove('blf-shelf-collapsed');
    });
    wanted.forEach(function (el) { el.classList.add('blf-shelf-collapsed'); });
    const changed = wanted.length !== S.shelves.length;
    S.shelves = wanted;
    return changed;
  }

  function restoreShelves() {
    S.shelves.forEach(function (el) { el.classList.remove('blf-shelf-collapsed'); });
    S.shelves = [];
  }

  function recordDomainId(record) {
    if (!record || !record.item) return '';
    const text = [record.item.title, record.item.tags, record.item.typename].filter(Boolean).join(' ');
    const d = BLF.Domains.topDomain(text);
    return d ? d.id : '';
  }

  function recordTopicLabel(record) {
    if (!record) return '';
    return (record.cluster && record.cluster.label) || record.decision.topic || '';
  }

  function isMuted(record) {
    if (!record) return false;
    const domain = recordDomainId(record);
    if (domain && S.mutedDomains.has(domain)) return true;
    const topic = recordTopicLabel(record);
    if (topic && S.mutedTopics.has(topic)) return true;
    return false;
  }

  function computeAction(record) {
    if (!S.settings.enabled || S.paused) return 'ok';
    if (record.forcedHidden) return 'hide';
    if (record.revealed) return 'ok';
    if (isMuted(record)) return 'hide';
    const d = record.decision;
    let action = BLF.Scoring.effectiveAction(d, S.settings);
    const cluster = record.cluster;
    if (S.settings.rules.homogeneity && cluster && !cluster.isBest && cluster.size >= S.settings.thresholds.homogeneityMin) {
      if (action === 'ok' || action === 'badge') action = S.settings.mode === 'hide' ? 'hide' : 'dim';
    }
    if (S.settings.focusMode) {
      if (cluster && !cluster.isBest) action = 'hide';
      else if (d.shortNonKnowledge && !d.protected) action = 'hide';
      else if (d.severity === 'high' && ['gaming', 'ai', 'slop', 'entertainment', 'vertical'].indexOf(d.category) !== -1) action = 'hide';
    }
    return action;
  }

  function isFlagged(record) {
    if (!record) return false;
    if (record.decision.severity === 'high' || record.decision.severity === 'medium') return true;
    if (record.cluster && !record.cluster.isBest) return true;
    if (S.settings.focusMode && record.decision.shortNonKnowledge) return true;
    return false;
  }

  function resetCollapsedSections() {
    document.querySelectorAll('.blf-section-collapsed').forEach(function (el) {
      el.classList.remove('blf-section-collapsed');
    });
  }

  function refreshEmptyShelves() {
    const main = studyContainer();
    const nodes = document.querySelectorAll('.vertical-shelf, [class*="shelf"], [class*="floor"], section');
    for (let i = 0; i < nodes.length; i++) {
      const el = nodes[i];
      if (!el.querySelector || !el.querySelector('.feed-card')) continue;
      if (main && (el === main || main.contains(el) || el.contains(main))) continue;
      if (el.closest('#blf-extension-host')) continue;
      const cards = el.querySelectorAll('.feed-card');
      let allHidden = cards.length > 0;
      for (let j = 0; j < cards.length; j++) {
        const slot = cards[j];
        if (!slot.querySelector('.bili-video-card.blf-hide') || slot.querySelector('[data-blf-fill]')) {
          allHidden = false;
          break;
        }
      }
      el.classList.toggle('blf-section-collapsed', allHidden);
    }
  }

  function scheduleEmptyShelves() {
    clearTimeout(S.emptyShelfTimer);
    S.emptyShelfTimer = setTimeout(refreshEmptyShelves, 80);
  }

  function updateStats() {
    let flagged = 0;
    let hidden = 0;
    S.records.forEach(function (r) {
      if (isFlagged(r)) flagged++;
      if (r.action === 'hide') hidden++;
    });
    S.stats = {
      scanned: S.records.size,
      flagged: flagged,
      clusters: S.clusters.groups.length,
      revealed: S.pageRevealed,
      hidden: hidden + S.shelves.length
    };
    BLF.UI.setStats(S.stats);
    BLF.UI.setPageInfo({ context: CONTEXT_LABEL[S.context] || 'B站', topic: S.pageTopic });
    if (S.lastBadgeCount !== flagged) {
      S.lastBadgeCount = flagged;
      clearTimeout(S.badgeTimer);
      S.badgeTimer = setTimeout(function () { sendBadge(flagged); }, 500);
    }
  }

  function sendBadge(count) {
    if (BLF.Store.isDemo || typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.sendMessage) return;
    try {
      chrome.runtime.sendMessage({ type: 'blf:badge', count: count }, function () {
        if (chrome.runtime.lastError) { /* ignore */ }
      });
    } catch (e) { /* extension reloaded */ }
  }

  function updatePageTopic() {
    let topic = S.baseTopic;
    if (!topic && S.context === 'feed' && S.clusters.groups.length) topic = S.clusters.groups[0].label;
    if (topic !== S.pageTopic) {
      S.pageTopic = topic;
      BLF.UI.setPageInfo({ context: CONTEXT_LABEL[S.context] || 'B站', topic: topic });
    }
  }

  function updateDiversity() {
    if (!S.settings || !S.settings.explore || S.settings.explore.enabled === false ||
        S.context === 'search' || S.paused) {
      S.diversity = null;
      BLF.UI.setDiversity(null);
      return;
    }
    const titles = [];
    S.records.forEach(function (record) {
      if (record.item && record.item.title) titles.push(record.item.title);
    });
    const d = BLF.Domains.diversity(titles, S.settings.explore.cocoonThreshold);
    S.diversity = d;
    BLF.UI.setDiversity(d);
  }

  async function syncProfile() {
    const profile = await BLF.Account.sync(S.settings, {});
    S.profile = profile;
    BLF.UI.setProfile(profile);
    updateDiversity();
    return profile;
  }

  async function exploreAll(opts) {
    const profile = S.profile || BLF.Profile.fromSettings(S.settings);
    const excludeIds = [];
    S.records.forEach(function (record, id) { excludeIds.push(id); });
    const data = await BLF.Explore.getAll(profile, S.settings, {
      force: !!(opts && opts.force),
      excludeIds: excludeIds,
      onProgress: function (p) {
        if (p && p.index && p.total) {
          // 不阻塞 UI，细节由探索弹窗的进度文案承载
        }
      }
    });
    return data;
  }

  function recluster() {
    if (!S.settings || !S.settings.enabled || S.paused) return;
    if (!CLUSTER_CONTEXTS[S.context] || !S.settings.rules.homogeneity) {
      if (S.clusters.groups.length) {
        S.clusters = { groups: [], byId: Object.create(null) };
        S.clusterSig = '';
        S.records.forEach(function (r) { r.cluster = null; applyRecord(r); });
        updateStats();
      }
      return;
    }
    const list = [];
    S.records.forEach(function (record) {
      const item = record.item;
      if (!item.title || item.title.length < 3) return;
      list.push({
        id: item.id,
        bvid: item.bvid,
        title: item.title,
        author: item.author,
        durationSec: item.durationSec,
        views: item.views,
        likes: item.likes,
        favorites: item.favorites,
        url: item.url,
        quality: record.decision.quality
      });
    });
    if (list.length < S.settings.thresholds.homogeneityMin) {
      if (S.clusters.groups.length) {
        S.clusters = { groups: [], byId: Object.create(null) };
        S.clusterSig = '';
        S.records.forEach(function (r) { r.cluster = null; applyRecord(r); });
        updateStats();
      }
      return;
    }
    const result = BLF.Cluster.analyze(list, { minSize: S.settings.thresholds.homogeneityMin });
    const sig = result.groups.map(function (g) {
      return g.id + ':' + g.size + ':' + g.itemIds.slice().sort().join(',');
    }).join('|');
    if (sig === S.clusterSig) return;
    S.clusterSig = sig;
    S.clusters = result;
    S.records.forEach(function (record) {
      record.cluster = result.byId[record.id] || null;
      applyRecord(record);
    });
    updateStats();
    updatePageTopic();
    updateDiversity();
  }

  function revealRecord(id) {
    const record = S.records.get(id);
    if (!record) return;
    record.revealed = true;
    record.forcedHidden = false;
    if (!record.revealCounted) {
      record.revealCounted = true;
      S.pageRevealed++;
      bump('revealed', 1);
    }
    applyRecord(record);
    updateStats();
    const vm = popoverVm(record);
    BLF.UI.updateCardPopover(vm);
  }

  function collapseRecord(id) {
    const record = S.records.get(id);
    if (!record) return;
    record.revealed = false;
    applyRecord(record);
    updateStats();
    BLF.UI.closePopover();
  }

  function hideRecord(id) {
    const record = S.records.get(id);
    if (!record) return;
    record.forcedHidden = true;
    record.revealed = false;
    applyRecord(record);
    updateStats();
    BLF.UI.closePopover();
  }

  function muteSimilar(id) {
    const record = S.records.get(id);
    if (!record) return;
    const domain = recordDomainId(record);
    const topic = recordTopicLabel(record);
    if (!domain && !topic) {
      BLF.UI.toast('没有识别出同类内容', 'error');
      return;
    }
    if (domain) S.mutedDomains.add(domain);
    if (topic) S.mutedTopics.add(topic);
    record.revealed = false;
    S.records.forEach(function (r) {
      if (isMuted(r)) applyRecord(r);
    });
    updateStats();
    BLF.UI.closePopover();
    const d = domain ? BLF.Domains.get(domain) : null;
    const label = d ? d.label : topic;
    BLF.UI.toast('本页已少看「' + label + '」同类 · 点“显示隐藏”恢复');
  }

  function revealAllHidden() {
    S.mutedDomains.clear();
    S.mutedTopics.clear();
    if (S.shelves.length) S.shelvesSuppressed = true;
    restoreShelves();
    S.records.forEach(function (record) {
      if (record.action === 'hide' || record.forcedHidden) {
        record.forcedHidden = false;
        record.revealed = true;
        if (!record.revealCounted) {
          record.revealCounted = true;
          S.pageRevealed++;
          bump('revealed', 1);
        }
        applyRecord(record);
      }
    });
    updateStats();
  }

  function whitelistRecord(id) {
    const record = S.records.get(id);
    if (!record) return;
    const name = (record.item.author || '').trim();
    const mid = record.item.mid;
    if (!name && !mid) {
      BLF.UI.toast('没有识别到这个 UP 主，请到设置页手动添加', 'error');
      return;
    }
    const wl = S.settings.whitelist;
    const names = wl.names.slice();
    const mids = wl.mids.slice();
    if (name && names.indexOf(name) === -1) names.push(name);
    if (mid && mids.indexOf(String(mid)) === -1) mids.push(String(mid));
    onPatch({ whitelist: { names: names, mids: mids } });
    BLF.UI.toast('已放行：' + (name || ('mid ' + mid)));
    BLF.UI.closePopover();
  }

  function popoverVm(record) {
    const cluster = record.cluster;
    const labels = (record.decision.labels || []).filter(function (l) {
      return l.severity !== 'none' || l.id === 'knowledge';
    });
    const reasons = (record.decision.reasons || []).slice();
    if (cluster) {
      reasons.push(cluster.isBest
        ? '同题共 ' + cluster.size + ' 个视频，这一条是当前最佳版本'
        : '同题共 ' + cluster.size + ' 个视频，已保留更优版本');
    }
    const domainId = recordDomainId(record);
    const domainObj = domainId ? BLF.Domains.get(domainId) : null;
    return {
      id: record.id,
      title: record.item.title,
      author: record.item.author,
      durationSec: record.item.durationSec,
      labels: labels,
      reasons: U.unique(reasons),
      cluster: cluster,
      revealed: record.revealed,
      bestUrl: cluster ? cluster.bestUrl : '',
      clusterLabel: cluster ? cluster.label : '',
      canMute: !!(domainObj || recordTopicLabel(record)),
      muteLabel: domainObj ? domainObj.label : recordTopicLabel(record),
      topic: record.decision.topic || (cluster ? cluster.label : ''),
      canWhitelist: !!(record.item.author || record.item.mid)
    };
  }

  function openRecordPopover(record) {
    const badge = record.badge;
    const rect = badge ? badge.getBoundingClientRect() : record.card.getBoundingClientRect();
    const vm = popoverVm(record);
    vm.rect = rect;
    BLF.UI.openPopover(vm, rect);
  }

  function onPatch(patch) {
    if (!S.settings || !patch) return;
    const prevEnabled = S.settings.enabled;
    const prevPaused = S.paused;
    const prevStudy = S.settings.studyFeed ? JSON.stringify(S.settings.studyFeed) : '';
    S.settings = BLF.Settings.normalize(BLF.Settings.merge(S.settings, patch));
    BLF.UI.setSettings(S.settings);
    scheduleSave();
    const onlyUi = Object.keys(patch).length === 1 && !!patch.ui;
    if (onlyUi) return;
    if (patch.rules && Object.prototype.hasOwnProperty.call(patch.rules, 'collapseShelves')) {
      S.shelvesSuppressed = false;
    }
    if (patch.explore && (!S.profile || S.profile.manual)) {
      S.profile = BLF.Profile.fromSettings(S.settings);
      BLF.UI.setProfile(S.profile);
    }
    if (patch.explore) {
      BLF.Explore.clearCache();
      if (patch.explore.deepen || patch.explore.broaden) BLF.UI.invalidateExplore();
      updateDiversity();
    }
    if (patch.appearance) applyPageBackground();
    if (patch.homeClean) {
      restoreHomeRemoved();
      cleanHome();
    }
    if (patch.studyFeed) {
      const nextStudy = S.settings.studyFeed;
      const studyChanged = prevStudy !== JSON.stringify(nextStudy);
      const needPoolReset = patch.studyFeed.topics || patch.studyFeed.minDuration ||
        patch.studyFeed.poolSize || patch.studyFeed.cacheHours;
      if (needPoolReset) {
        BLF.StudyFeed.clearCache();
        S.studyPool = null;
        S.studyPoolError = '';
        S.studyPoolProgress = '';
        S.fillAssigned.clear();
      }
      if (studyChanged) {
        renderStudyHero();
        applyStudyCarousel();
        S.records.forEach(function (r) { applyRecord(r); });
        maybeLoadStudyPool();
      }
    }
    if (S.settings.enabled !== prevEnabled) {
      if (S.settings.enabled) start(); else stop();
    }
    if (S.settings.enabled && !S.paused) {
      scheduleReclassify();
    } else {
      BLF.UI.setPaused(S.paused);
      updateStats();
    }
    if (prevPaused !== S.paused) BLF.UI.setPaused(S.paused);
  }

  function scheduleReclassify() {
    clearTimeout(S.reclassifyTimer);
    S.reclassifyTimer = setTimeout(reclassifyAll, 120);
  }

  function reclassifyAll() {
    if (!S.settings) return;
    if (!S.settings.enabled || S.paused) {
      S.records.forEach(clearRecordVisual);
      resetCollapsedSections();
      updateStats();
      return;
    }
    S.records.forEach(function (record) {
      record.decision = BLF.Scoring.analyze(record.item, S.settings);
      applyRecord(record);
    });
    recluster();
    processShelves();
    updateStats();
    updateDiversity();
  }

  function scheduleSave() {
    clearTimeout(S.saveTimer);
    S.saveTimer = setTimeout(async function () {
      if (!S.settings) return;
      const normalized = BLF.Settings.normalize(S.settings);
      S.settings = normalized;
      S.lastSettingsJson = JSON.stringify(normalized);
      await BLF.Store.set('blfSettings', normalized);
    }, 260);
  }

  async function applyPreset(name) {
    const p = BLF.Settings.preset(name);
    p.enabled = S.settings.enabled;
    p.whitelist = S.settings.whitelist;
    p.customBlock = S.settings.customBlock;
    p.customAllow = S.settings.customAllow;
    p.qualityUps = S.settings.qualityUps;
    p.archaeology = S.settings.archaeology;
    p.explore = S.settings.explore;
    p.studyFeed = S.settings.studyFeed;
    p.ui = S.settings.ui;
    S.settings = BLF.Settings.normalize(p);
    BLF.UI.setSettings(S.settings);
    if (S.settings.enabled) {
      start();
      reclassifyAll();
    }
    scheduleSave();
    const label = name === 'focus' ? '专注学习' : name === 'gentle' ? '轻度' : '平衡';
    BLF.UI.toast('已切换到「' + label + '」模式');
  }

  function togglePause() {
    if (S.paused) {
      S.paused = false;
      BLF.UI.setPaused(false);
      start();
      scan();
      BLF.UI.toast('已恢复净化');
    } else {
      S.paused = true;
      BLF.UI.setPaused(true);
      S.mutedDomains.clear();
      S.mutedTopics.clear();
      restoreHomeRemoved();
      clearTimeout(S.studyTimer);
      S.studyTimer = null;
      clearTimeout(S.emptyShelfTimer);
      S.emptyShelfTimer = null;
      removeStudyHero();
      resetCollapsedSections();
      document.querySelectorAll('.blf-reflow').forEach(function (el) { el.classList.remove('blf-reflow'); });
      restoreShelves();
      S.records.forEach(clearRecordVisual);
      S.records.clear();
      S.clusters = { groups: [], byId: Object.create(null) };
      S.clusterSig = '';
      updateStats();
      BLF.UI.toast('本页已暂停 · 点击「恢复本页」继续净化');
    }
  }

  function openOptions() {
    if (typeof chrome !== 'undefined' && chrome.runtime) {
      try {
        if (chrome.runtime.openOptionsPage) { chrome.runtime.openOptionsPage(); return; }
      } catch (e) { /* ignore */ }
      try { window.open(chrome.runtime.getURL('src/options/options.html'), '_blank'); } catch (e) { /* ignore */ }
    } else {
      BLF.UI.toast('演示页没有设置页');
    }
  }

  function start() {
    if (S.started || !S.settings || !S.settings.enabled || S.paused) return;
    S.started = true;
    if (!S.observer && document.body) {
      S.observer = new MutationObserver(function () { scheduleScan(); });
      S.observer.observe(document.body, { childList: true, subtree: true });
    }
    scan();
    renderStudyHero();
    maybeLoadStudyPool();
  }

  function stop() {
    S.started = false;
    if (S.observer) { S.observer.disconnect(); S.observer = null; }
    S.shelvesSuppressed = false;
    S.mutedDomains.clear();
    S.mutedTopics.clear();
    restoreHomeRemoved();
    restoreShelves();
    S.records.forEach(clearRecordVisual);
    S.records.clear();
    S.clusters = { groups: [], byId: Object.create(null) };
    S.clusterSig = '';
    S.pageRevealed = 0;
    S.stats = { scanned: 0, flagged: 0, clusters: 0, revealed: 0, hidden: 0 };
    S.lastBadgeCount = 0;
    S.diversity = null;
    S.studyPool = null;
    S.studyPoolLoading = false;
    S.studyPoolError = '';
    S.studyPoolProgress = '';
    S.heroCursor = 0;
    S.fillAssigned.clear();
    clearTimeout(S.studyTimer);
    S.studyTimer = null;
    clearTimeout(S.emptyShelfTimer);
    S.emptyShelfTimer = null;
    resetCollapsedSections();
    document.querySelectorAll('.blf-reflow').forEach(function (el) { el.classList.remove('blf-reflow'); });
    BLF.UI.setDiversity(null);
    removeStudyHero();
    updateStats();
    sendBadge(0);
  }

  function onNavigate() {
    S.mainBvid = mainBvid();
    S.context = detectContext();
    S.baseTopic = detectTopic();
    S.pageTopic = '';
    S.clusterSig = '';
    S.lastSize = 0;
    S.shelvesSuppressed = false;
    S.mutedDomains.clear();
    S.mutedTopics.clear();
    restoreHomeRemoved();
    S.fillAssigned.clear();
    S.heroCursor = 0;
    clearTimeout(S.studyTimer);
    S.studyTimer = null;
    removeStudyHero();
    document.querySelectorAll('.blf-reflow').forEach(function (el) { el.classList.remove('blf-reflow'); });
    restoreShelves();
    clearAllRecords();
    BLF.UI.closePopover();
    BLF.UI.setPageInfo({ context: CONTEXT_LABEL[S.context] || 'B站', topic: S.baseTopic });
    applyPageBackground();
    BLF.UI.setDiversity(null);
    updateStats();
    if (S.settings && S.settings.enabled && !S.paused) setTimeout(scan, 650);
  }

  function watchUrl() {
    S.lastHref = location.href;
    S.urlTimer = setInterval(function () {
      if (location.href !== S.lastHref) {
        S.lastHref = location.href;
        onNavigate();
      }
    }, 800);
  }

  function bindClicks() {
    document.addEventListener('click', function (event) {
      if (event.button !== 0) return;
      const path = event.composedPath ? event.composedPath() : [];
      if (path.some(function (el) { return el && el.id === 'blf-extension-host'; })) return;
      if (path.some(function (el) { return el && el.classList && el.classList.contains('blf-badge'); })) return;
      let card = null;
      for (let i = 0; i < path.length; i++) {
        const el = path[i];
        if (el && el.classList && el.classList.contains('blf-card')) { card = el; break; }
      }
      if (!card) return;
      const record = S.records.get(card.dataset.blfBvid);
      if (!record || record.revealed) return;
      if (record.action === 'blur' || record.action === 'dim') {
        event.preventDefault();
        event.stopImmediatePropagation();
        revealRecord(record.id);
      }
    }, true);
    document.addEventListener('click', onStudyClick, true);
  }

  function bindRuntime() {
    BLF.Store.onChange(function (key, value) {
      if (key === 'blfProfile') {
        S.profile = value || null;
        if (!S.profile && S.settings && S.settings.explore &&
            ((S.settings.explore.deepen || []).length || (S.settings.explore.broaden || []).length)) {
          S.profile = BLF.Profile.fromSettings(S.settings);
        }
        BLF.UI.setProfile(S.profile);
        updateDiversity();
        return;
      }
      if (key !== 'blfSettings' || !value) return;
      const json = JSON.stringify(value);
      if (json === S.lastSettingsJson) return;
      S.lastSettingsJson = json;
      const prevExplore = S.settings && S.settings.explore ? JSON.stringify(S.settings.explore) : '';
      const prevStudy = S.settings && S.settings.studyFeed ? JSON.stringify(S.settings.studyFeed) : '';
      const prevHomeClean = S.settings && S.settings.homeClean ? JSON.stringify(S.settings.homeClean) : '';
      S.settings = BLF.Settings.normalize(value);
      BLF.UI.setSettings(S.settings);
      if (prevExplore && JSON.stringify(S.settings.explore) !== prevExplore) {
        BLF.Explore.clearCache();
        BLF.UI.invalidateExplore();
      }
      if (S.settings.appearance) applyPageBackground();
      if (prevHomeClean !== JSON.stringify(S.settings.homeClean)) {
        restoreHomeRemoved();
        cleanHome();
      }
      if (prevStudy !== JSON.stringify(S.settings.studyFeed)) {
        const prevSf = (function () { try { return JSON.parse(prevStudy || '{}'); } catch (e) { return {}; } })();
        if (studyPoolKey(prevSf) !== studyPoolKey(S.settings.studyFeed)) {
          BLF.StudyFeed.clearCache();
          S.studyPool = null;
          S.studyPoolError = '';
          S.fillAssigned.clear();
        }
        renderStudyHero();
        applyStudyCarousel();
        S.records.forEach(function (r) { applyRecord(r); });
        maybeLoadStudyPool();
      }
      if ((!S.profile || S.profile.manual) && S.settings.explore &&
          ((S.settings.explore.deepen || []).length || (S.settings.explore.broaden || []).length)) {
        S.profile = BLF.Profile.fromSettings(S.settings);
        BLF.UI.setProfile(S.profile);
      }
      if (!S.settings.enabled) stop();
      else if (!S.started) start();
      reclassifyAll();
    });

    if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.onMessage) return;
    chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
      if (!msg || !msg.type) return;
      if (msg.type === 'blf:open-panel') {
        BLF.UI.openPanel();
        sendResponse({ ok: true });
      } else if (msg.type === 'blf:open-archaeology') {
        BLF.UI.openArchaeology(msg.topic || S.pageTopic || S.baseTopic, true);
        sendResponse({ ok: true });
      } else if (msg.type === 'blf:page-info') {
        sendResponse({
          ok: true,
          context: S.context,
          contextLabel: CONTEXT_LABEL[S.context] || 'B站',
          topic: S.pageTopic || S.baseTopic,
          url: location.href,
          paused: S.paused,
          enabled: S.settings ? S.settings.enabled : false,
          stats: S.stats,
          diversity: S.diversity ? {
            topLabel: S.diversity.top ? S.diversity.top.label : '',
            topShare: S.diversity.topShare,
            isCocoon: S.diversity.isCocoon,
            entropy: S.diversity.entropy
          } : null
        });
      } else if (msg.type === 'blf:toggle-pause') {
        togglePause();
        sendResponse({ ok: true, paused: S.paused });
      } else if (msg.type === 'blf:sync-profile') {
        syncProfile().then(function (profile) {
          sendResponse({ ok: true, profile: profile });
        }).catch(function (err) {
          sendResponse({ ok: false, error: { message: (err && err.message) || '同步失败', code: err && err.code } });
        });
      } else if (msg.type === 'blf:open-explore') {
        BLF.UI.openExplore();
        sendResponse({ ok: true });
      } else if (msg.type === 'blf:refresh-study') {
        ensureStudyPool(true).then(function () {
          sendResponse({ ok: !S.studyPoolError, count: (S.studyPool || []).length, error: S.studyPoolError });
        }).catch(function (err) {
          sendResponse({ ok: false, error: (err && err.message) || '刷新失败' });
        });
      }
      return true;
    });
  }

  function bump(key, delta) {
    const today = U.todayKey();
    if (!S.daily || S.daily.day !== today) {
      S.daily = { day: today, flagged: 0, revealed: 0, archaeology: 0, blocked: 0 };
    }
    S.daily[key] = (S.daily[key] || 0) + delta;
    clearTimeout(S.statTimer);
    S.statTimer = setTimeout(function () {
      if (S.daily) BLF.Store.set('blfStats', S.daily);
    }, 900);
  }

  async function loadDaily() {
    const stored = await BLF.Store.get('blfStats', null);
    const today = U.todayKey();
    if (stored && stored.day === today) {
      S.daily = {
        day: today,
        flagged: Number(stored.flagged) || 0,
        revealed: Number(stored.revealed) || 0,
        archaeology: Number(stored.archaeology) || 0,
        blocked: Number(stored.blocked) || 0
      };
    } else {
      S.daily = { day: today, flagged: 0, revealed: 0, archaeology: 0, blocked: 0 };
    }
  }

  async function runArchaeology(topic, opts) {
    const temp = BLF.Settings.normalize(BLF.Settings.merge(S.settings, {
      archaeology: {
        cutoff: opts.cutoff,
        minDuration: opts.minDuration
      }
    }));
    const result = await BLF.Api.archaeology(topic, temp, {
      onProgress: function (p) { BLF.UI.archProgress(p.page, p.pages); }
    });
    bump('archaeology', 1);
    return result;
  }

  function welcome() {
    if (BLF.Store.isDemo) return;
    BLF.Store.get('blfWelcomeShown', false).then(function (shown) {
      if (shown) return;
      BLF.Store.set('blfWelcomeShown', true);
      setTimeout(function () {
        BLF.UI.toast('学习净化器已启用 · Alt+B 打开面板，Alt+A 考古');
      }, 1200);
    });
  }

  async function boot() {
    if (!isTarget()) return;
    S.settings = await BLF.Settings.load();
    S.lastSettingsJson = JSON.stringify(S.settings);
    await loadDaily();
    S.mainBvid = mainBvid();
    S.context = detectContext();
    S.baseTopic = detectTopic();
    S.pageTopic = S.baseTopic;
    try {
      S.profile = await BLF.Account.load();
    } catch (e) {
      S.profile = null;
    }
    if (!S.profile && S.settings.explore &&
        ((S.settings.explore.deepen || []).length || (S.settings.explore.broaden || []).length)) {
      S.profile = BLF.Profile.fromSettings(S.settings);
    }

    BLF.UI.init({
      onPatch: onPatch,
      onPreset: applyPreset,
      onTogglePause: togglePause,
      onOpenOptions: openOptions,
      onCardAction: function (action, id) {
        if (action === 'reveal') revealRecord(id);
        else if (action === 'hide') hideRecord(id);
        else if (action === 'whitelist') whitelistRecord(id);
        else if (action === 'mute-similar') muteSimilar(id);
        else if (action === 'reveal-all') revealAllHidden();
      },
      onArchaeology: runArchaeology,
      onSyncProfile: syncProfile,
      onExplore: exploreAll
    }, S.settings, {
      context: CONTEXT_LABEL[S.context] || 'B站',
      topic: S.pageTopic,
      url: location.href
    });

    BLF.UI.setProfile(S.profile);
    applyPageBackground();
    bindRuntime();
    bindClicks();
    watchUrl();
    document.addEventListener('visibilitychange', function () {
      if (!document.hidden) scheduleScan();
    });

    if (S.settings.enabled) start();
    renderStudyHero();
    maybeLoadStudyPool();
    welcome();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})(typeof globalThis !== 'undefined' ? globalThis : this);
