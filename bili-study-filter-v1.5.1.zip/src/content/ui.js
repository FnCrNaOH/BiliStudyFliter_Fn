/* B站学习净化器 · 悬浮面板 / 考古弹窗 / 卡片详情（Shadow DOM，避免被 B 站样式污染） */
(function (root) {
  'use strict';
  const BLF = (root.BLF = root.BLF || {});
  const U = BLF.U;

  const ICON = '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 4h18l-7 8v6l-4 2v-8L3 4z"/></svg>';
  const ICON_SEARCH = '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg>';
  const ICON_CLOSE = '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>';
  const ICON_GEAR = '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19 12a7 7 0 0 0-.1-1.2l2-1.6-2-3.4-2.4 1a7 7 0 0 0-2-1.2L14 3h-4l-.5 2.6a7 7 0 0 0-2 1.2l-2.4-1-2 3.4 2 1.6a7 7 0 0 0 0 2.4l-2 1.6 2 3.4 2.4-1a7 7 0 0 0 2 1.2L10 21h4l.5-2.6a7 7 0 0 0 2-1.2l2.4 1 2-3.4-2-1.6c.1-.4.1-.8.1-1.2z"/></svg>';
  const ICON_EXT = '<svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M14 4h6v6M20 4l-9 9"/><path d="M19 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1h5"/></svg>';

  const STYLE = `
  :host { all: initial; }
  * { box-sizing: border-box; }
  #blf-root {
    position: fixed; inset: 0; z-index: 2147483000;
    pointer-events: none;
    font-family: -apple-system, BlinkMacSystemFont, "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", sans-serif;
    color: #e8eef6;
    --blf-bg: #0d111a;
    --blf-card: rgba(18, 24, 36, 0.97);
    --blf-line: rgba(255, 255, 255, 0.09);
    --blf-text: #e8eef6;
    --blf-muted: #8b98ab;
    --blf-accent: #00aeec;
    --blf-pink: #fb7299;
    --blf-green: #3dd68c;
  }
  button { font-family: inherit; }
  .launcher {
    position: fixed; right: 20px; bottom: 22px;
    display: inline-flex; align-items: center; gap: 8px;
    padding: 9px 13px 9px 11px;
    border-radius: 999px;
    border: 1px solid rgba(255,255,255,.14);
    background: linear-gradient(135deg, rgba(0,174,236,.96), rgba(48,108,255,.96));
    color: #fff; font-size: 12px; font-weight: 600;
    letter-spacing: .3px; cursor: pointer;
    box-shadow: 0 10px 30px rgba(0, 110, 200, .35);
    pointer-events: auto;
    backdrop-filter: blur(12px);
    transition: transform .15s ease, box-shadow .15s ease;
  }
  .launcher:hover { transform: translateY(-1px); box-shadow: 0 14px 34px rgba(0,110,200,.45); }
  .launcher svg { opacity: .95; }
  .launcher__count {
    min-width: 20px; height: 20px; padding: 0 6px;
    display: inline-flex; align-items: center; justify-content: center;
    border-radius: 999px; background: rgba(0,0,0,.28);
    font-size: 11px; font-variant-numeric: tabular-nums;
  }
  .launcher.is-paused { background: linear-gradient(135deg, #4b5563, #374151); box-shadow: 0 8px 22px rgba(0,0,0,.3); }

  .restore-chip {
    position: fixed; right: 20px; bottom: 118px;
    padding: 7px 12px; border-radius: 999px;
    border: 1px solid rgba(0,174,236,.35);
    background: rgba(13,17,26,.94); color: #a9d9ee;
    font-size: 11px; cursor: pointer; pointer-events: auto;
    box-shadow: 0 8px 24px rgba(0,0,0,.35);
  }
  .restore-chip b { color: #8ee6ff; }
  .restore-chip:hover { background: rgba(0,174,236,.16); color: #fff; }
  .restore-chip[hidden] { display: none !important; }

  .cocoon-chip {
    position: fixed; right: 20px; bottom: 70px;
    max-width: 280px; padding: 7px 12px; border-radius: 999px;
    border: 1px solid rgba(251,114,153,.38);
    background: rgba(31,17,30,.94);
    color: #ffc0d2; font-size: 11px; cursor: pointer; pointer-events: auto;
    box-shadow: 0 8px 24px rgba(0,0,0,.35);
    white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
  }
  .cocoon-chip:hover { background: rgba(251,114,153,.18); color: #fff; }
  .cocoon-chip[hidden] { display: none !important; }

  .profile-domains { display: flex; flex-wrap: wrap; gap: 5px; }
  .profile-domain {
    display: inline-flex; align-items: center; gap: 4px;
    padding: 4px 7px; border-radius: 6px; background: rgba(255,255,255,.05);
    border: 1px solid rgba(255,255,255,.07); font-size: 10px; color: #aeb9c9;
  }
  .profile-domain b { color: #dfe8f3; font-weight: 600; }
  .profile-domain i { font-style: normal; color: #7f8da2; }
  .diversity { margin-top: 9px; }
  .diversity__bar { height: 5px; border-radius: 999px; background: rgba(255,255,255,.07); overflow: hidden; }
  .diversity__bar i { display: block; height: 100%; width: 0; border-radius: 999px; background: linear-gradient(90deg, #00aeec, #fb7299); transition: width .25s ease; }
  .diversity__text { font-size: 10.5px; color: #8b98ab; margin-top: 5px; }
  .explore-profile {
    padding: 11px 12px; border-radius: 10px; background: rgba(0,174,236,.06);
    border: 1px solid rgba(0,174,236,.14); font-size: 11.5px; color: #aeb9c9; line-height: 1.7;
  }
  .explore-profile b { color: #dfe8f3; }
  .explore-profile .explore-hint { color: #7f8da2; font-size: 10.5px; }
  .explore-actions { display: flex; align-items: center; gap: 6px; margin-top: 10px; flex-wrap: wrap; }
  .explore-actions .spacer { flex: 1; }
  .explore-diversity { margin: 10px 0 2px; }
  .explore-tabs { display: flex; gap: 4px; margin-top: 10px; border-bottom: 1px solid var(--blf-line); padding-bottom: 8px; }
  .explore-tabs button {
    border: 1px solid transparent; background: transparent; color: #8b98ab;
    padding: 6px 12px; border-radius: 8px; font-size: 11.5px; cursor: pointer;
  }
  .explore-tabs button:hover { color: #dfe8f3; background: rgba(255,255,255,.05); }
  .explore-tabs button.is-active { background: rgba(0,174,236,.14); border-color: rgba(0,174,236,.28); color: #8ee6ff; }
  .explore-status { font-size: 11.5px; color: #8b98ab; padding: 10px 2px 6px; min-height: 20px; display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
  .explore-empty { text-align: center; color: #8b98ab; font-size: 12px; padding: 30px 20px 36px; line-height: 1.9; }
  .explore-empty b { color: #dfe8f3; }
  .explore-empty .chip { margin-top: 10px; }
  .explore-badge { font-size: 10px; padding: 2px 6px; border-radius: 5px; background: rgba(177,140,255,.14); color: #d3bcff; }
  .explore-badge--broaden { background: rgba(61,214,140,.13); color: #8ff0bd; }
  .explore-badge--classic { background: rgba(251,114,153,.13); color: #ffa8c0; }
  .modal__card--explore { width: min(840px, calc(100vw - 32px)); }

  .panel {
    position: fixed; right: 20px; bottom: 78px;
    width: 344px; max-height: min(720px, calc(100vh - 110px));
    overflow: auto; overscroll-behavior: contain;
    border-radius: 18px;
    border: 1px solid var(--blf-line);
    background: var(--blf-card);
    box-shadow: 0 24px 70px rgba(0,0,0,.5), inset 0 1px 0 rgba(255,255,255,.05);
    backdrop-filter: blur(22px) saturate(1.1);
    pointer-events: auto;
    padding: 16px;
    transform-origin: bottom right;
    transition: opacity .18s ease, transform .18s ease;
    scrollbar-width: thin;
  }
  .panel[aria-hidden="true"] { display: none; }
  .panel::-webkit-scrollbar { width: 6px; }
  .panel::-webkit-scrollbar-thumb { background: rgba(255,255,255,.14); border-radius: 3px; }

  .panel__head { display: flex; align-items: flex-start; justify-content: space-between; gap: 10px; }
  .brand { display: flex; align-items: center; gap: 10px; min-width: 0; }
  .brand__logo {
    width: 34px; height: 34px; border-radius: 11px;
    display: grid; place-items: center; color: #fff;
    background: linear-gradient(135deg, #00aeec, #7c5cff 70%, #fb7299);
    box-shadow: 0 6px 18px rgba(0,174,236,.3);
    flex: 0 0 auto;
  }
  .brand__title { font-size: 14px; font-weight: 700; letter-spacing: .2px; }
  .brand__sub { font-size: 11px; color: var(--blf-muted); margin-top: 2px; max-width: 180px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .head-actions { display: flex; align-items: center; gap: 6px; }

  .switch {
    width: 42px; height: 24px; border-radius: 999px;
    border: 1px solid rgba(255,255,255,.12);
    background: rgba(255,255,255,.08);
    position: relative; cursor: pointer; padding: 0;
    transition: background .18s ease;
  }
  .switch::after {
    content: ''; position: absolute; top: 2px; left: 2px;
    width: 18px; height: 18px; border-radius: 50%;
    background: #9aa7b8; transition: transform .18s ease, background .18s ease;
  }
  .switch.is-on { background: rgba(0,174,236,.32); border-color: rgba(0,174,236,.6); }
  .switch.is-on::after { transform: translateX(18px); background: #4fd2ff; }

  .icon-btn {
    width: 26px; height: 26px; border-radius: 8px; border: 1px solid transparent;
    background: transparent; color: var(--blf-muted); cursor: pointer;
    display: grid; place-items: center;
  }
  .icon-btn:hover { background: rgba(255,255,255,.07); color: #fff; }

  .stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 7px; margin: 14px 0 4px; }
  .stats > div {
    background: rgba(255,255,255,.045); border: 1px solid rgba(255,255,255,.05);
    border-radius: 11px; padding: 8px 6px 7px; text-align: center;
  }
  .stats b { display: block; font-size: 17px; font-weight: 700; font-variant-numeric: tabular-nums; letter-spacing: .3px; }
  .stats span { display: block; font-size: 10px; color: var(--blf-muted); margin-top: 2px; }

  .section { margin-top: 14px; }
  .section__title { font-size: 11px; color: var(--blf-muted); letter-spacing: .5px; margin-bottom: 7px; display: flex; align-items: center; justify-content: space-between; }
  .hint { font-size: 10px; color: #6e7b8f; font-weight: 400; }

  .seg { display: flex; background: rgba(255,255,255,.05); border-radius: 10px; padding: 3px; gap: 3px; }
  .seg button {
    flex: 1; border: 0; background: transparent; color: var(--blf-muted);
    padding: 7px 4px; border-radius: 8px; font-size: 11.5px; cursor: pointer;
    transition: background .15s ease, color .15s ease;
    white-space: nowrap;
  }
  .seg button:hover { color: #dfe8f3; }
  .seg button.is-active { background: rgba(0,174,236,.18); color: #8ee6ff; box-shadow: inset 0 0 0 1px rgba(0,174,236,.28); }

  .chips { display: flex; flex-wrap: wrap; gap: 6px; }
  .chip {
    border: 1px solid rgba(255,255,255,.09); background: rgba(255,255,255,.035);
    color: #aeb9c9; border-radius: 999px; padding: 5px 9px; font-size: 11px;
    cursor: pointer; transition: all .15s ease;
  }
  .chip:hover { border-color: rgba(255,255,255,.2); color: #e8eef6; }
  .chip.is-active { background: rgba(61,214,140,.14); border-color: rgba(61,214,140,.38); color: #8ff0bd; }
  .chip.is-active::before { content: '✓ '; font-size: 10px; }

  .range { display: block; margin-top: 10px; }
  .range > span { display: flex; justify-content: space-between; font-size: 11.5px; color: #aeb9c9; }
  .range b { color: #dfe8f3; font-variant-numeric: tabular-nums; font-weight: 600; }
  input[type="range"] {
    width: 100%; margin-top: 6px; accent-color: var(--blf-accent); height: 18px; cursor: pointer;
  }

  .arch__row { display: flex; gap: 6px; }
  .arch__row input, .modal input, .modal select {
    flex: 1; min-width: 0; background: rgba(255,255,255,.05);
    border: 1px solid rgba(255,255,255,.1); color: var(--blf-text);
    border-radius: 9px; padding: 8px 9px; font-size: 12px; outline: none;
  }
  .arch__row input:focus, .modal input:focus, .modal select:focus { border-color: rgba(0,174,236,.65); box-shadow: 0 0 0 3px rgba(0,174,236,.12); }
  .primary {
    border: 0; border-radius: 9px; padding: 8px 13px; font-size: 12px; font-weight: 600;
    color: #fff; background: linear-gradient(135deg, #00aeec, #3b82f6);
    cursor: pointer; white-space: nowrap;
  }
  .primary:hover { filter: brightness(1.08); }
  .primary:disabled { opacity: .55; cursor: default; }

  .panel__foot { display: flex; align-items: center; gap: 6px; margin-top: 15px; padding-top: 11px; border-top: 1px solid var(--blf-line); }
  .panel__foot button {
    border: 0; background: transparent; color: var(--blf-muted); font-size: 11px;
    cursor: pointer; padding: 5px 6px; border-radius: 6px;
  }
  .panel__foot button:hover { color: #e8eef6; background: rgba(255,255,255,.06); }
  .panel__foot .kbd { margin-left: auto; font-size: 9.5px; color: #5d6a7d; border: 1px solid rgba(255,255,255,.09); border-radius: 5px; padding: 2px 5px; }

  .modal { position: fixed; inset: 0; display: none; pointer-events: auto; }
  .modal.is-open { display: block; }
  .modal__backdrop { position: absolute; inset: 0; background: rgba(3,6,12,.66); backdrop-filter: blur(5px); }
  .modal__card {
    position: absolute; left: 50%; top: 50%; transform: translate(-50%, -50%);
    width: min(780px, calc(100vw - 32px)); max-height: min(82vh, 860px);
    display: flex; flex-direction: column;
    border-radius: 20px; border: 1px solid rgba(255,255,255,.1);
    background: var(--blf-card); box-shadow: 0 30px 90px rgba(0,0,0,.6);
    overflow: hidden;
  }
  .modal__head { padding: 18px 20px 14px; display: flex; align-items: flex-start; justify-content: space-between; border-bottom: 1px solid var(--blf-line); }
  .modal__title { font-size: 16px; font-weight: 700; letter-spacing: .2px; }
  .modal__sub { font-size: 11.5px; color: var(--blf-muted); margin-top: 4px; line-height: 1.5; }
  .modal__body { padding: 14px 20px 0; overflow: auto; }
  .arch-controls { display: flex; gap: 8px; flex-wrap: wrap; }
  .arch-controls input { flex: 1 1 180px; }
  .arch-controls select { flex: 0 0 auto; background: rgba(255,255,255,.06); }
  .arch-status { font-size: 11.5px; color: var(--blf-muted); padding: 12px 2px 8px; min-height: 20px; display: flex; align-items: center; gap: 8px; }
  .spinner { width: 12px; height: 12px; border-radius: 50%; border: 2px solid rgba(0,174,236,.25); border-top-color: #00aeec; animation: blf-spin .8s linear infinite; }
  @keyframes blf-spin { to { transform: rotate(360deg); } }
  .arch-results { padding-bottom: 4px; }
  .arch-empty { text-align: center; color: var(--blf-muted); font-size: 12.5px; padding: 34px 16px 40px; line-height: 1.8; }
  .arch-empty b { color: #dfe8f3; }
  .arch-item {
    display: flex; gap: 12px; padding: 11px 2px; border-bottom: 1px solid rgba(255,255,255,.055);
    align-items: flex-start;
  }
  .arch-item:last-child { border-bottom: 0; }
  .arch-cover { position: relative; width: 132px; aspect-ratio: 16/9; flex: 0 0 auto; border-radius: 8px; overflow: hidden; background: #1a2230; }
  .arch-cover img { position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover; display: block; z-index: 1; }
  .arch-cover__ph {
    position: absolute; inset: 0; display: grid; place-items: center; z-index: 0;
    background: linear-gradient(135deg, #172536, #34254d 60%, #193a4a);
    color: rgba(255,255,255,.38); font-size: 23px; font-weight: 800; letter-spacing: -1px;
  }
  .arch-cover .dur { position: absolute; right: 4px; bottom: 4px; z-index: 2; padding: 1px 4px; border-radius: 4px; background: rgba(0,0,0,.72); font-size: 10px; color: #fff; font-variant-numeric: tabular-nums; }
  .arch-body { flex: 1; min-width: 0; }
  .arch-title { display: block; color: #e8eef6; font-size: 13px; line-height: 1.45; font-weight: 600; text-decoration: none; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
  .arch-title:hover { color: #8ee6ff; }
  .arch-meta { font-size: 11px; color: var(--blf-muted); margin-top: 5px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .arch-tags { display: flex; gap: 5px; flex-wrap: wrap; margin-top: 6px; }
  .tag { font-size: 10px; padding: 2px 6px; border-radius: 5px; background: rgba(255,255,255,.06); color: #aeb9c9; }
  .tag--score { background: rgba(61,214,140,.13); color: #8ff0bd; font-weight: 700; }
  .tag--old { background: rgba(251,114,153,.12); color: #ffa8c0; }
  .arch-open { align-self: center; flex: 0 0 auto; color: #8ee6ff; font-size: 11px; text-decoration: none; border: 1px solid rgba(0,174,236,.3); padding: 5px 9px; border-radius: 7px; white-space: nowrap; }
  .arch-open:hover { background: rgba(0,174,236,.12); }
  .modal__foot { display: flex; align-items: center; gap: 10px; padding: 12px 20px; border-top: 1px solid var(--blf-line); font-size: 11px; color: var(--blf-muted); flex-wrap: wrap; }
  .modal__foot a { color: #8ee6ff; text-decoration: none; }
  .modal__foot a:hover { text-decoration: underline; }
  .modal__foot .spacer { flex: 1; }

  .popover {
    position: fixed; width: 330px; z-index: 2147483400; pointer-events: auto;
    border-radius: 14px; border: 1px solid rgba(255,255,255,.11);
    background: var(--blf-card); box-shadow: 0 20px 60px rgba(0,0,0,.55);
    padding: 13px 14px; font-size: 12px; line-height: 1.5;
    backdrop-filter: blur(18px);
  }
  .popover[hidden] { display: none; }
  .pop__head { display: flex; align-items: center; gap: 7px; font-size: 12px; font-weight: 700; }
  .pop__dot { width: 7px; height: 7px; border-radius: 50%; background: #00aeec; }
  .pop__dot[data-tone="pink"] { background: #fb7299; }
  .pop__dot[data-tone="purple"] { background: #b18cff; }
  .pop__dot[data-tone="orange"] { background: #ff9f43; }
  .pop__dot[data-tone="amber"] { background: #f7c948; }
  .pop__dot[data-tone="red"] { background: #ff5c5c; }
  .pop__dot[data-tone="gray"] { background: #8b95a5; }
  .pop__dot[data-tone="green"] { background: #3dd68c; }
  .pop__close { margin-left: auto; width: 22px; height: 22px; border: 0; border-radius: 6px; background: transparent; color: #8b98ab; cursor: pointer; display: grid; place-items: center; }
  .pop__close:hover { background: rgba(255,255,255,.07); color: #fff; }
  .pop__title { margin-top: 7px; color: #dfe8f3; font-size: 12.5px; font-weight: 600; line-height: 1.45; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
  .pop__meta { color: #8b98ab; font-size: 11px; margin-top: 4px; }
  .pop__reasons { margin-top: 9px; display: flex; flex-direction: column; gap: 6px; }
  .pop__reason { display: flex; gap: 7px; font-size: 11.5px; color: #aeb9c9; line-height: 1.55; }
  .pop__reason::before { content: '·'; color: #5d6a7d; }
  .pop__cluster { margin-top: 10px; padding: 9px 10px; border-radius: 9px; background: rgba(0,174,236,.08); border: 1px solid rgba(0,174,236,.18); font-size: 11px; color: #a9d9ee; line-height: 1.55; }
  .pop__cluster b { color: #8ee6ff; }
  .pop__actions { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 12px; }
  .pop__actions button, .pop__actions a {
    border: 1px solid rgba(255,255,255,.12); background: rgba(255,255,255,.05);
    color: #cfe3f5; border-radius: 7px; padding: 6px 9px; font-size: 11px;
    cursor: pointer; text-decoration: none; line-height: 1.2;
  }
  .pop__actions button:hover, .pop__actions a:hover { background: rgba(255,255,255,.1); color: #fff; }
  .pop__actions .danger { color: #ffb4b4; border-color: rgba(255,92,92,.28); }
  .pop__actions .accent { color: #8ee6ff; border-color: rgba(0,174,236,.3); }

  .toast {
    position: fixed; left: 50%; bottom: 30px; transform: translateX(-50%) translateY(8px);
    background: rgba(13,17,26,.96); border: 1px solid rgba(255,255,255,.12);
    color: #e8eef6; padding: 10px 16px; border-radius: 10px; font-size: 12px;
    box-shadow: 0 12px 40px rgba(0,0,0,.45); opacity: 0; pointer-events: none;
    transition: opacity .2s ease, transform .2s ease; max-width: 80vw; text-align: center;
    z-index: 2147483500;
  }
  .toast.is-show { opacity: 1; transform: translateX(-50%) translateY(0); }
  .toast[data-type="error"] { border-color: rgba(255,92,92,.4); color: #ffc9c9; }

  @media (max-width: 520px) {
    .panel { right: 8px; left: 8px; width: auto; bottom: 72px; }
    .launcher { right: 12px; bottom: 14px; }
    .popover { width: calc(100vw - 20px); left: 10px !important; }
    .arch-cover { width: 96px; }
  }
  @media (prefers-reduced-motion: reduce) {
    * { animation: none !important; transition: none !important; }
  }
  `;

  const state = {
    initialized: false,
    callbacks: null,
    settings: null,
    stats: { scanned: 0, flagged: 0, clusters: 0, revealed: 0, hidden: 0 },
    pageInfo: { context: '页面', topic: '' },
    paused: false,
    panelOpen: false,
    archOpen: false,
    archRunning: false,
    exploreOpen: false,
    exploreTab: 'deepen',
    exploreData: null,
    exploreLoading: false,
    exploreError: '',
    profile: null,
    diversity: null,
    syncing: false,
    lastFallback: '',
    currentCard: null,
    host: null,
    shadow: null,
    els: {},
    chipRules: {
      gamingShorts: '游戏短视频',
      verticalShorts: '竖屏/小视频',
      aiSlop: 'AI 营销',
      marketingSlop: '营销号',
      clickbait: '标题党',
      entertainmentShorts: '娱乐短视频',
      homogeneity: '同质选题',
      collapseShelves: '折叠专区'
    }
  };

  function esc(s) { return U.escapeHtml(s); }

  function dots(n) {
    return String(n);
  }

  function build() {
    const host = document.createElement('div');
    host.id = 'blf-extension-host';
    host.style.cssText = 'position:fixed;inset:0;z-index:2147483000;pointer-events:none;';
    const shadow = host.attachShadow({ mode: 'open' });

    const ruleChips = Object.keys(state.chipRules).map(function (key) {
      return '<button class="chip" data-action="rule" data-rule="' + key + '">' + esc(state.chipRules[key]) + '</button>';
    }).join('');

    shadow.innerHTML = `
      <style>${STYLE}</style>
      <div id="blf-root">
        <button class="launcher" id="blf-launcher" data-action="open-panel" title="打开学习净化器（Alt+B）">
          ${ICON}<span>学习净化</span><span class="launcher__count" id="blf-launcher-count">0</span>
        </button>

        <button class="restore-chip" id="blf-restore" data-action="reveal-all" hidden>
          已隐藏 <b id="blf-restore-count">0</b> 个 · 显示
        </button>

        <button class="cocoon-chip" id="blf-cocoon" data-action="open-explore" hidden>
          本页领域有点单一 · 换换脑子
        </button>

        <section class="panel" id="blf-panel" aria-hidden="true" aria-label="学习净化器面板">
          <div class="panel__head">
            <div class="brand">
              <div class="brand__logo">${ICON}</div>
              <div>
                <div class="brand__title">学习净化器</div>
                <div class="brand__sub" id="blf-page-context">推荐流</div>
              </div>
            </div>
            <div class="head-actions">
              <button class="switch is-on" id="blf-enabled" data-action="toggle-enabled" aria-label="启用" aria-pressed="true"></button>
              <button class="icon-btn" data-action="close-panel" title="收起">${ICON_CLOSE}</button>
            </div>
          </div>

          <div class="stats">
            <div><b id="blf-stat-scanned">0</b><span>已扫描</span></div>
            <div><b id="blf-stat-flagged">0</b><span>已标记</span></div>
            <div><b id="blf-stat-clusters">0</b><span>同题组</span></div>
            <div><b id="blf-stat-revealed">0</b><span>已展开</span></div>
          </div>

          <div class="section">
            <div class="section__title">兴趣画像 <span class="hint" id="blf-profile-status">未同步</span></div>
            <div class="profile-domains" id="blf-profile-domains">
              <span class="hint">同步账号后，按关注与收藏看领域结构</span>
            </div>
            <div class="diversity">
              <div class="diversity__bar"><i id="blf-diversity-fill"></i></div>
              <div class="diversity__text" id="blf-diversity-text">本页领域分布 —</div>
            </div>
            <div class="arch__row" style="margin-top:8px">
              <button class="chip" data-action="sync-profile" id="blf-sync-profile">同步账号画像</button>
              <button class="primary" data-action="open-explore">探索</button>
            </div>
            <div class="hint" style="margin-top:6px">只在本机聚合关注/收藏，不上传；可随时清除</div>
          </div>

          <div class="section">
            <div class="section__title">策略 <span class="hint">一键切换</span></div>
            <div class="seg" id="blf-preset">
              <button data-action="preset" data-preset="balanced">平衡</button>
              <button data-action="preset" data-preset="focus">专注学习</button>
              <button data-action="preset" data-preset="gentle">轻度</button>
            </div>
          </div>

          <div class="section">
            <div class="section__title">高优先级内容的显示方式</div>
            <div class="seg" id="blf-mode">
              <button data-action="mode" data-mode="blur">模糊</button>
              <button data-action="mode" data-mode="dim">淡化</button>
              <button data-action="mode" data-mode="hide">隐藏</button>
            </div>
          </div>

          <div class="section">
            <div class="section__title">规则</div>
            <div class="chips" id="blf-rules">${ruleChips}</div>
          </div>

          <div class="section">
            <label class="range"><span>短视频阈值 <b id="blf-short-label">3:00</b></span>
              <input type="range" id="blf-short-range" min="30" max="600" step="30">
            </label>
            <label class="range"><span>同题最少 <b id="blf-min-label">3</b> 条</span>
              <input type="range" id="blf-min-range" min="2" max="6" step="1">
            </label>
          </div>

          <div class="section">
            <div class="section__title">考古 · 找到短视频时代前的好内容</div>
            <div class="arch__row">
              <input id="blf-arch-input" placeholder="输入选题，如：信息论" />
              <button class="primary" data-action="archaeology">考古</button>
            </div>
            <div class="hint" style="margin-top:7px">从当前页面提取选题，检索 2021 年前的长视频</div>
          </div>

          <div class="panel__foot">
            <button data-action="pause" id="blf-pause">本页暂停</button>
            <button data-action="reveal-all">显示隐藏</button>
            <button data-action="options">设置</button>
            <span class="kbd">Alt+B</span>
          </div>
        </section>

        <div class="modal" id="blf-arch-modal" aria-hidden="true">
          <div class="modal__backdrop" data-action="close-arch"></div>
          <div class="modal__card" role="dialog" aria-modal="true" aria-label="考古模式">
            <div class="modal__head">
              <div>
                <div class="modal__title">考古模式 · 短视频时代前</div>
                <div class="modal__sub">在 B 站历史视频里，找同一个选题下更长、更扎实的硬核内容。</div>
              </div>
              <button class="icon-btn" data-action="close-arch" title="关闭">${ICON_CLOSE}</button>
            </div>
            <div class="modal__body">
              <div class="arch-controls">
                <input id="blf-arch-modal-input" placeholder="输入选题关键词" />
                <select id="blf-arch-cutoff" aria-label="发布时间上限">
                  <option value="2021-12-31">2021 年前</option>
                  <option value="2019-12-31">2019 年前</option>
                  <option value="2017-12-31">2017 年前</option>
                  <option value="2014-12-31">2014 年前</option>
                </select>
                <select id="blf-arch-mindur" aria-label="最短时长">
                  <option value="300">≥ 5 分钟</option>
                  <option value="600">≥ 10 分钟</option>
                  <option value="1800">≥ 30 分钟</option>
                  <option value="3600">≥ 60 分钟</option>
                </select>
                <button class="primary" id="blf-arch-run" data-action="arch-run">开始考古</button>
              </div>
              <div class="arch-status" id="blf-arch-status">输入选题后开始。结果只来自 B 站公开搜索接口。</div>
              <div class="arch-results" id="blf-arch-results">
                <div class="arch-empty">你正在看的选题，<b>2019 年可能已经有更好的讲解</b>。<br>试试「信息论」「量子力学」「线性代数」。</div>
              </div>
            </div>
            <div class="modal__foot">
              <span id="blf-arch-summary">按收藏率、时长、年代与知识密度综合排序</span>
              <span class="spacer"></span>
              <a href="#" id="blf-arch-fallback" target="_blank" rel="noopener noreferrer">在 B 站搜索页打开 ${ICON_EXT}</a>
            </div>
          </div>
        </div>

        <div class="modal" id="blf-explore-modal" aria-hidden="true">
          <div class="modal__backdrop" data-action="close-explore"></div>
          <div class="modal__card modal__card--explore" role="dialog" aria-modal="true" aria-label="兴趣探索">
            <div class="modal__head">
              <div>
                <div class="modal__title">兴趣探索 · 打破信息茧房</div>
                <div class="modal__sub">用你的关注和收藏做一张兴趣地图：一边深耕，一边拓界。不追求“更上瘾”，只追求更宽。</div>
              </div>
              <button class="icon-btn" data-action="close-explore" title="关闭">${ICON_CLOSE}</button>
            </div>
            <div class="modal__body">
              <div class="explore-profile" id="blf-explore-profile">
                还没有账号画像。可以同步账号，或到设置里手动选择深耕/拓界领域。
              </div>
              <div class="explore-diversity" id="blf-explore-diversity"></div>
              <div class="explore-actions">
                <button class="chip" data-action="sync-profile" id="blf-explore-sync">同步账号画像</button>
                <button class="chip" data-action="explore-settings">兴趣设置</button>
                <span class="spacer"></span>
                <button class="chip" data-action="explore-run" id="blf-explore-run">换一批</button>
              </div>
              <div class="explore-tabs" id="blf-explore-tabs">
                <button data-action="explore-tab" data-lane="deepen" class="is-active">深耕</button>
                <button data-action="explore-tab" data-lane="broaden">拓界</button>
                <button data-action="explore-tab" data-lane="classic">经典</button>
              </div>
              <div class="explore-status" id="blf-explore-status"></div>
              <div class="arch-results" id="blf-explore-results"></div>
            </div>
            <div class="modal__foot">
              <span id="blf-explore-summary">深耕：延长已有兴趣 · 拓界：补上相邻领域 · 经典：2021 年前长内容</span>
              <span class="spacer"></span>
              <span class="hint">本地画像 · 不上传</span>
            </div>
          </div>
        </div>

        <div class="popover" id="blf-popover" hidden></div>
        <div class="toast" id="blf-toast"></div>
      </div>
    `;

    document.documentElement.appendChild(host);

    const byId = function (id) { return shadow.getElementById(id); };
    state.host = host;
    state.shadow = shadow;
    state.els = {
      root: byId('blf-root'),
      launcher: byId('blf-launcher'),
      launcherCount: byId('blf-launcher-count'),
      restore: byId('blf-restore'),
      restoreCount: byId('blf-restore-count'),
      cocoon: byId('blf-cocoon'),
      profileStatus: byId('blf-profile-status'),
      profileDomains: byId('blf-profile-domains'),
      diversityFill: byId('blf-diversity-fill'),
      diversityText: byId('blf-diversity-text'),
      syncProfile: byId('blf-sync-profile'),
      panel: byId('blf-panel'),
      enabled: byId('blf-enabled'),
      pageContext: byId('blf-page-context'),
      statScanned: byId('blf-stat-scanned'),
      statFlagged: byId('blf-stat-flagged'),
      statClusters: byId('blf-stat-clusters'),
      statRevealed: byId('blf-stat-revealed'),
      preset: byId('blf-preset'),
      mode: byId('blf-mode'),
      rules: byId('blf-rules'),
      shortRange: byId('blf-short-range'),
      shortLabel: byId('blf-short-label'),
      minRange: byId('blf-min-range'),
      minLabel: byId('blf-min-label'),
      archInput: byId('blf-arch-input'),
      pause: byId('blf-pause'),
      modal: byId('blf-arch-modal'),
      modalInput: byId('blf-arch-modal-input'),
      cutoff: byId('blf-arch-cutoff'),
      minDur: byId('blf-arch-mindur'),
      archRun: byId('blf-arch-run'),
      archStatus: byId('blf-arch-status'),
      archResults: byId('blf-arch-results'),
      archSummary: byId('blf-arch-summary'),
      archFallback: byId('blf-arch-fallback'),
      exploreModal: byId('blf-explore-modal'),
      exploreProfile: byId('blf-explore-profile'),
      exploreDiversity: byId('blf-explore-diversity'),
      exploreSync: byId('blf-explore-sync'),
      exploreRun: byId('blf-explore-run'),
      exploreTabs: byId('blf-explore-tabs'),
      exploreStatus: byId('blf-explore-status'),
      exploreResults: byId('blf-explore-results'),
      exploreSummary: byId('blf-explore-summary'),
      popover: byId('blf-popover'),
      toast: byId('blf-toast')
    };

    bind();
    state.initialized = true;
  }

  function bind() {
    const shadow = state.shadow;
    shadow.addEventListener('click', function (event) {
      const target = event.target.closest ? event.target.closest('[data-action]') : null;
      if (!target) return;
      const action = target.getAttribute('data-action');
      if (!action) return;
      event.preventDefault();
      event.stopPropagation();
      handleAction(action, target, event);
    });

    state.els.shortRange.addEventListener('input', function () {
      const v = Number(state.els.shortRange.value);
      state.els.shortLabel.textContent = U.formatDuration(v);
      callbacks().onPatch({ thresholds: { shortMax: v } });
    });
    state.els.minRange.addEventListener('input', function () {
      const v = Number(state.els.minRange.value);
      state.els.minLabel.textContent = String(v);
      callbacks().onPatch({ thresholds: { homogeneityMin: v } });
    });
    state.els.archInput.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') {
        e.preventDefault();
        openArchaeology(state.els.archInput.value || state.pageInfo.topic, true);
      }
    });
    state.els.modalInput.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') {
        e.preventDefault();
        runArchaeology();
      }
    });
    state.els.modalInput.addEventListener('input', updateFallback);
    state.els.cutoff.addEventListener('change', function () { state.lastFallback = ''; updateFallback(); });
    state.els.minDur.addEventListener('change', function () { state.lastFallback = ''; updateFallback(); });

    document.addEventListener('keydown', onKeydown, true);
    document.addEventListener('click', onDocumentClick, true);
    window.addEventListener('scroll', onScroll, true);
    window.addEventListener('resize', closePopover, true);
  }

  function callbacks() {
    return state.callbacks || {};
  }

  function onKeydown(e) {
    if (e.altKey && !e.ctrlKey && !e.metaKey) {
      const key = String(e.key || '').toLowerCase();
      if (key === 'b') {
        e.preventDefault();
        togglePanel();
        return;
      }
      if (key === 'a') {
        e.preventDefault();
        openArchaeology(state.pageInfo.topic || state.els.archInput.value, true);
        return;
      }
    }
    if (e.key === 'Escape') {
      if (state.exploreOpen) { closeExplore(); return; }
      if (state.archOpen) { closeArchaeology(); return; }
      if (!state.els.popover.hidden) { closePopover(); return; }
      if (state.panelOpen) closePanel();
    }
  }

  function onDocumentClick(event) {
    if (!state.els || !state.els.popover || state.els.popover.hidden) return;
    const path = event.composedPath ? event.composedPath() : [];
    if (path.indexOf(state.els.popover) !== -1) return;
    if (path.some(function (el) { return el && el.classList && el.classList.contains('blf-badge'); })) return;
    closePopover();
  }

  function onScroll() {
    if (!state.els || state.els.popover.hidden) return;
    closePopover();
  }

  function handleAction(action, target) {
    if (action === 'open-panel') { openPanel(); return; }
    if (action === 'close-panel') { closePanel(); return; }
    if (action === 'toggle-enabled') { callbacks().onPatch({ enabled: !state.settings.enabled }); return; }
    if (action === 'preset') { callbacks().onPreset(target.getAttribute('data-preset')); return; }
    if (action === 'mode') { callbacks().onPatch({ mode: target.getAttribute('data-mode') }); return; }
    if (action === 'rule') {
      const rule = target.getAttribute('data-rule');
      const rules = {};
      rules[rule] = !state.settings.rules[rule];
      callbacks().onPatch({ rules: rules });
      return;
    }
    if (action === 'archaeology') {
      openArchaeology(state.els.archInput.value || state.pageInfo.topic, true);
      return;
    }
    if (action === 'pause') {
      callbacks().onTogglePause();
      return;
    }
    if (action === 'sync-profile') { doSyncProfile(); return; }
    if (action === 'open-explore') { openExplore(); return; }
    if (action === 'close-explore') { closeExplore(); return; }
    if (action === 'explore-tab') { setExploreTab(target.getAttribute('data-lane')); return; }
    if (action === 'explore-run') { loadExplore(true); return; }
    if (action === 'explore-settings') {
      callbacks().onOpenOptions();
      closeExplore();
      return;
    }
    if (action === 'options') {
      callbacks().onOpenOptions();
      closePanel();
      return;
    }
    if (action === 'close-arch') { closeArchaeology(); return; }
    if (action === 'arch-run') { runArchaeology(); return; }
    if (action === 'reveal-all') {
      callbacks().onCardAction('reveal-all', null);
      return;
    }
    if (action === 'open-fallback') {
      if (state.lastFallback) window.open(state.lastFallback, '_blank', 'noopener');
      return;
    }
    if (action === 'pop-close') { closePopover(); return; }
    if (action === 'reveal') { callbacks().onCardAction('reveal', state.currentCard && state.currentCard.id); return; }
    if (action === 'hide') { callbacks().onCardAction('hide', state.currentCard && state.currentCard.id); return; }
    if (action === 'mute-similar') { callbacks().onCardAction('mute-similar', state.currentCard && state.currentCard.id); closePopover(); return; }
    if (action === 'whitelist') { callbacks().onCardAction('whitelist', state.currentCard && state.currentCard.id); return; }
    if (action === 'arch-topic') {
      const topic = state.currentCard && (state.currentCard.clusterLabel || state.currentCard.topic);
      closePopover();
      openArchaeology(topic || state.pageInfo.topic, true);
      return;
    }
    if (action === 'open-best') {
      const url = state.currentCard && state.currentCard.bestUrl;
      if (url) window.open(url, '_blank', 'noopener');
      return;
    }
    if (action === 'toggle-panel') { togglePanel(); return; }
  }

  function openPanel() {
    if (!state.initialized) return;
    state.panelOpen = true;
    state.els.panel.setAttribute('aria-hidden', 'false');
    if (state.settings) {
      state.els.archInput.value = state.els.archInput.value || state.pageInfo.topic || '';
    }
    if (!state.settings || state.settings.ui.panelCollapsed !== false) {
      callbacks().onPatch({ ui: { panelCollapsed: false } });
    }
  }

  function closePanel() {
    if (!state.initialized) return;
    state.panelOpen = false;
    state.els.panel.setAttribute('aria-hidden', 'true');
    closePopover();
    if (!state.settings || state.settings.ui.panelCollapsed !== true) {
      callbacks().onPatch({ ui: { panelCollapsed: true } });
    }
  }

  function togglePanel() {
    if (state.panelOpen) closePanel();
    else openPanel();
  }

  function syncPanel() {
    if (!state.initialized || !state.settings) return;
    const s = state.settings;
    state.els.enabled.classList.toggle('is-on', !!s.enabled);
    state.els.enabled.setAttribute('aria-pressed', s.enabled ? 'true' : 'false');
    state.els.pause.textContent = state.paused ? '恢复本页' : '本页暂停';
    state.els.launcher.classList.toggle('is-paused', state.paused || !s.enabled);
    state.els.launcherCount.textContent = state.paused ? '暂停' : (s.enabled ? dots(state.stats.flagged) : '关');

    const modeBtns = state.els.mode.querySelectorAll('button');
    modeBtns.forEach(function (b) {
      b.classList.toggle('is-active', b.getAttribute('data-mode') === s.mode);
    });

    const presetBtns = state.els.preset.querySelectorAll('button');
    presetBtns.forEach(function (b) {
      const p = b.getAttribute('data-preset');
      b.classList.toggle('is-active', p === 'focus' ? !!s.focusMode : false);
    });

    state.els.rules.querySelectorAll('[data-rule]').forEach(function (b) {
      const key = b.getAttribute('data-rule');
      b.classList.toggle('is-active', !!s.rules[key]);
    });

    state.els.shortRange.value = String(s.thresholds.shortMax);
    state.els.shortLabel.textContent = U.formatDuration(s.thresholds.shortMax);
    state.els.minRange.value = String(s.thresholds.homogeneityMin);
    state.els.minLabel.textContent = String(s.thresholds.homogeneityMin);

    state.els.launcher.style.display = s.ui.showPanel === false ? 'none' : 'inline-flex';
    state.els.restore.hidden = !(state.stats.hidden > 0);
    state.els.restoreCount.textContent = String(state.stats.hidden || 0);
    state.els.pageContext.textContent = state.pageInfo.context + (state.pageInfo.topic ? ' · ' + state.pageInfo.topic : '');
    state.els.statScanned.textContent = String(state.stats.scanned || 0);
    state.els.statFlagged.textContent = String(state.stats.flagged || 0);
    state.els.statClusters.textContent = String(state.stats.clusters || 0);
    state.els.statRevealed.textContent = String(state.stats.revealed || 0);
    renderProfile();
  }

  function setSettings(settings) {
    state.settings = settings;
    if (state.initialized) syncPanel();
  }

  function setStats(stats) {
    state.stats = Object.assign({}, state.stats, stats || {});
    if (state.initialized) syncPanel();
  }

  function setPageInfo(info) {
    const prevTopic = state.pageInfo.topic;
    state.pageInfo = Object.assign({}, state.pageInfo, info || {});
    if (state.initialized) {
      state.els.pageContext.textContent = state.pageInfo.context + (state.pageInfo.topic ? ' · ' + state.pageInfo.topic : '');
      if (state.pageInfo.topic && (!state.els.archInput.value || state.els.archInput.value === prevTopic)) {
        state.els.archInput.value = state.pageInfo.topic;
      }
    }
  }

  function setPaused(paused) {
    state.paused = !!paused;
    if (state.initialized) syncPanel();
  }

  function profileStatusText() {
    if (state.syncing) return '同步中…';
    if (!state.profile) return '未同步';
    if (state.profile.manual) return '手动兴趣';
    return '已同步 ' + U.formatDate(Math.floor((state.profile.syncedAt || 0) / 1000));
  }

  function renderProfile() {
    if (!state.initialized || !state.settings) return;
    const s = state.settings;
    const p = state.profile;
    const d = state.diversity;
    if (state.els.profileStatus) state.els.profileStatus.textContent = profileStatusText();
    if (state.els.syncProfile) {
      state.els.syncProfile.disabled = state.syncing;
      state.els.syncProfile.textContent = state.syncing ? '同步中…' : '同步账号画像';
    }
    if (state.els.exploreSync) {
      state.els.exploreSync.disabled = state.syncing;
      state.els.exploreSync.textContent = state.syncing ? '同步中…' : '同步账号画像';
    }
    if (state.els.profileDomains) {
      if (p && p.domains && p.domains.length) {
        state.els.profileDomains.innerHTML = p.domains.slice(0, 4).map(function (domain) {
          return '<span class="profile-domain"><b>' + esc(domain.label) + '</b><i>' +
            Math.round((domain.share || 0) * 100) + '%</i></span>';
        }).join('');
      } else {
        state.els.profileDomains.innerHTML = '<span class="hint">' +
          (p ? '账号数据里没有识别出明显领域' : '同步账号后，按关注与收藏看领域结构') +
          '</span>';
      }
    }
    if (state.els.diversityFill && state.els.diversityText) {
      if (d && d.classified) {
        state.els.diversityFill.style.width = Math.round(d.topShare * 100) + '%';
        let line = '本页 ' + d.top.label + ' ' +
          Math.round(d.topShare * 100) + '% · 多样性 ' + (d.entropy || 0).toFixed(2) +
          (d.isCocoon ? ' · 偏单一' : '');
        const cal = BLF.Domains && p ? BLF.Domains.compareProfile(p.domains, d, 2) : null;
        if (cal && (cal.over.length || cal.under.length)) {
          const over = cal.over[0];
          const under = cal.under[0];
          const bits = [];
          if (over) bits.push(over.label + ' +' + Math.round(over.delta * 100) + '%');
          if (under) bits.push(under.label + ' ' + Math.round(under.delta * 100) + '%');
          line += ' · 画像偏差：' + bits.join(' / ');
        }
        state.els.diversityText.textContent = line;
      } else {
        state.els.diversityFill.style.width = '0%';
        state.els.diversityText.textContent = '本页领域分布 —';
      }
    }
    if (state.els.cocoon) {
      const show = !!(d && d.isCocoon && s.enabled && !state.paused &&
        s.explore && s.explore.enabled !== false && s.explore.showCocoonChip !== false);
      state.els.cocoon.hidden = !show;
      if (show) {
        state.els.cocoon.textContent = '本页 ' + Math.round(d.topShare * 100) + '% ' +
          d.top.label + ' · 换换脑子';
      }
    }
  }

  function setProfile(profile) {
    state.profile = profile || null;
    state.exploreData = null;
    state.exploreError = '';
    if (state.initialized) {
      renderProfile();
      if (state.exploreOpen) renderExplore();
    }
  }

  function setDiversity(diversity) {
    state.diversity = diversity || null;
    if (state.initialized) {
      renderProfile();
      if (state.exploreOpen) renderExplore();
    }
  }

  function invalidateExplore() {
    state.exploreData = null;
    state.exploreError = '';
    if (state.exploreOpen) loadExplore(true);
    else renderExplore();
  }

  async function doSyncProfile() {
    if (state.syncing) return;
    const cb = callbacks().onSyncProfile;
    if (!cb) { toast('当前页面不支持同步账号画像', 'error'); return; }
    state.syncing = true;
    renderProfile();
    if (state.exploreOpen) renderExplore();
    try {
      const profile = await cb();
      if (profile) state.profile = profile;
      state.syncing = false;
      renderProfile();
      toast(state.profile && state.profile.domains && state.profile.domains.length
        ? '账号画像已同步 · 已生成兴趣地图'
        : '同步完成，但没有识别出明显领域，可以在设置里手动选择');
      if (state.exploreOpen) {
        state.exploreData = null;
        loadExplore(true);
      }
    } catch (err) {
      state.syncing = false;
      renderProfile();
      if (state.exploreOpen) renderExplore();
      toast((err && err.message) || '同步失败，请稍后再试', 'error');
    }
  }

  function openExplore() {
    if (!state.initialized) return;
    if (state.archOpen) closeArchaeology();
    state.exploreOpen = true;
    state.els.exploreModal.classList.add('is-open');
    state.els.exploreModal.setAttribute('aria-hidden', 'false');
    renderExplore();
    const s = state.settings;
    const canExplore = !!(state.profile && (state.profile.deepen || []).length) ||
      !!(s && s.explore && ((s.explore.deepen || []).length || (s.explore.broaden || []).length));
    if (canExplore && !state.exploreData && !state.exploreLoading) loadExplore(false);
  }

  function closeExplore() {
    if (!state.initialized) return;
    state.exploreOpen = false;
    state.els.exploreModal.classList.remove('is-open');
    state.els.exploreModal.setAttribute('aria-hidden', 'true');
  }

  function setExploreTab(lane) {
    if (!lane) return;
    state.exploreTab = lane;
    if (state.els.exploreTabs) {
      state.els.exploreTabs.querySelectorAll('[data-lane]').forEach(function (b) {
        b.classList.toggle('is-active', b.getAttribute('data-lane') === lane);
      });
    }
    if (state.exploreOpen) renderExplore();
  }

  function exploreLaneLabel(lane) {
    return lane === 'broaden' ? '拓界' : lane === 'classic' ? '经典' : '深耕';
  }

  function exploreItemHtml(it) {
    const cover = '<span class="arch-cover__ph">B</span>' +
      (it.cover ? '<img src="' + esc(it.cover) + '" loading="lazy" referrerpolicy="no-referrer" alt="">' : '');
    const reasons = (it.exploreReasons || []).slice(0, 4).map(function (r) {
      return '<span class="tag">' + esc(r) + '</span>';
    }).join('');
    const meta = [
      it.author ? esc(it.author) : '',
      it.pubdate ? U.formatDate(it.pubdate) : '',
      it.views ? U.formatCount(it.views) + ' 播放' : '',
      it.favorites ? U.formatCount(it.favorites) + ' 收藏' : ''
    ].filter(Boolean).join(' · ');
    const laneClass = it.lane === 'broaden' ? ' explore-badge--broaden' :
      it.lane === 'classic' ? ' explore-badge--classic' : '';
    return '<div class="arch-item">' +
      '<a class="arch-cover" href="' + esc(it.url) + '" target="_blank" rel="noopener noreferrer">' +
        cover + '<span class="dur">' + esc(U.formatDuration(it.durationSec || 0)) + '</span>' +
      '</a>' +
      '<div class="arch-body">' +
        '<a class="arch-title" href="' + esc(it.url) + '" target="_blank" rel="noopener noreferrer">' + esc(it.title) + '</a>' +
        '<div class="arch-meta">' + meta + '</div>' +
        '<div class="arch-tags"><span class="tag tag--score">' + esc(String(it.exploreScore || 0)) + ' 分</span>' +
          '<span class="explore-badge' + laneClass + '">' + esc(exploreLaneLabel(it.lane)) + '</span>' +
          reasons +
        '</div>' +
      '</div>' +
      '<a class="arch-open" href="' + esc(it.url) + '" target="_blank" rel="noopener noreferrer">打开</a>' +
    '</div>';
  }

  function renderExplore() {
    if (!state.initialized || !state.exploreOpen) return;
    const p = state.profile;
    const d = state.diversity;
    const s = state.settings;
    if (state.els.exploreProfile) {
      let html = '';
      if (p) {
        const name = p.uname ? '@' + p.uname : '你的账号';
        html = '<b>' + esc(name) + '</b> · ' + esc(profileStatusText());
        if (p.sources) {
          html += '<br>读取：关注 ' + (p.sources.followings || 0) + ' · 收藏夹 ' + (p.sources.folders || 0) +
            ' · 收藏 ' + (p.sources.favorites || 0) +
            (p.sources.history ? ' · 最近观看 ' + p.sources.history : '');
        }
        if (p.deepen && p.deepen.length) html += '<br>深耕：' + esc(p.deepen.map(function (id) {
          const domain = BLF.Domains && BLF.Domains.get(id);
          return domain ? domain.label : id;
        }).join('、'));
        if (p.broaden && p.broaden.length) html += ' · 拓界：' + esc(p.broaden.map(function (id) {
          const domain = BLF.Domains && BLF.Domains.get(id);
          return domain ? domain.label : id;
        }).join('、'));
        const cal = BLF.Domains && d ? BLF.Domains.compareProfile(p.domains, d, 3) : null;
        if (cal && cal.blindspots.length) {
          html += '<br>画像盲区：' + esc(cal.blindspots.map(function (x) { return x.label; }).join('、'));
        }
        html += '<div class="explore-hint">画像只根据关注/收藏聚合，不保存原始列表；历史默认不读取。</div>';
      } else {
        html = '<b>还没有账号画像</b><br>可以同步账号，让插件按你的关注和收藏规划「深耕 / 拓界」；也可以在设置里手动选择领域。<div class="explore-hint">不需要登录也能手动使用探索。</div>';
      }
      state.els.exploreProfile.innerHTML = html;
    }
    if (state.els.exploreDiversity) {
      if (d && d.classified) {
        let line = '本页 ' + esc(d.top.label) + ' ' + Math.round(d.topShare * 100) +
          '% · 多样性 ' + (d.entropy || 0).toFixed(2) +
          (d.isCocoon ? ' · 单一领域偏多，建议换换脑子' : ' · 分布还算均衡');
        const cal = BLF.Domains && p ? BLF.Domains.compareProfile(p.domains, d, 2) : null;
        if (cal && (cal.over.length || cal.under.length)) {
          const bits = [];
          if (cal.over[0]) bits.push(cal.over[0].label + ' +' + Math.round(cal.over[0].delta * 100) + '%');
          if (cal.under[0]) bits.push(cal.under[0].label + ' ' + Math.round(cal.under[0].delta * 100) + '%');
          line += ' ｜ 画像校准：' + bits.join(' / ');
        }
        state.els.exploreDiversity.innerHTML =
          '<div class="diversity__bar"><i style="width:' + Math.round(d.topShare * 100) + '%"></i></div>' +
          '<div class="diversity__text">' + line + '</div>';
      } else {
        state.els.exploreDiversity.innerHTML = '<div class="diversity__text">本页可分类内容不足，先浏览一会儿再回来。</div>';
      }
    }
    if (state.els.exploreTabs) {
      state.els.exploreTabs.querySelectorAll('[data-lane]').forEach(function (b) {
        b.classList.toggle('is-active', b.getAttribute('data-lane') === state.exploreTab);
      });
    }
    if (state.els.exploreStatus) {
      if (state.exploreLoading) {
        state.els.exploreStatus.innerHTML = '<span class="spinner"></span> 正在生成深耕 / 拓界 / 经典三条路线…';
      } else if (state.exploreError) {
        state.els.exploreStatus.textContent = state.exploreError;
      } else if (state.exploreData) {
        const lanes = state.exploreData.lanes || {};
        const total = (lanes.deepen || []).length + (lanes.broaden || []).length + (lanes.classic || []).length;
        state.els.exploreStatus.textContent = '共 ' + total + ' 条 · 深耕 ' + (lanes.deepen || []).length +
          ' / 拓界 ' + (lanes.broaden || []).length + ' / 经典 ' + (lanes.classic || []).length +
          (state.exploreData.cached ? ' · 缓存' : '') +
          (state.exploreData.errors && state.exploreData.errors.length ? ' · 部分查询失败' : '');
      } else {
        state.els.exploreStatus.textContent = '';
      }
    }
    if (state.els.exploreResults) {
      if (state.exploreLoading && !state.exploreData) {
        state.els.exploreResults.innerHTML = '<div class="explore-empty">正在从 B 站搜索里找长内容…<br>不会上传你的账号数据。</div>';
        return;
      }
      if (state.exploreError) {
        state.els.exploreResults.innerHTML = '<div class="explore-empty">' +
          esc(state.exploreError) + '<br><br>' +
          '<button class="chip" data-action="explore-run">重试</button> ' +
          '<button class="chip" data-action="explore-settings">去设置兴趣</button>' +
        '</div>';
        return;
      }
      if (!state.exploreData) {
        state.els.exploreResults.innerHTML = '<div class="explore-empty">' +
          '<b>先建立一张兴趣地图</b><br>同步账号后，插件会按关注/收藏规划“深耕”和“拓界”；也可以手动选择领域。' +
          '<br><button class="chip" data-action="sync-profile">同步账号画像</button>' +
        '</div>';
        return;
      }
      const items = (state.exploreData.lanes || {})[state.exploreTab] || [];
      if (!items.length) {
        state.els.exploreResults.innerHTML = '<div class="explore-empty">' +
          '这一路暂时没有合适的长内容。<br>可以点「换一批」，或到设置里调整深耕/拓界领域。' +
        '</div>';
        return;
      }
      state.els.exploreResults.innerHTML = items.map(exploreItemHtml).join('');
    }
  }

  async function loadExplore(force) {
    if (state.exploreLoading) return;
    const cb = callbacks().onExplore;
    if (!cb) { toast('当前页面不支持探索', 'error'); return; }
    state.exploreLoading = true;
    state.exploreError = '';
    renderExplore();
    try {
      const data = await cb({ force: !!force });
      state.exploreData = data;
    } catch (err) {
      state.exploreError = (err && err.message) || '探索失败，请稍后再试';
    } finally {
      state.exploreLoading = false;
      renderExplore();
    }
  }

  function openArchaeology(topic, autorun) {
    if (!state.initialized) return;
    if (state.exploreOpen) closeExplore();
    state.archOpen = true;
    state.els.modal.classList.add('is-open');
    state.els.modal.setAttribute('aria-hidden', 'false');
    const q = (topic || state.pageInfo.topic || '').trim();
    state.els.modalInput.value = q;
    state.els.cutoff.value = state.settings.archaeology.cutoff;
    state.els.minDur.value = String(state.settings.archaeology.minDuration);
    updateFallback();
    setTimeout(function () {
      state.els.modalInput.focus();
      state.els.modalInput.select();
    }, 30);
    if (autorun && q) runArchaeology();
  }

  function closeArchaeology() {
    if (!state.initialized) return;
    state.archOpen = false;
    state.els.modal.classList.remove('is-open');
    state.els.modal.setAttribute('aria-hidden', 'true');
  }

  function updateFallback() {
    if (!state.initialized) return;
    const q = (state.els.modalInput.value || state.pageInfo.topic || '').trim();
    if (!q) { state.els.archFallback.setAttribute('href', '#'); return; }
    const cutoff = state.els.cutoff.value || (state.settings && state.settings.archaeology.cutoff) || '2021-12-31';
    const begin = (state.settings && state.settings.archaeology.begin) || '2009-01-01';
    const minDur = Number(state.els.minDur.value) || (state.settings && state.settings.archaeology.minDuration) || 600;
    const url = BLF.Archaeology.buildWebUrl({
      keyword: q,
      beginSec: U.toTs(begin, false),
      endSec: U.toTs(cutoff, true),
      duration: minDur >= 3600 ? 4 : ''
    });
    state.lastFallback = url;
    state.els.archFallback.href = url;
  }

  async function runArchaeology() {
    if (!state.initialized || state.archRunning) return;
    const topic = (state.els.modalInput.value || '').trim();
    if (!topic) {
      state.els.modalInput.focus();
      toast('先输入一个选题', 'error');
      return;
    }
    const opts = {
      cutoff: state.els.cutoff.value || state.settings.archaeology.cutoff,
      minDuration: Number(state.els.minDur.value) || state.settings.archaeology.minDuration || 600
    };
    updateFallback();
    state.archRunning = true;
    state.els.archRun.disabled = true;
    state.els.archRun.textContent = '检索中…';
    state.els.archStatus.innerHTML = '<span class="spinner"></span> 正在检索 B 站历史视频…';
    state.els.archResults.innerHTML = '';

    try {
      const result = await callbacks().onArchaeology(topic, opts);
      renderArchaeology(result, opts);
    } catch (err) {
      renderArchError(err, topic, opts);
    } finally {
      state.archRunning = false;
      state.els.archRun.disabled = false;
      state.els.archRun.textContent = '开始考古';
    }
  }

  function archProgress(page, pages) {
    if (!state.initialized || !state.archRunning) return;
    state.els.archStatus.innerHTML = '<span class="spinner"></span> 正在检索第 ' + page + '/' + pages + ' 页历史视频…';
  }

  function renderArchaeology(result, opts) {
    if (!result || !Array.isArray(result.items)) {
      state.els.archStatus.textContent = '没有拿到有效结果，请稍后重试。';
      return;
    }
    const items = result.items;
    const bits = [];
    bits.push('找到 ' + items.length + ' 个');
    if (result.candidateCount) bits.push('候选 ' + result.candidateCount);
    if (result.tooShort) bits.push('过短 ' + result.tooShort);
    if (result.tooNew) bits.push('太新 ' + result.tooNew);
    if (result.cached) bits.push('缓存');
    state.els.archStatus.textContent = bits.join(' · ');
    state.els.archSummary.textContent = '「' + result.query + '」· ' + (opts.minDuration >= 1800 ? '深度长视频' : '长视频') + ' · 综合排序';

    if (!items.length) {
      state.els.archResults.innerHTML = '<div class="arch-empty">没有找到符合条件的视频。<br>可以试试放宽年代或缩短时长要求，或者换一个更具体的选题。</div>';
      return;
    }

    state.els.archResults.innerHTML = items.map(function (it) {
      const cover = it.cover
        ? '<img src="' + esc(it.cover) + '" loading="lazy" referrerpolicy="no-referrer" alt="">'
        : '';
      const reasons = (it.archReasons || []).slice(0, 4).map(function (r) {
        const cls = /年$/.test(r) ? 'tag tag--old' : 'tag';
        return '<span class="' + cls + '">' + esc(r) + '</span>';
      }).join('');
      const meta = [
        it.author ? esc(it.author) : '',
        it.pubdate ? U.formatDate(it.pubdate) : '',
        it.views ? U.formatCount(it.views) + ' 播放' : '',
        it.favorites ? U.formatCount(it.favorites) + ' 收藏' : ''
      ].filter(Boolean).join(' · ');
      return '<div class="arch-item">' +
        '<a class="arch-cover" href="' + esc(it.url) + '" target="_blank" rel="noopener noreferrer">' +
          cover + '<span class="dur">' + esc(U.formatDuration(it.durationSec)) + '</span>' +
        '</a>' +
        '<div class="arch-body">' +
          '<a class="arch-title" href="' + esc(it.url) + '" target="_blank" rel="noopener noreferrer">' + esc(it.title) + '</a>' +
          '<div class="arch-meta">' + meta + '</div>' +
          '<div class="arch-tags"><span class="tag tag--score">' + esc(String(it.archScore)) + ' 分</span>' + reasons + '</div>' +
        '</div>' +
        '<a class="arch-open" href="' + esc(it.url) + '" target="_blank" rel="noopener noreferrer">打开</a>' +
      '</div>';
    }).join('');
  }

  function renderArchError(err, topic, opts) {
    const code = err && err.code;
    let msg = (err && err.message) || '考古失败，请稍后重试';
    if (code === -412) {
      msg = 'B 站风控拦截了这次批量搜索（-412）。休息 1 分钟再试，或直接在搜索页打开。';
    } else if (code === 'demo') {
      msg = '演示页不联网。正式安装扩展后，这里会显示真实的考古结果。';
    }
    state.els.archStatus.textContent = msg;
    const fallback = state.lastFallback || BLF.Archaeology.buildWebUrl({
      keyword: topic,
      endSec: U.toTs(opts.cutoff, true)
    });
    state.els.archResults.innerHTML = '<div class="arch-empty">' +
      '没有完成检索。<br><b>' + esc(msg) + '</b><br><br>' +
      '<button class="primary" data-action="open-fallback">在 B 站搜索页手动查看</button>' +
      '</div>';
    state.els.archFallback.href = fallback;
  }

  function toast(message, type) {
    if (!state.initialized) return;
    const el = state.els.toast;
    el.textContent = message;
    el.dataset.type = type || 'info';
    el.classList.add('is-show');
    clearTimeout(state._toastTimer);
    state._toastTimer = setTimeout(function () {
      el.classList.remove('is-show');
    }, 2600);
  }

  function openPopover(vm, rect) {
    if (!state.initialized || !vm) return;
    state.currentCard = vm;
    const labels = (vm.labels || []).slice(0, 4);
    const head = labels[0] || { text: '已标记', tone: 'blue' };
    const reasons = (vm.reasons && vm.reasons.length ? vm.reasons : labels.map(function (l) { return l.why; }))
      .filter(Boolean).slice(0, 4);
    const cluster = vm.cluster;
    const clusterHtml = cluster
      ? '<div class="pop__cluster">' + (cluster.isBest
        ? '同题共 <b>' + cluster.size + '</b> 个视频，这一条是当前推荐的最佳版本。'
        : '同题共 <b>' + cluster.size + '</b> 个视频，已为你保留更优版本：<b>' + esc(U.truncate(cluster.bestTitle || '', 42)) + '</b>') +
        '</div>'
      : '';
    const actions = [];
    actions.push('<button class="accent" data-action="' + (vm.revealed ? 'hide' : 'reveal') + '">' + (vm.revealed ? '收起' : '展开') + '</button>');
    if (vm.cluster && !vm.cluster.isBest && vm.bestUrl) {
      actions.push('<button data-action="open-best">看看最佳版本</button>');
    }
    actions.push('<button data-action="arch-topic">考古同题</button>');
    if (vm.canMute) actions.push('<button data-action="mute-similar">少看同类' + (vm.muteLabel ? ' · ' + esc(vm.muteLabel) : '') + '</button>');
    if (vm.canWhitelist) actions.push('<button data-action="whitelist">放行此 UP</button>');
    actions.push('<button class="danger" data-action="hide">隐藏</button>');
    actions.push('<button data-action="pop-close">关闭</button>');

    state.els.popover.innerHTML =
      '<div class="pop__head"><span class="pop__dot" data-tone="' + esc(head.tone || 'blue') + '"></span>' +
        '<span>' + esc(head.text) + '</span>' +
        '<button class="pop__close" data-action="pop-close" aria-label="关闭">' + ICON_CLOSE + '</button>' +
      '</div>' +
      '<div class="pop__title">' + esc(vm.title || '') + '</div>' +
      '<div class="pop__meta">' + esc([vm.author, U.formatDuration(vm.durationSec || 0)].filter(Boolean).join(' · ')) + '</div>' +
      (reasons.length ? '<div class="pop__reasons">' + reasons.map(function (r) {
        return '<div class="pop__reason">' + esc(r) + '</div>';
      }).join('') + '</div>' : '') +
      clusterHtml +
      '<div class="pop__actions">' + actions.join('') + '</div>';

    state.els.popover.hidden = false;
    positionPopover(rect);
  }

  function positionPopover(rect) {
    const el = state.els.popover;
    if (!rect) return;
    const margin = 12;
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    const w = 330;
    const h = Math.min(el.offsetHeight || 300, vh - 24);
    let left = rect.right + 12;
    if (left + w > vw - margin) left = rect.left - w - 12;
    if (left < margin) left = Math.min(vw - w - margin, Math.max(margin, rect.left));
    let top = rect.top;
    if (top + h > vh - margin) top = Math.max(margin, vh - h - margin);
    if (top < margin) top = margin;
    el.style.left = left + 'px';
    el.style.top = top + 'px';
  }

  function closePopover() {
    if (!state.initialized) return;
    state.els.popover.hidden = true;
    state.currentCard = null;
  }

  function updateCardPopover(vm) {
    if (!state.initialized || !state.currentCard || state.currentCard.id !== vm.id) return;
    const rect = state.currentCard.rect;
    openPopover(Object.assign({}, vm, { rect: rect }), rect);
  }

  function destroy() {
    document.removeEventListener('keydown', onKeydown, true);
    document.removeEventListener('click', onDocumentClick, true);
    window.removeEventListener('scroll', onScroll, true);
    window.removeEventListener('resize', closePopover, true);
    if (state.host && state.host.parentNode) state.host.parentNode.removeChild(state.host);
    state.initialized = false;
  }

  BLF.UI = {
    init: function (callbacks, settings, pageInfo) {
      state.callbacks = callbacks || {};
      state.settings = settings;
      state.pageInfo = Object.assign({}, state.pageInfo, pageInfo || {});
      if (!state.initialized) build();
      setSettings(settings);
      syncPanel();
      if (settings && settings.ui && settings.ui.panelCollapsed === false) openPanel();
      return state;
    },
    setSettings: setSettings,
    setStats: setStats,
    setPageInfo: setPageInfo,
    setPaused: setPaused,
    setProfile: setProfile,
    setDiversity: setDiversity,
    invalidateExplore: invalidateExplore,
    openExplore: openExplore,
    closeExplore: closeExplore,
    sync: syncPanel,
    openPanel: openPanel,
    closePanel: closePanel,
    togglePanel: togglePanel,
    openArchaeology: openArchaeology,
    closeArchaeology: closeArchaeology,
    archProgress: archProgress,
    toast: toast,
    openPopover: openPopover,
    updateCardPopover: updateCardPopover,
    closePopover: closePopover,
    isPanelOpen: function () { return state.panelOpen; },
    isPaused: function () { return state.paused; },
    destroy: destroy
  };
})(typeof globalThis !== 'undefined' ? globalThis : this);
