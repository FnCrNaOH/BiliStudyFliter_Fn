/* B站学习净化器 · 账号数据读取：登录态、关注、收藏夹、可选历史；只在内存聚合，原始列表不落盘 */
(function (root) {
  'use strict';
  const BLF = (root.BLF = root.BLF || {});
  const U = BLF.U;

  const API = 'https://api.bilibili.com';
  const PROFILE_KEY = 'blfProfile';
  const EXPLORE_CACHE = 'blfExploreCache';

  function makeError(message, code, extra) {
    const err = new Error(message);
    err.code = code || 'account-error';
    if (extra) Object.assign(err, extra);
    return err;
  }

  function qs(params) {
    const p = new URLSearchParams();
    Object.keys(params || {}).forEach(function (k) {
      if (params[k] !== undefined && params[k] !== null && params[k] !== '') p.set(k, String(params[k]));
    });
    return p.toString();
  }

  async function get(path, params) {
    const url = API + path + (params ? '?' + qs(params) : '');
    return BLF.Api.getJson(url, 'api');
  }

  async function sync(settings, options) {
    const opts = options || {};
    const progress = function (stage, detail, done, total) {
      if (opts.onProgress) opts.onProgress({ stage: stage, detail: detail || '', done: done || 0, total: total || 0 });
    };
    if (BLF.Store.isDemo) {
      throw makeError('演示页不联网：正式安装扩展并登录 B 站后才能同步画像', 'demo');
    }
    if (!settings || !settings.explore) throw makeError('配置未就绪', 'no-settings');

    let nav;
    try {
      progress('登录信息', '正在确认 B 站登录状态…');
      nav = await get('/x/web-interface/nav');
    } catch (e) {
      if (e && e.code === 'login-required') throw e;
      throw makeError('无法读取登录状态：' + (e && e.message ? e.message : '网络错误'), e && e.code);
    }
    if (!nav || !nav.isLogin) {
      throw makeError('请先在当前浏览器登录 B 站，再同步账号画像', 'login-required');
    }
    const mid = nav.mid;
    if (!mid) throw makeError('没有拿到账号 mid，请刷新 B 站后重试', 'no-mid');

    const followPages = Math.max(1, Math.min(8, Number(settings.explore.followPages) || 3));
    const tagMap = Object.create(null);
    try {
      progress('关注分组', '正在读取关注分组…');
      const tagData = await get('/x/relation/tags', { vmid: mid });
      const tagList = Array.isArray(tagData) ? tagData :
        (tagData && Array.isArray(tagData.list) ? tagData.list : []);
      tagList.forEach(function (t) {
        if (t && t.tagid !== undefined && t.name) tagMap[String(t.tagid)] = t.name;
      });
    } catch (e) { /* 分组不是必需 */ }
    const followings = [];
    for (let page = 1; page <= followPages; page++) {
      progress('关注列表', '第 ' + page + '/' + followPages + ' 页', page, followPages);
      let data;
      try {
        data = await get('/x/relation/followings', {
          vmid: mid,
          pn: page,
          ps: 50,
          order: 'desc',
          order_type: 'attention'
        });
      } catch (e) {
        if (page === 1) throw e;
        break;
      }
      const list = data && Array.isArray(data.list) ? data.list : [];
      list.forEach(function (f) {
        followings.push({
          mid: f.mid,
          uname: f.uname || '',
          sign: f.sign || '',
          tag: f.tag ? (tagMap[String(f.tag)] || f.tag) : '',
          official: f.official_verify || null
        });
      });
      if (list.length < 20) break;
      await U.sleep(380);
    }

    const folderLimit = Math.max(1, Math.min(12, Number(settings.explore.favFolders) || 8));
    progress('收藏夹', '正在读取收藏夹列表…');
    let folderList = [];
    try {
      const folderData = await get('/x/v3/fav/folder/created/list-all', { up_mid: mid });
      folderList = folderData && Array.isArray(folderData.list) ? folderData.list : [];
    } catch (e) {
      folderList = [];
    }
    folderList.sort(function (a, b) {
      return (Number(b.media_count) || 0) - (Number(a.media_count) || 0);
    });
    const folders = [];
    let favoriteCount = 0;
    const selected = folderList.slice(0, folderLimit);
    for (let i = 0; i < selected.length; i++) {
      const folder = selected[i];
      if (!folder || !folder.id) continue;
      if ((Number(folder.media_count) || 0) === 0) {
        folders.push({ id: folder.id, title: folder.title || '', media_count: 0, items: [] });
        continue;
      }
      progress('收藏夹', folder.title || ('收藏夹 ' + (i + 1)), i + 1, selected.length);
      let medias = [];
      try {
        const data = await get('/x/v3/fav/resource/list', {
          media_id: folder.id,
          pn: 1,
          ps: 20,
          platform: 'web'
        });
        medias = data && Array.isArray(data.medias) ? data.medias : [];
      } catch (e) {
        medias = [];
      }
      const items = medias.map(function (m) {
        return {
          title: m.title || '',
          intro: m.intro || m.description || '',
          duration: m.duration || 0,
          bvid: m.bvid || ''
        };
      });
      favoriteCount += items.length;
      folders.push({
        id: folder.id,
        title: folder.title || '',
        media_count: Number(folder.media_count) || items.length,
        items: items
      });
      await U.sleep(380);
    }

    let history = [];
    if (settings.explore.useHistory) {
      progress('观看历史', '正在读取最近观看…');
      try {
        const data = await get('/x/web-interface/history/cursor', { ps: 30, type: 'archive' });
        const list = data && Array.isArray(data.list) ? data.list : [];
        history = list.map(function (h) {
          return {
            title: h.title || '',
            author_name: h.author_name || '',
            duration: h.duration || 0
          };
        });
      } catch (e) {
        history = [];
      }
    }

    progress('聚合画像', '正在把关注与收藏映射到学科领域…');
    const profile = BLF.Profile.aggregate({
      nav: { mid: mid, uname: nav.uname || '' },
      followings: followings,
      folders: folders,
      history: history
    }, settings);
    profile.sources = {
      followings: followings.length,
      folders: folders.length,
      favorites: favoriteCount,
      history: history.length
    };
    profile.syncedAt = Date.now();
    await BLF.Store.set(PROFILE_KEY, profile);
    progress('完成', '画像已保存在本机', 1, 1);
    return profile;
  }

  async function load() {
    return BLF.Store.get(PROFILE_KEY, null);
  }

  async function clear() {
    await BLF.Store.remove(PROFILE_KEY);
    await BLF.Store.remove(EXPLORE_CACHE);
  }

  async function clearExploreCache() {
    await BLF.Store.remove(EXPLORE_CACHE);
  }

  BLF.Account = {
    sync: sync,
    load: load,
    clear: clear,
    clearExploreCache: clearExploreCache,
    makeError: makeError,
    ENDPOINTS: [
      '/x/web-interface/nav',
      '/x/relation/followings',
      '/x/v3/fav/folder/created/list-all',
      '/x/v3/fav/resource/list',
      '/x/web-interface/history/cursor'
    ]
  };
})(typeof globalThis !== 'undefined' ? globalThis : this);
