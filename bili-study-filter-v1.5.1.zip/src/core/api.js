/* B站学习净化器 · B 站搜索 API 客户端（通过 MAIN world 桥接，带缓存/退避） */
(function (root) {
  'use strict';
  const BLF = (root.BLF = root.BLF || {});
  const U = BLF.U;
  const A = BLF.Archaeology;

  const CACHE_KEY = 'blfArchCache';
  const MAX_CACHE = 40;

  let ready = false;
  let seq = 0;
  const pending = new Map();

  function ensureBridge() {
    if (ready) return;
    if (typeof window === 'undefined' || !window.addEventListener) return;
    ready = true;
    window.addEventListener('message', function (event) {
      if (event.source !== window) return;
      const data = event.data;
      if (!data || data.__blf !== 'res' || !data.id) return;
      const entry = pending.get(data.id);
      if (!entry) return;
      pending.delete(data.id);
      clearTimeout(entry.timer);
      entry.resolve(data);
    });
  }

  function requestBridge(url, type) {
    ensureBridge();
    return new Promise(function (resolve, reject) {
      if (typeof window === 'undefined' || typeof window.postMessage !== 'function') {
        reject(makeError('当前环境不支持网络请求', 'no-window'));
        return;
      }
      const id = 'req-' + Date.now().toString(36) + '-' + (++seq);
      const timer = setTimeout(function () {
        pending.delete(id);
        reject(makeError('B站接口响应超时，请稍后重试', 'timeout'));
      }, 15000);
      pending.set(id, { resolve: resolve, reject: reject, timer: timer });
      try {
        window.postMessage({ __blf: 'req', id: id, type: type || 'api', url: url }, '*');
      } catch (e) {
        clearTimeout(timer);
        pending.delete(id);
        reject(makeError('无法与页面通信', 'post-failed'));
      }
    });
  }

  function makeError(message, code, extra) {
    const err = new Error(message);
    err.code = code || 'unknown';
    if (extra) Object.assign(err, extra);
    return err;
  }

  async function searchPage(params) {
    const url = A.buildApiUrl(params);
    if (!url) throw makeError('关键词为空', 'empty-keyword');

    let last;
    for (let attempt = 0; attempt < 2; attempt++) {
      const res = await requestBridge(url, 'search');
      const code = res.code;
      if (res.ok && code === 0 && res.data) {
        return res.data;
      }
      last = res;
      if (code === -412 || res.httpStatus === 412) {
        await U.sleep(1400);
        continue;
      }
      break;
    }

    const reason = last && (last.message || last.biliMessage);
    if (last && (last.code === -412 || last.httpStatus === 412)) {
      throw makeError('B 站搜索触发了风控（-412），请稍后再试，或打开网页搜索', -412, {
        httpStatus: 412,
        url: url
      });
    }
    throw makeError(reason ? '搜索失败：' + reason : '搜索失败，请稍后重试',
      (last && last.code) || 'search-failed', { httpStatus: last && last.httpStatus, url: url });
  }

  /**
   * 读取 B 站账号类接口（nav / 关注 / 收藏夹 / 历史）。
   * 与页面的搜索请求一样，通过 MAIN world 桥以当前登录态发起。
   */
  async function getJson(url, type) {
    if (BLF.Store.isDemo) {
      throw makeError('演示页不联网：正式安装扩展后才能读取账号数据', 'demo');
    }
    let last;
    for (let attempt = 0; attempt < 2; attempt++) {
      const res = await requestBridge(url, type || 'api');
      if (res.ok && res.code === 0) return res.data;
      last = res;
      if (res.code === -412 || res.httpStatus === 412) {
        await U.sleep(1500);
        continue;
      }
      break;
    }
    if (last && (last.code === -101 || last.httpStatus === 401)) {
      throw makeError('需要先登录 B 站，才能读取账号画像', 'login-required', { status: last.httpStatus });
    }
    if (last && (last.code === -412 || last.httpStatus === 412)) {
      throw makeError('B 站风控拦截了账号数据请求（-412），请稍后再试', -412, { status: 412 });
    }
    throw makeError(last && last.message ? 'B 站接口返回：' + last.message : 'B 站接口请求失败',
      (last && last.code) || 'api-failed', { status: last && last.httpStatus, url: url });
  }

  function cacheKey(topic, settings) {
    const a = settings.archaeology;
    return [topic, a.begin, a.cutoff, a.minDuration, a.pages].join('|').toLowerCase();
  }

  async function loadCache() {
    const cache = await BLF.Store.get(CACHE_KEY, {});
    return cache && typeof cache === 'object' ? cache : {};
  }

  async function readCache(key, ttlHours) {
    const cache = await loadCache();
    const entry = cache[key];
    if (!entry || !entry.at) return null;
    if (Date.now() - entry.at > ttlHours * 3600 * 1000) return null;
    return entry.data;
  }

  async function writeCache(key, data) {
    const cache = await loadCache();
    cache[key] = { at: Date.now(), data: data };
    const keys = Object.keys(cache).sort(function (a, b) { return cache[b].at - cache[a].at; });
    keys.slice(MAX_CACHE).forEach(function (k) { delete cache[k]; });
    await BLF.Store.set(CACHE_KEY, cache);
  }

  /**
   * 考古搜索：按选题抓取 pre-cutoff 的长视频并排序。
   * @returns {Promise<{items:Array,total:number,query:string,cached:boolean}>}
   */
  async function archaeology(topic, settings, options) {
    const opts = options || {};
    if (BLF.Store.isDemo) {
      throw makeError('演示页不联网：正式安装扩展后即可考古', 'demo');
    }
    if (typeof window === 'undefined' || typeof window.postMessage !== 'function') {
      throw makeError('当前页面不支持考古搜索', 'no-window');
    }
    const query = BLF.Topic.cleanQuery(topic);
    if (!query) throw makeError('请先输入一个选题', 'empty-keyword');

    const key = cacheKey(query, settings);
    if (!opts.force) {
      const hit = await readCache(key, settings.archaeology.cacheHours);
      if (hit) return Object.assign({}, hit, { cached: true, query: query });
    }

    const beginSec = U.toTs(settings.archaeology.begin, false);
    const endSec = U.toTs(settings.archaeology.cutoff, true);
    const pages = Math.max(1, Math.min(3, Number(settings.archaeology.pages) || 2));
    const raw = [];
    let numResults = 0;

    for (let page = 1; page <= pages; page++) {
      if (opts.onProgress) opts.onProgress({ page: page, pages: pages, found: raw.length });
      const data = await searchPage({
        keyword: query,
        page: page,
        beginSec: beginSec,
        endSec: endSec,
        order: 'totalrank'
      });
      numResults = data.numResults || numResults;
      const list = Array.isArray(data.result) ? data.result : [];
      list.forEach(function (it) {
        const normalized = A.normalizeItem(it);
        if (normalized) raw.push(normalized);
      });
      if (list.length === 0) break;
      if (page < pages) await U.sleep(480);
    }

    const ranked = A.rank(raw, {
      cutoffTs: endSec,
      minDuration: settings.archaeology.minDuration,
      limit: settings.archaeology.results
    });

    const result = {
      items: ranked.items,
      total: ranked.total,
      candidateCount: raw.length,
      numResults: numResults,
      tooNew: ranked.tooNew,
      tooShort: ranked.tooShort,
      query: query,
      at: Date.now()
    };
    await writeCache(key, result);
    return Object.assign({}, result, { cached: false });
  }

  async function cacheCount() {
    const cache = await loadCache();
    return Object.keys(cache).length;
  }

  async function clearCache() {
    await BLF.Store.remove(CACHE_KEY);
  }

  BLF.Api = {
    archaeology: archaeology,
    searchPage: searchPage,
    getJson: getJson,
    requestBridge: requestBridge,
    cacheCount: cacheCount,
    clearCache: clearCache,
    makeError: makeError
  };
})(typeof globalThis !== 'undefined' ? globalThis : this);
