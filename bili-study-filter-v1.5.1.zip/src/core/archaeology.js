/* B站学习净化器 · 「考古模式」检索构造与排序（无 DOM 依赖） */
(function (root) {
  'use strict';
  const BLF = (root.BLF = root.BLF || {});
  const U = BLF.U;
  const K = BLF.Keywords;

  const API_BASE = 'https://api.bilibili.com/x/web-interface/search/type';
  const WEB_BASE = 'https://search.bilibili.com/all';

  function buildApiUrl(params) {
    const p = params || {};
    const keyword = String(p.keyword || '').trim();
    if (!keyword) return '';
    const qs = new URLSearchParams();
    qs.set('search_type', 'video');
    qs.set('keyword', keyword);
    qs.set('page', String(Math.max(1, Math.min(50, Number(p.page) || 1))));
    qs.set('order', p.order || 'totalrank');
    if (p.beginSec) qs.set('pubtime_begin_s', String(p.beginSec));
    if (p.endSec) qs.set('pubtime_end_s', String(p.endSec));
    if (p.duration) qs.set('duration', String(p.duration));
    qs.set('from_source', 'webtop_search');
    qs.set('spm_id_from', '333.1007');
    return API_BASE + '?' + qs.toString();
  }

  function buildWebUrl(params) {
    const p = params || {};
    const keyword = String(p.keyword || '').trim();
    const qs = new URLSearchParams();
    qs.set('keyword', keyword);
    qs.set('order', p.order || 'totalrank');
    if (p.beginSec) qs.set('pubtime_begin_s', String(p.beginSec));
    if (p.endSec) qs.set('pubtime_end_s', String(p.endSec));
    if (p.duration) qs.set('duration', String(p.duration));
    return WEB_BASE + '?' + qs.toString();
  }

  function normalizeItem(raw) {
    if (!raw) return null;
    const bvid = raw.bvid || '';
    const title = U.cleanText(raw.title || '');
    if (!title) return null;
    const durationSec = U.parseDuration(raw.duration);
    const cover = raw.pic || raw.cover || raw.user_cover || '';
    const url = bvid
      ? 'https://www.bilibili.com/video/' + bvid
      : (raw.arcurl || raw.url || '');
    return {
      id: bvid || String(raw.aid || raw.id || U.hashString(title)),
      bvid: bvid,
      title: title,
      author: U.cleanText(raw.author || raw.uname || ''),
      mid: raw.mid || raw.uid || 0,
      durationSec: durationSec,
      views: U.parseCount(raw.play || raw.view || 0),
      danmaku: U.parseCount(raw.video_review || raw.danmaku || 0),
      likes: U.parseCount(raw.like || 0),
      favorites: U.parseCount(raw.favorites || 0),
      pubdate: Number(raw.pubdate || raw.senddate || 0),
      description: U.cleanText(raw.description || raw.desc || ''),
      tags: U.cleanText(raw.tag || ''),
      typename: U.cleanText(raw.typename || ''),
      cover: cover ? (cover.indexOf('//') === 0 ? 'https:' + cover : cover) : '',
      url: url
    };
  }

  function scoreItem(item, opts) {
    const o = opts || {};
    const now = o.now || Date.now();
    const dur = item.durationSec || 0;
    const views = item.views || 0;
    const knowledge = K.isKnowledge(item.title,
      [item.title, item.description, item.tags, item.typename].filter(Boolean).join(' '));
    const clickbait = K.clickbait(item.title);
    const ageYears = U.ageYears(item.pubdate, now);
    const lecture = /(公开课|课程|讲座|MIT|Stanford|哈佛|牛津|剑桥|第[一二三四五六七八九十0-9]+讲)/.test(item.title);

    let score = 14;
    score += U.clamp(U.log10(1 + dur / 60) * 17, 0, 28);
    score += U.clamp(Math.log10(1 + views) * 1.8, 0, 9);

    if (views > 0) {
      score += U.clamp((item.favorites / views) * 260, 0, 18);
      score += U.clamp((item.likes / views) * 110, 0, 8);
      score += U.clamp((item.danmaku / views) * 200, 0, 4);
    }
    if (knowledge.core.length >= 2) score += 5;
    else if (knowledge.core.length === 1) score += 2;
    if (knowledge.markers.length) score += 2;
    if (lecture) score += 4;
    if (ageYears >= 8) score += 4;
    else if (ageYears >= 5) score += 2;
    score -= clickbait.score * 5;
    if (dur > 4 * 3600) score -= 2;
    if (!item.pubdate) score -= 10;

    const reasons = [];
    if (item.pubdate) reasons.push(U.formatDate(item.pubdate).slice(0, 4) + ' 年');
    reasons.push(U.formatDuration(dur));
    if (views > 0 && item.favorites / views >= 0.02) {
      reasons.push('收藏率 ' + (item.favorites / views * 100).toFixed(1) + '%');
    } else if (views > 0) {
      reasons.push(U.formatCount(views) + ' 播放');
    }
    if (lecture) reasons.push('课程/讲座');
    if (knowledge.core.length >= 2) reasons.push('知识密度高');
    if (ageYears >= 8) reasons.push('黄金年代');

    return {
      score: Math.round(U.clamp(score, 0, 100)),
      reasons: reasons,
      ageYears: Math.round(ageYears * 10) / 10,
      knowledge: knowledge,
      clickbait: clickbait
    };
  }

  function rank(items, opts) {
    const o = opts || {};
    const cutoffTs = o.cutoffTs || U.toTs('2021-12-31', true);
    const minDuration = Math.max(0, Number(o.minDuration) || 0);
    const limit = Math.max(1, Number(o.limit) || 12);
    const now = o.now || Date.now();
    const seen = Object.create(null);
    const filtered = [];
    let tooNew = 0;
    let tooShort = 0;

    (items || []).forEach(function (item) {
      if (!item || !item.title || !item.bvid) return;
      if (seen[item.bvid]) return;
      if (!item.pubdate || item.pubdate > cutoffTs) { tooNew++; return; }
      if (!item.durationSec || item.durationSec < minDuration) { tooShort++; return; }
      seen[item.bvid] = true;
      const scored = scoreItem(item, { now: now });
      filtered.push(Object.assign({}, item, {
        archScore: scored.score,
        archReasons: scored.reasons,
        ageYears: scored.ageYears
      }));
    });

    filtered.sort(function (a, b) {
      if (b.archScore !== a.archScore) return b.archScore - a.archScore;
      return (b.views || 0) - (a.views || 0);
    });

    return {
      items: filtered.slice(0, limit),
      total: filtered.length,
      tooNew: tooNew,
      tooShort: tooShort
    };
  }

  BLF.Archaeology = {
    API_BASE: API_BASE,
    WEB_BASE: WEB_BASE,
    buildApiUrl: buildApiUrl,
    buildWebUrl: buildWebUrl,
    normalizeItem: normalizeItem,
    scoreItem: scoreItem,
    rank: rank
  };
})(typeof globalThis !== 'undefined' ? globalThis : this);
