/* B站学习净化器 · 同质选题聚类（无 DOM 依赖） */
(function (root) {
  'use strict';
  const BLF = (root.BLF = root.BLF || {});
  const U = BLF.U;
  const Topic = BLF.Topic;
  const K = BLF.Keywords;

  function bigramSet(title) {
    const set = new Set();
    const text = U.cleanText(title).normalize('NFKC');
    const runs = text.match(/[\u4e00-\u9fa5]+/g) || [];
    runs.forEach(function (run) {
      for (let i = 0; i + 2 <= run.length; i++) {
        const gram = run.slice(i, i + 2);
        if (K.TOPIC_STOP_GRAMS.has(gram) || K.TOPIC_GENERIC_GRAMS.has(gram)) continue;
        if (K.STOP_CHARS.indexOf(gram[0]) !== -1 && K.STOP_CHARS.indexOf(gram[1]) !== -1) continue;
        set.add(gram);
      }
    });
    const latin = text.toLowerCase().match(/[a-z][a-z0-9+#.]{1,}/g) || [];
    latin.forEach(function (w) { if (w.length >= 2) set.add(w); });
    return set;
  }

  function unionFind(n) {
    const parent = new Array(n);
    const rank = new Array(n).fill(0);
    for (let i = 0; i < n; i++) parent[i] = i;
    function find(x) {
      while (parent[x] !== x) {
        parent[x] = parent[parent[x]];
        x = parent[x];
      }
      return x;
    }
    function union(a, b) {
      let ra = find(a);
      let rb = find(b);
      if (ra === rb) return;
      if (rank[ra] < rank[rb]) { const t = ra; ra = rb; rb = t; }
      parent[rb] = ra;
      if (rank[ra] === rank[rb]) rank[ra]++;
    }
    return { find: find, union: union };
  }

  function termDf(items) {
    const df = new Map();
    const perItem = [];
    items.forEach(function (item) {
      const map = Topic.candidateMap(item.title || '');
      const terms = new Set();
      map.forEach(function (c) {
        if (c.len >= 2 || c.term === '熵') terms.add(c.term);
      });
      perItem.push(terms);
      terms.forEach(function (t) { df.set(t, (df.get(t) || 0) + 1); });
    });
    return { df: df, perItem: perItem };
  }

  function analyze(items, options) {
    const opts = options || {};
    const minSize = Math.max(2, Number(opts.minSize) || 3);
    const list = (items || []).filter(function (it) { return it && it.id && it.title; }).slice(0, 120);
    const result = { groups: [], byId: Object.create(null), eligibleCount: list.length };
    if (list.length < minSize) return result;

    const n = list.length;
    const maxDf = Math.max(minSize + 1, Math.floor(n * 0.45));
    const { df, perItem } = termDf(list);

    const candidates = [];
    df.forEach(function (count, term) {
      if (count < minSize || count > maxDf) return;
      if (term.length < 2 && term !== '熵') return;
      if (K.CLUSTER_STOP_TERMS && K.CLUSTER_STOP_TERMS.has(term)) return;
      if (K.clickbait(term).score > 0) return;
      const weight = Math.pow(term.length, 1.6) * Math.log2(1 + count);
      candidates.push({ term: term, df: count, weight: weight });
    });
    candidates.sort(function (a, b) { return b.weight - a.weight; });
    const candMap = new Map(candidates.map(function (c) { return [c.term, c]; }));

    if (!candidates.length) return result;

    const topTerms = perItem.map(function (set) {
      const arr = [];
      set.forEach(function (t) { if (candMap.has(t)) arr.push(candMap.get(t)); });
      arr.sort(function (a, b) { return b.weight - a.weight; });
      return arr.slice(0, 3);
    });

    const uf = unionFind(n);

    // 共享候选主题词即并为一组（每个 item 只看自己最强的 2 个主题词，避免链式合并）
    const owners = new Map();
    topTerms.forEach(function (terms, idx) {
      terms.slice(0, 2).forEach(function (c) {
        if (!owners.has(c.term)) owners.set(c.term, []);
        owners.get(c.term).push(idx);
      });
    });
    owners.forEach(function (idxs) {
      for (let i = 1; i < idxs.length; i++) uf.union(idxs[0], idxs[i]);
    });

    // 近似重复标题（改写/搬运）直接合并
    const bigrams = list.map(function (it) { return bigramSet(it.title); });
    for (let i = 0; i < n; i++) {
      for (let j = i + 1; j < n; j++) {
        if (U.titleSimilarity(bigrams[i], bigrams[j]) >= 0.58) uf.union(i, j);
      }
    }

    const rawGroups = new Map();
    for (let i = 0; i < n; i++) {
      const r = uf.find(i);
      if (!rawGroups.has(r)) rawGroups.set(r, []);
      rawGroups.get(r).push(i);
    }

    const clusters = [];
    rawGroups.forEach(function (idxs) {
      if (idxs.length > Math.max(8, Math.floor(n * 0.7))) {
        // 过大组按最强主题词拆分，防止“物理”这类上位词把整页吞掉
        const byTop = new Map();
        idxs.forEach(function (idx) {
          const top = topTerms[idx][0];
          const key = top ? top.term : 'misc-' + idx;
          if (!byTop.has(key)) byTop.set(key, []);
          byTop.get(key).push(idx);
        });
        byTop.forEach(function (sub) { if (sub.length >= minSize) clusters.push(sub); });
      } else if (idxs.length >= minSize) {
        clusters.push(idxs);
      }
    });

    const groups = [];
    clusters.forEach(function (idxs) {
      const members = idxs.map(function (i) { return list[i]; });
      members.sort(function (a, b) {
        if ((b.quality || 0) !== (a.quality || 0)) return (b.quality || 0) - (a.quality || 0);
        return (b.durationSec || 0) - (a.durationSec || 0);
      });
      const best = members[0];
      const termCount = new Map();
      idxs.forEach(function (idx) {
        topTerms[idx].forEach(function (c) { termCount.set(c.term, (termCount.get(c.term) || 0) + 1); });
      });
      let label = '';
      let bestWeight = 0;
      termCount.forEach(function (count, term) {
        if (count < minSize) return;
        const c = candMap.get(term);
        if (c && c.weight > bestWeight) { bestWeight = c.weight; label = term; }
      });
      if (!label) label = Topic.fromTitle(best.title) || '同题';
      label = label.slice(0, 14);

      const id = 'c-' + U.hashString(label + '|' + best.id);
      const group = {
        id: id,
        label: label,
        size: members.length,
        itemIds: members.map(function (m) { return m.id; }),
        bestId: best.id,
        bestTitle: best.title,
        bestBvid: best.bvid || '',
        bestUrl: best.url || '',
        bestAuthor: best.author || '',
        bestDuration: best.durationSec || 0
      };
      groups.push(group);
    });

    groups.sort(function (a, b) { return b.size - a.size; });

    const out = [];
    groups.forEach(function (g) {
      if (g.size < minSize) return;
      out.push(g);
      g.itemIds.forEach(function (id) {
        const isBest = id === g.bestId;
        result.byId[id] = {
          groupId: g.id,
          label: g.label,
          size: g.size,
          bestId: g.bestId,
          bestTitle: g.bestTitle,
          bestBvid: g.bestBvid,
          bestUrl: g.bestUrl,
          bestAuthor: g.bestAuthor,
          isBest: isBest
        };
      });
    });
    result.groups = out;
    return result;
  }

  BLF.Cluster = {
    analyze: analyze,
    bigramSet: bigramSet
  };
})(typeof globalThis !== 'undefined' ? globalThis : this);
