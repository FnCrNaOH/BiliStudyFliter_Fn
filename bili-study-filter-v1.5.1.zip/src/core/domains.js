/* B站学习净化器 · 领域地图：把标题/收藏夹/关注签名映射到可解释的学科领域 */
(function (root) {
  'use strict';
  const BLF = (root.BLF = root.BLF || {});
  const U = BLF.U;

  const LIST = [
    {
      id: 'math', label: '数学', color: '#5b8def',
      keywords: ['数学', '高数', '高等数学', '线性代数', '概率论', '微积分', '几何', '代数', '数论', '拓扑', '统计学', '傅里叶', '拉普拉斯', '方程', '定理', '证明', '矩阵', '向量', '积分', '导数', '数学分析', '运筹学', '集合论', '数理逻辑', '概率', '数列'],
      adjacent: ['physics', 'cs', 'humanities', 'social']
    },
    {
      id: 'physics', label: '物理', color: '#7c5cff',
      keywords: ['物理', '量子', '相对论', '力学', '电磁', '热力学', '光学', '粒子', '凝聚态', '弦论', '麦克斯韦', '薛定谔', '牛顿', '爱因斯坦', '费曼', '熵', '能量守恒', '引力', '核聚变', '超导'],
      adjacent: ['math', 'cosmos', 'engineering', 'humanities']
    },
    {
      id: 'cs', label: '计算机', color: '#00aeec',
      keywords: ['计算机', '编程', '代码', '算法', '数据结构', '人工智能', '机器学习', '深度学习', '神经网络', '操作系统', '数据库', '网络安全', '密码学', '芯片', '半导体', '软件', '程序', 'Python', 'Java', 'C++', 'Linux', 'Git', 'ChatGPT', '大模型', '编译原理', '分布式', '云计算', '前端', '后端', '开源', '编程语言', '信息论', '香农', '图灵', 'AIGC', 'AI'],
      adjacent: ['math', 'engineering', 'design', 'psychology']
    },
    {
      id: 'biology', label: '生物/医学', color: '#3dd68c',
      keywords: ['生物', '医学', '细胞', '基因', 'DNA', '蛋白质', '免疫', '病毒', '神经科学', '脑科学', '解剖', '进化论', '生态学', '临床', '药理', '微生物', '遗传', '生理', '疫苗', '癌症', '肠道菌群'],
      adjacent: ['chemistry', 'psychology', 'life', 'cosmos']
    },
    {
      id: 'chemistry', label: '化学/材料', color: '#2ec4b6',
      keywords: ['化学', '元素', '分子', '原子', '化学反应', '有机化学', '无机化学', '材料', '纳米', '催化', '电池', '高分子', '电化学', '晶体', '化合物'],
      adjacent: ['physics', 'biology', 'engineering']
    },
    {
      id: 'engineering', label: '工程/技术', color: '#f4a261',
      keywords: ['工程', '机械', '电子', '电路', '机器人', '制造', '航空', '航天', '汽车', '能源', '建筑', '土木', '控制', '自动化', '无人机', '3D打印', '传感器', '发动机', '桥梁', '芯片制造'],
      adjacent: ['physics', 'cs', 'design', 'life']
    },
    {
      id: 'cosmos', label: '宇宙/地球', color: '#4f86f7',
      keywords: ['宇宙', '天文', '星系', '黑洞', '行星', '地球', '地质', '海洋', '气候', '环境', '空间站', '火星', '月球', '太阳系', '天体', '陨石', '地震', '火山'],
      adjacent: ['physics', 'biology', 'humanities']
    },
    {
      id: 'humanities', label: '人文/历史', color: '#e9c46a',
      keywords: ['历史', '哲学', '文学', '艺术', '音乐', '美术', '电影', '戏剧', '文化', '宗教', '考古', '诗词', '小说', '美学', '思想', '伦理', '古希腊', '文艺复兴', '启蒙运动', '人类简史', '文明', '博物馆', '古典'],
      adjacent: ['social', 'psychology', 'design', 'cosmos']
    },
    {
      id: 'social', label: '社科/经济', color: '#fb7299',
      keywords: ['经济', '金融', '社会', '政治', '法律', '教育', '管理', '商业', '投资', '货币', '市场', '博弈论', '人类学', '传播学', '国际关系', '社会学', '财政', '股票', '宏观经济', '微观经济', '劳动', '城市化'],
      adjacent: ['humanities', 'math', 'psychology', 'cs']
    },
    {
      id: 'psychology', label: '心理/认知', color: '#b18cff',
      keywords: ['心理', '认知', '意识', '情绪', '行为', '精神', '冥想', '睡眠', '记忆', '注意力', '决策', '社会心理', '人格', '成瘾', '习惯', '脑机接口'],
      adjacent: ['biology', 'social', 'humanities', 'life']
    },
    {
      id: 'design', label: '设计/艺术', color: '#ff9f43',
      keywords: ['设计', '绘画', '摄影', '视觉', 'UI', 'UX', '交互设计', '工业设计', '动画', '创意', '排版', '色彩', '平面设计', '产品设计', '游戏设计', '建筑美学', '字体'],
      adjacent: ['humanities', 'engineering', 'cs', 'entertainment']
    },
    {
      id: 'language', label: '语言/学习', color: '#8ecae6',
      keywords: ['英语', '日语', '语言', '翻译', '单词', '语法', '写作', '阅读', '考研', '考试', '读书', '学习方法', '笔记', '记忆法', '口语', '听力'],
      adjacent: ['humanities', 'social', 'psychology']
    },
    {
      id: 'gaming', label: '游戏', color: '#ff5c8a',
      keywords: ['游戏', '王者荣耀', '原神', '英雄联盟', '手游', '电竞', '主机', 'Steam', 'Switch', 'PS5', '攻略', '实况', '抽卡', '五杀', '开黑', '上分', '独立游戏', '游戏史', '速通'],
      adjacent: ['design', 'cs', 'psychology', 'humanities']
    },
    {
      id: 'entertainment', label: '娱乐', color: '#f28482',
      keywords: ['搞笑', '鬼畜', '综艺', '明星', '短剧', '影视解说', '舞蹈', '翻唱', '萌宠', '美食', '旅游', '穿搭', '美妆', 'vlog', '娱乐', '沙雕', '整活', '抽象', '吃瓜', '八卦', '段子', '脱口秀'],
      adjacent: ['humanities', 'design', 'language', 'life']
    },
    {
      id: 'life', label: '生活/健康', color: '#84a98c',
      keywords: ['健康', '健身', '运动', '饮食', '减肥', '睡眠', '生活', '效率', '时间管理', '收纳', '手工', '情感', '恋爱', '职场', '理财', '装修', '育儿', '养生'],
      adjacent: ['psychology', 'biology', 'social']
    }
  ];

  const BY_ID = Object.create(null);
  LIST.forEach(function (d) { BY_ID[d.id] = d; });

  function asciiWord(term) {
    return /^[a-z0-9+#.]+$/i.test(term);
  }

  function hit(text, term) {
    const t = text.toLowerCase();
    const k = String(term).toLowerCase();
    if (asciiWord(term)) {
      const re = new RegExp('(^|[^a-z0-9])' + U.escapeRegExp(k) + '($|[^a-z0-9])', 'i');
      return re.test(text);
    }
    return t.indexOf(k) !== -1;
  }

  /**
   * 返回按得分排序的领域数组：{id,label,color,score,share,hits}
   */
  function classify(text) {
    const input = U.cleanText(text || '');
    if (!input) return [];
    const results = [];
    LIST.forEach(function (d) {
      let score = 0;
      const hits = [];
      d.keywords.forEach(function (kw) {
        if (hit(input, kw)) {
          score += kw.length >= 4 ? 2.2 : kw.length >= 3 ? 1.7 : 1.2;
          hits.push(kw);
        }
      });
      if (hit(input, d.label)) {
        score += 2;
        if (hits.indexOf(d.label) === -1) hits.push(d.label);
      }
      if (score > 0) {
        results.push({ id: d.id, label: d.label, color: d.color, score: score, hits: hits.slice(0, 6) });
      }
    });
    const total = results.reduce(function (s, r) { return s + r.score; }, 0);
    results.forEach(function (r) { r.share = total ? r.score / total : 0; });
    results.sort(function (a, b) { return b.score - a.score; });
    return results;
  }

  function topDomain(text) {
    const r = classify(text);
    return r.length ? r[0] : null;
  }

  /**
   * 当前页面/信息流的领域分布与“信息茧房”指标。
   */
  function diversity(titles, threshold) {
    const list = (titles || []).filter(Boolean);
    const counts = Object.create(null);
    const labels = Object.create(null);
    let classified = 0;
    list.forEach(function (title) {
      const top = topDomain(title);
      if (!top) return;
      classified++;
      counts[top.id] = (counts[top.id] || 0) + 1;
      labels[top.id] = top.label;
    });
    const entries = Object.keys(counts).map(function (id) {
      return { id: id, label: labels[id], count: counts[id] };
    }).sort(function (a, b) { return b.count - a.count; });
    const top = entries[0] || null;
    const topShare = classified && top ? top.count / classified : 0;
    let entropy = 0;
    if (classified && entries.length > 1) {
      entries.forEach(function (e) {
        const p = e.count / classified;
        entropy -= p * Math.log(p);
      });
      entropy = entropy / Math.log(entries.length);
    }
    const th = Number(threshold) || 0.65;
    return {
      total: list.length,
      classified: classified,
      counts: entries,
      top: top,
      topShare: Math.round(topShare * 1000) / 1000,
      entropy: Math.round(entropy * 1000) / 1000,
      isCocoon: classified >= 6 && topShare >= th,
      threshold: th
    };
  }

  /**
   * 画像校准：把账号画像的领域占比和当前页面分布对比。
   * 返回“本页比画像多/少”的领域，以及画像里没有、本页也没有的“盲区”。
   */
  function compareProfile(profileDomains, feedDiversity, limit) {
    if (!profileDomains || !profileDomains.length || !feedDiversity || !feedDiversity.classified) return null;
    const n = limit || 3;
    const profileMap = Object.create(null);
    profileDomains.forEach(function (d) {
      profileMap[d.id] = d.share || 0;
    });
    const feedMap = Object.create(null);
    (feedDiversity.counts || []).forEach(function (c) {
      feedMap[c.id] = c.count / feedDiversity.classified;
    });
    const ids = [];
    const add = function (id) { if (id && ids.indexOf(id) === -1) ids.push(id); };
    profileDomains.slice(0, 6).forEach(function (d) { add(d.id); });
    (feedDiversity.counts || []).slice(0, 4).forEach(function (c) { add(c.id); });

    const deltas = ids.map(function (id) {
      const d = BY_ID[id];
      return {
        id: id,
        label: d ? d.label : id,
        profileShare: profileMap[id] || 0,
        feedShare: feedMap[id] || 0,
        delta: Math.round(((feedMap[id] || 0) - (profileMap[id] || 0)) * 1000) / 1000
      };
    });
    const over = deltas.filter(function (d) { return d.delta >= 0.15; })
      .sort(function (a, b) { return b.delta - a.delta; }).slice(0, n);
    const under = deltas.filter(function (d) { return d.delta <= -0.15; })
      .sort(function (a, b) { return a.delta - b.delta; }).slice(0, n);

    const topProfile = profileDomains.slice(0, 3).map(function (d) { return d.id; });
    const blind = suggestBroaden(topProfile, 4).filter(function (id) {
      return (profileMap[id] || 0) < 0.03 && (feedMap[id] || 0) < 0.03;
    }).slice(0, n).map(function (id) {
      const d = BY_ID[id];
      return { id: id, label: d ? d.label : id };
    });

    return { over: over, under: under, blindspots: blind };
  }

  function get(id) {
    return BY_ID[id] || null;
  }

  function validIds(ids) {
    const seen = Object.create(null);
    const out = [];
    (Array.isArray(ids) ? ids : []).forEach(function (id) {
      if (BY_ID[id] && !seen[id]) {
        seen[id] = true;
        out.push(id);
      }
    });
    return out;
  }

  function labelsOf(ids) {
    return validIds(ids).map(function (id) { return BY_ID[id].label; });
  }

  function suggestDeepen(domains, limit) {
    const ids = (domains || []).map(function (d) { return typeof d === 'string' ? d : d.id; });
    const studies = ids.filter(function (id) { return id !== 'gaming' && id !== 'entertainment'; });
    return (studies.length ? studies : ids).slice(0, limit || 2);
  }

  function suggestBroaden(domains, limit) {
    const ids = validIds((domains || []).map(function (d) { return typeof d === 'string' ? d : d.id; }));
    const top = ids.slice(0, 3);
    const out = [];
    ids.slice(0, 2).forEach(function (id) {
      const d = BY_ID[id];
      if (!d) return;
      d.adjacent.forEach(function (adj) {
        if (top.indexOf(adj) === -1 && out.indexOf(adj) === -1) out.push(adj);
      });
    });
    const fallback = ['humanities', 'biology', 'engineering', 'psychology', 'design'];
    fallback.forEach(function (id) {
      if (out.length < (limit || 2) && top.indexOf(id) === -1 && out.indexOf(id) === -1) out.push(id);
    });
    return out.slice(0, limit || 2);
  }

  BLF.Domains = {
    LIST: LIST,
    BY_ID: BY_ID,
    classify: classify,
    topDomain: topDomain,
    diversity: diversity,
    compareProfile: compareProfile,
    get: get,
    validIds: validIds,
    labelsOf: labelsOf,
    suggestDeepen: suggestDeepen,
    suggestBroaden: suggestBroaden
  };
})(typeof globalThis !== 'undefined' ? globalThis : this);
