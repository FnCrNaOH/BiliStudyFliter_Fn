/* B站学习净化器 · 兴趣探索：从账号画像生成「深耕 / 拓界 / 经典」三条探索路线 */
(function (root) {
  'use strict';
  const BLF = (root.BLF = root.BLF || {});
  const U = BLF.U;
  const Domains = BLF.Domains;
  const A = BLF.Archaeology;

  const CACHE_KEY = 'blfExploreCache';
  const MAX_CACHE = 24;

  function labelOf(id) {
    const d = Domains.get(id);
    return d ? d.label : id;
  }

  function searchLabelOf(id) {
    const d = Domains.get(id);
    return d ? d.label.split('/')[0] : id;
  }

  function validTargets(profile, settings) {
    const deepSetting = Domains.validIds(settings.explore && settings.explore.deepen);
    const broadSetting = Domains.validIds(settings.explore && settings.explore.broaden);
    const deepen = Domains.validIds(
      (deepSetting.length ? deepSetting : null) ||
      (profile && profile.deepen && profile.deepen.length ? profile.deepen : null) ||
      (profile && profile.domains ? profile.domains.map(function (d) { return d.id; }) : [])
    ).slice(0, 2);
    let broaden = Domains.validIds(
      (broadSetting.length ? broadSetting : null) ||
      (profile && profile.broaden && profile.broaden.length ? profile.broaden : null) ||
      []
    );
    if (!broaden.length) broaden = Domains.suggestBroaden(deepen, 2);
    broaden = broaden.filter(function (id) { return deepen.indexOf(id) === -1; }).slice(0, 2);
    return { deepen: deepen, broaden: broaden };
  }

  function buildQueries(profile, settings) {
    const targets = validTargets(profile, settings);
    const topics = (profile && profile.topTopics) || [];
    const queries = [];
    const seen = Object.create(null);
    const push = function (q) {
      if (!q.keyword || seen[q.keyword]) return;
      if (queries.length >= 5) return;
      seen[q.keyword] = true;
      queries.push(q);
    };

    if (targets.deepen.length) {
      if (topics[0]) {
        push({
          lane: 'deepen',
          keyword: topics[0] + ' 深度 讲解',
          targetIds: targets.deepen,
          minDuration: 900,
          order: 'totalrank'
        });
      }
      push({
        lane: 'deepen',
        keyword: searchLabelOf(targets.deepen[0]) + ' 大学 公开课 讲座',
        targetIds: [targets.deepen[0]],
        minDuration: 900,
        order: 'totalrank'
      });
    }
    targets.broaden.forEach(function (id) {
      push({
        lane: 'broaden',
        keyword: searchLabelOf(id) + ' 通识 讲座 公开课',
        targetIds: [id],
        minDuration: 480,
        order: 'totalrank'
      });
    });
    const classicKeyword = topics[0]
      ? topics[0] + ' 经典 科普'
      : (targets.broaden[0] ? searchLabelOf(targets.broaden[0]) + ' 经典 科普' : '');
    const classicTargets = [];
    var addTarget = function (id) { if (id && classicTargets.indexOf(id) === -1) classicTargets.push(id); };
    targets.deepen.concat(targets.broaden).forEach(addTarget);
    ((profile && profile.domains) || []).slice(0, 3).forEach(function (d) { addTarget(d.id); });
    Domains.classify(topics.join(' ')).slice(0, 3).forEach(function (d) { addTarget(d.id); });
    push({
      lane: 'classic',
      keyword: classicKeyword,
      targetIds: classicTargets.slice(0, 6),
      minDuration: 600,
      beginSec: U.toTs(settings.archaeology.begin, false),
      endSec: U.toTs(settings.archaeology.cutoff, true),
      order: 'totalrank'
    });
    return queries;
  }

  function scoreItem(item, lane, targets, profile, settings) {
    const title = item.title || '';
    const domainText = [title, item.tags, item.typename].filter(Boolean).join(' ');
    const domains = Domains.classify(domainText);
    const ids = domains.map(function (d) { return d.id; });
    const targetHit = ids.some(function (id) { return targets.indexOf(id) !== -1; });
    if (lane !== 'classic' && !targetHit && !(profile && (profile.topTopics || []).some(function (t) { return title.indexOf(t) !== -1; }))) {
      return null;
    }
    if (lane === 'classic' && !targetHit) return null;

    let decision;
    try {
      decision = BLF.Scoring.analyze(item, settings);
    } catch (e) {
      decision = { severity: 'none', quality: 50 };
    }
    if (decision.severity === 'high') return null;

    const dur = item.durationSec || 0;
    const views = item.views || 0;
    const knowledgeText = [title, item.description, item.tags, item.typename].filter(Boolean).join(' ');
    const knowledge = BLF.Keywords.isKnowledge(title, knowledgeText);
    const clickbait = BLF.Keywords.clickbait(title);
    const slop = BLF.Keywords.slopSignals(title, knowledgeText);
    const profileTop = profile && profile.domains
      ? profile.domains.slice(0, 3).map(function (d) { return d.id; })
      : [];

    const k12 = /(小学|初中|高中|中考|高考|八年级|七年级|九年级|初二|初三|高一|高二|高三|义务教育|人教版|北师大版|同步课程|教材解读|课程标准|从小学到大学|儿童|幼儿|少儿|亲子|小朋友|3-15岁)/.test(title);
    const advanced = /(大学|高等|进阶|研究生|MIT|Stanford|哈佛|公开课|讲座|论文|证明|推导|系统讲解|硬核)/.test(title);
    const advice = /(准大一|大一规划|志愿填报|专业选择|自救指南|避坑|就业|考研规划|留学中介)/.test(title);
    const topicHit = !!(profile && Array.isArray(profile.topTopics) &&
      profile.topTopics.some(function (t) { return t && title.indexOf(t) !== -1; }));

    let score = 20;
    if (targetHit) score += 20;
    if (topicHit) score += 10;
    if (lane === 'deepen' && ids.some(function (id) { return profileTop.indexOf(id) !== -1; })) score += 6;
    if (lane === 'broaden' && ids.some(function (id) { return profileTop.indexOf(id) !== -1; })) score -= 12;
    if (lane === 'classic') score += U.clamp(U.ageYears(item.pubdate) * 1.0, 0, 7);

    score += U.clamp(Math.log10(1 + dur / 60) * 8, 0, 14);
    score += U.clamp(Math.log10(1 + views) * 1.0, 0, 5);
    if (views > 0) {
      score += U.clamp((item.favorites / views) * 140, 0, 12);
      score += U.clamp((item.likes / views) * 50, 0, 4);
    }
    if (knowledge.core.length >= 2) score += 4;
    else if (knowledge.core.length === 1) score += 2;
    if (knowledge.markers.length) score += 2;
    if (knowledge.markers.some(function (m) { return /公开课|课程|讲座|第[一二三四五六七八九十0-9]+讲/.test(m); })) score += 3;
    if (advanced) score += 4;
    if (advice) score -= 16;
    if (k12) score -= 24;
    score -= clickbait.score * 6;
    if (slop.combos.length) score -= 8;
    if (decision.severity === 'medium') score -= 4;
    if (item.durationSec >= 1800) score += 2;
    if (lane === 'deepen' && item.pubdate && U.ageYears(item.pubdate) <= 3) score += 2;
    if (lane === 'deepen' && (k12 || advice)) return null;
    if (lane === 'broaden' && (k12 || advice)) return null;

    const reasons = [];
    if (lane === 'deepen') {
      const targetLabel = labelOf(targets.find(function (id) { return ids.indexOf(id) !== -1; }) || targets[0]);
      reasons.push('深耕「' + targetLabel + '」· 长内容');
      if (topicHit) reasons.push('贴合你的主题：' + (profile.topTopics[0] || ''));
    } else if (lane === 'broaden') {
      const targetLabel = labelOf(targets.find(function (id) { return ids.indexOf(id) !== -1; }) || targets[0]);
      reasons.push('拓界「' + targetLabel + '」· 通识/入门');
    } else {
      reasons.push('2021 年前 · 经典长视频');
    }
    reasons.push(U.formatDuration(dur));
    if (views > 0 && item.favorites / views >= 0.02) {
      reasons.push('收藏率 ' + (item.favorites / views * 100).toFixed(1) + '%');
    }
    if (knowledge.core.length >= 2) reasons.push('知识密度高');

    return {
      score: Math.round(U.clamp(score, 0, 100)),
      reasons: reasons,
      domain: domains[0] ? domains[0].label : '',
      lane: lane
    };
  }

  function rankLane(items, lane, targets, profile, settings, limit) {
    const seen = Object.create(null);
    const out = [];
    (items || []).forEach(function (item) {
      if (!item || !item.bvid || seen[item.bvid]) return;
      const scored = scoreItem(item, lane, targets, profile, settings);
      if (!scored) return;
      if (!item.durationSec) return;
      if (lane === 'deepen' && item.durationSec < 900) return;
      if (lane === 'broaden' && item.durationSec < 480) return;
      if (lane === 'classic' && (!item.pubdate || item.durationSec < 600)) return;
      seen[item.bvid] = true;
      out.push(Object.assign({}, item, {
        exploreScore: scored.score,
        exploreReasons: scored.reasons,
        exploreDomain: scored.domain,
        lane: lane
      }));
    });
    out.sort(function (a, b) {
      if (b.exploreScore !== a.exploreScore) return b.exploreScore - a.exploreScore;
      return (b.views || 0) - (a.views || 0);
    });
    return out.slice(0, limit || (settings.explore.resultsPerLane || 5));
  }

  async function loadCache() {
    const cache = await BLF.Store.get(CACHE_KEY, {});
    return cache && typeof cache === 'object' ? cache : {};
  }

  async function readCache(key, ttlHours) {
    const cache = await loadCache();
    const entry = cache[key];
    if (!entry || !entry.at) return null;
    if (Date.now() - entry.at > (ttlHours || 12) * 3600 * 1000) return null;
    return entry.data;
  }

  async function writeCache(key, data) {
    const cache = await loadCache();
    cache[key] = { at: Date.now(), data: data };
    Object.keys(cache).sort(function (a, b) { return cache[b].at - cache[a].at; })
      .slice(MAX_CACHE)
      .forEach(function (k) { delete cache[k]; });
    await BLF.Store.set(CACHE_KEY, cache);
  }

  function cacheKey(profile, settings, queries) {
    return [
      BLF.Profile.hash(profile),
      queries.map(function (q) { return q.lane + ':' + q.keyword + ':' + (q.beginSec || '') + ':' + (q.endSec || ''); }).join('|'),
      settings.explore.resultsPerLane || 5
    ].join('||');
  }

  /**
   * 获取三条探索路线。所有网络请求都在本地页面登录态下发起。
   */
  async function getAll(profile, settings, options) {
    const opts = options || {};
    if (BLF.Store.isDemo) {
      throw BLF.Api.makeError('演示页不联网：正式安装扩展后即可生成探索推荐', 'demo');
    }
    const p = profile || BLF.Profile.fromSettings(settings);
    const queries = buildQueries(p, settings);
    if (!queries.length) {
      throw BLF.Api.makeError('还没有兴趣方向：先同步账号画像，或在设置里手动选择深耕/拓界领域', 'no-profile');
    }
    const key = cacheKey(p, settings, queries);
    if (!opts.force) {
      const hit = await readCache(key, settings.explore.cacheHours);
      if (hit) {
        return Object.assign({}, hit, {
          cached: true,
          lanes: filterLanes(hit.lanes, opts.excludeIds)
        });
      }
    }

    const buckets = { deepen: [], broaden: [], classic: [] };
    const errors = [];
    for (let i = 0; i < queries.length; i++) {
      const q = queries[i];
      if (opts.onProgress) opts.onProgress({ index: i + 1, total: queries.length, lane: q.lane, keyword: q.keyword });
      try {
        const data = await BLF.Api.searchPage({
          keyword: q.keyword,
          page: 1,
          beginSec: q.beginSec,
          endSec: q.endSec,
          order: q.order || 'totalrank'
        });
        const list = data && Array.isArray(data.result) ? data.result : [];
        list.forEach(function (raw) {
          const item = A.normalizeItem(raw);
          if (!item) return;
          if (q.lane === 'classic' && q.endSec && item.pubdate && item.pubdate > q.endSec) return;
          item._queryLane = q.lane;
          buckets[q.lane].push(item);
        });
      } catch (e) {
        errors.push({ keyword: q.keyword, message: e && e.message });
      }
      if (i < queries.length - 1) await U.sleep(460);
    }

    const lanes = {
      deepen: rankLane(buckets.deepen, 'deepen', targetsOf(queries, 'deepen', p, settings), p, settings),
      broaden: rankLane(buckets.broaden, 'broaden', targetsOf(queries, 'broaden', p, settings), p, settings),
      classic: rankLane(buckets.classic, 'classic', targetsOf(queries, 'classic', p, settings), p, settings)
    };
    const total = lanes.deepen.length + lanes.broaden.length + lanes.classic.length;
    if (!total && errors.length) {
      throw BLF.Api.makeError('探索请求失败：' + errors[0].message, 'explore-failed', { errors: errors });
    }

    const result = {
      lanes: lanes,
      queries: queries,
      profileHash: BLF.Profile.hash(p),
      at: Date.now(),
      errors: errors
    };
    await writeCache(key, result);
    return Object.assign({}, result, {
      cached: false,
      lanes: filterLanes(lanes, opts.excludeIds)
    });
  }

  function targetsOf(queries, lane, profile, settings) {
    const set = [];
    queries.filter(function (q) { return q.lane === lane; }).forEach(function (q) {
      (q.targetIds || []).forEach(function (id) { if (set.indexOf(id) === -1) set.push(id); });
    });
    return set;
  }

  function filterLanes(lanes, excludeIds) {
    if (!excludeIds || !excludeIds.length) return lanes;
    const set = Object.create(null);
    excludeIds.forEach(function (id) { set[id] = true; });
    const out = {};
    Object.keys(lanes || {}).forEach(function (lane) {
      out[lane] = (lanes[lane] || []).filter(function (item) { return !set[item.bvid]; });
    });
    return out;
  }

  async function clearCache() {
    await BLF.Store.remove(CACHE_KEY);
  }

  BLF.Explore = {
    buildQueries: buildQueries,
    validTargets: validTargets,
    rankLane: rankLane,
    getAll: getAll,
    clearCache: clearCache,
    filterLanes: filterLanes
  };
})(typeof globalThis !== 'undefined' ? globalThis : this);
