/* B站学习净化器 · 词库与文本特征（无 DOM 依赖） */
(function (root) {
  'use strict';
  const BLF = (root.BLF = root.BLF || {});
  const U = BLF.U;

  const ASCII_TERM = /^[a-z0-9+#.\- ]+$/i;

  const GAMING_STRONG = [
    '游戏', '手游', '端游', '电竞', '游戏解说', '游戏实况', '游戏攻略',
    '王者荣耀', '和平精英', '原神', '崩坏', '星穹铁道', '星铁', '绝区零', '鸣潮',
    '明日方舟', '阴阳师', '光遇', '蛋仔派对', '元梦之星', '第五人格', '我的世界',
    '迷你世界', '英雄联盟', '云顶之弈', '金铲铲', '无畏契约', '瓦罗兰特',
    'CSGO', 'CS2', 'DOTA', '炉石传说', '魔兽世界', '守望先锋', 'APEX',
    '永劫无间', '三角洲行动', '暗区突围', '火影忍者手游', '赛博朋克', '黑神话',
    '艾尔登法环', '只狼', '塞尔达', 'GTA', '荒野大镖客', '双人成行', '胡闹厨房',
    '星露谷', '泰拉瑞亚', '植物大战僵尸', '三国杀', '任天堂', 'PS5', 'Xbox',
    'Steam', 'Switch', 'Roblox', 'LOL', '英雄联盟手游', '金克丝', '游戏视频'
  ];

  const GAMING_WEAK = [
    '开黑', '上分', '排位', '巅峰赛', '五杀', '超神', '对局', '战局', '实况',
    '解说', '攻略', '速通', '整活', '高能', '名场面', '操作秀', '萌新',
    '版本答案', '新皮肤', '抽卡', '十连', '出货', '打野', '中路', '射手',
    '辅助', '对抗路', '发育路', '打团', '团战', '吃鸡', '决赛圈', '跳伞',
    '压枪', '爆头', '外挂', '封号', '匹配', '段位', '国服', '职业选手',
    '赛事', '直播回放', '游戏区', '主机党', '单机', '联机', 'mod'
  ];

  const ENTERTAINMENT_STRONG = [
    '搞笑', '沙雕', '鬼畜', '爆笑', '笑死', '哈哈', '段子', '脱口秀', '综艺',
    '吃瓜', '八卦', '颜值', '舞蹈', '翻唱', '萌宠', '短剧', '土味', '抽象',
    '社死', '明星', '粉丝', '演唱会', 'cos', '漫展', '影视解说', '电影解说',
    '追剧', '整活', '名场面', '燃剪', '混剪', '踩点', '卡点'
  ];

  const ENTERTAINMENT_WEAK = [
    '挑战', '日常', 'vlog', '美食', '探店', '旅游', '穿搭', '美妆', '情感',
    '恋爱', '相亲', '娱乐', '二次元', '动画', '番剧', '猫咪', '狗狗', '萌',
    '开箱', '测评', '吐槽', '反应', 'reaction', '直播', '颜值区', '生活区'
  ];

  const KNOWLEDGE_CORE = [
    '科普', '知识', '学习', '课程', '公开课', '讲座', '原理', '推导', '证明',
    '公式', '定理', '实验', '论文', '研究', '学术', '大学', '高数', '高等数学',
    '线性代数', '概率论', '微积分', '物理', '化学', '生物', '数学', '几何',
    '代数', '统计', '计算机', '编程', '算法', '数据结构', '人工智能', '机器学习',
    '深度学习', '神经网络', '信息论', '熵', '量子', '相对论', '电磁', '热力学',
    '光学', '天文学', '宇宙', '天文', '地理', '地质', '历史', '哲学', '经济',
    '金融', '心理', '医学', '解剖', '细胞', '基因', 'DNA', '化学键', '元素',
    '反应', '力学', '流体', '材料', '电子', '电路', '信号', '通信', '控制',
    '机器人', '芯片', '半导体', '操作系统', '数据库', '网络', '安全', '密码',
    '傅里叶', '拉普拉斯', '麦克斯韦', '薛定谔', '牛顿', '爱因斯坦', '费曼',
    '香农', '图灵', 'MIT', 'Stanford', '哈佛', '牛津', '剑桥', '3Blue1Brown',
    'CrashCourse', '可汗学院', 'Khan Academy', 'Veritasium', 'Kurzgesagt',
    'TED', '系统学习', '入门到精通', '从零开始', '深度解析', '硬核'
  ];

  const KNOWLEDGE_MARKERS = [
    '科普', '讲解', '解析', '详解', '原理', '推导', '证明', '实验', '论文',
    '公开课', '课程', '讲座', '教程', '入门', '进阶', '系统', '从零',
    '第[一二三四五六七八九十0-9]+讲', '第[一二三四五六七八九十0-9]+课',
    '全[0-9一二三四五六七八九十]+集', '完整课程', '学习', '知识', '干货'
  ];

  const QUALITY_UPS = [
    '3Blue1Brown', '李永乐老师', '妈咪说MommyTalk', '李论科学', '毕导',
    '宋浩老师官方', '无穷小亮的科普日常', '芳斯塔芙', '龙女之声', '思维实验室',
    '混乱博物馆', '回到2049', '硬件茶谈', '影视飓风', '罗翔说刑法',
    '张朝阳的物理课', 'MIT OpenCourseWare', 'CrashCourse', 'Veritasium',
    'Kurzgesagt', 'TED-Ed', '回形针PaperClip', '星球研究所', '中国科普博览',
    '中科院物理所', '返朴', '集智俱乐部', '机器之心', '量子位'
  ];

  const SLOP_TERMS = [
    '认知', '格局', '底层逻辑', '人性', '强者', '弱者', '思维', '财富',
    '搞钱', '副业', '普通人', '翻身', '逆袭', '阶层', '圈层', '顶层',
    '高手', '牛人', '大佬', '成功学', '鸡汤', '励志', '正能量', '语录',
    '早安', '晚安', '每日', '每天', '打卡', '自律', '蜕变', '开悟',
    '觉醒', '通透', '禁书', '删前速看', '限流', '封杀', '不敢说',
    '说点真话', '资本', '割韭菜', '韭菜', '智商税', '信息差', '风口',
    '红利', '赛道', '变现', '涨粉', '爆款', '潜规则', '人情世故',
    '情商', '话术', '拿捏', '月入', '躺赚', '睡后收入', '财富自由',
    '注意看', '这个男人', '这个女人', '小帅', '小美', '佛伯乐',
    '一口气看完', '已完结', '大结局', '无删减'
  ];

  const SLOP_COMBO = [
    ['认知', '格局', '底层逻辑', '人性', '思维', '财富', '搞钱', '副业', '普通人', '翻身', '逆袭', '高手', '牛人', '大佬', '成功', '自律', '觉醒', '开悟', '通透'],
    ['一定要', '记住', '看完', '建议', '必看', '真相', '秘密', '不敢说', '说点', '通透', '收藏', '转发', '码住']
  ];

  const CLICKBAIT_PATTERNS = [
    { id: 'shock', weight: 1.0, re: /(震惊|吓人|太可怕|细思极恐|离谱|逆天|炸裂|惊了|破防|绷不住|笑死|绝了|封神|杀疯)/g },
    { id: 'secret', weight: 1.0, re: /(揭秘|真相|内幕|隐藏|没人告诉|99%|百分之九十九|你不知道|冷知识|秘密|禁术)/g },
    { id: 'must', weight: 1.2, re: /(一定要看|必看|建议收藏|赶紧收藏|速看|转给|不看后悔|错过|码住|收藏夹)/g },
    { id: 'story', weight: 1.6, re: /(注意看|这个男人|这个女人|小帅|小美|佛伯乐|一口气看完|已完结|大结局)/g },
    { id: 'spam', weight: 0.6, re: /([!！?？]{2,}|【\s*\d+\s*】|第[一二三四五六七八九十\d]+[集期弹]|无删减)/g },
    { id: 'emoji', weight: 0.35, re: /[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}]/gu },
    { id: 'vague', weight: 1.0, re: /^(这|那|它|他|她|我)[\u4e00-\u9fa5]{0,8}(太|真|就|居然|竟然|直接)/ },
    { id: 'caps', weight: 0.3, re: /[A-Z]{6,}/g }
  ];

  const AI_DISCLOSURE = /(AI\s*生成|AI\s*合成|由\s*AI|AI\s*制作|AI\s*配音|AI\s*绘画|AI\s*换脸|数字人|虚拟人|文生视频|图生视频|一键生成|Sora|Midjourney|Stable\s*Diffusion|Runway|Pika|可灵|即梦)/i;
  const AI_MENTION = /(\bAI\b|人工智能|AIGC|大模型|智能体|ChatGPT|GPT-?[3-5]|Claude|Gemini|DeepSeek|豆包|通义|文心|Kimi|Sora)/i;
  const AI_MARKETING = /(AI|人工智能|大模型|AIGC|智能体)[^，。！？]{0,14}(颠覆|取代|暴富|赚钱|副业|风口|神器|必备|变现|流量|创业|搞钱|遥遥领先|恐怖|进化|觉醒|淘汰|失业|躺赚|月入|接单|割韭菜)/i;

  const TOPIC_STOP_GRAMS = new Set([
    '我们', '你们', '他们', '这个', '那个', '什么', '为什么', '怎么', '如何',
    '一个', '视频', '本期', '今天', '大家', '可以', '就是', '还是', '但是',
    '因为', '所以', '如果', '没有', '自己', '时候', '已经', '非常', '真的',
    '感觉', '居然', '竟然', '一定', '不是', '这种', '那种', '现在', '以前',
    '第一', '第二', '第三', '这些', '那些', '这样', '那样', '起来', '出来',
    '知道', '觉得', '看看', '一下', '两个', '三个', '很多', '所有', '其实',
    '然后', '而且', '不过', '虽然', '上面', '下面', '里面', '时候', '东西'
  ]);

  const TOPIC_GENERIC_GRAMS = new Set([
    '视频', '合集', '全集', '完整版', '高清', '官方', '最新', '更新', '教程',
    '讲解', '科普', '解说', '分析', '盘点', '推荐', '必看', '干货', '硬核',
    '一个视频', '看完', '分钟', '带你', '告诉', '详解', '全解析', '深度',
    '合集', '系列', '第', '期', '集', '上集', '下集', '中集', '番外',
    '完整', '课程', '公开课', '入门', '进阶', '基础', '原理', '知识'
  ]);

  const CLUSTER_STOP_TERMS = new Set([
    '离谱', '震惊', '逆天', '炸裂', '绝了', '笑死', '可怕', '细思极恐', '揭秘',
    '真相', '内幕', '必看', '收藏', '建议', '一定', '看完', '高能', '名场面',
    '操作秀', '整活', '抽象', '社死', '绷不住', '破防', '封神', '杀疯', '太',
    '真的', '居然', '竟然', '直接', '一个', '视频', '讲清楚', '讲透', '科普',
    '硬核', '干货', '合集', '全集', '完整版', '教程', '讲解', '解析', '盘点',
    '推荐', '入门', '进阶', '基础', '课程', '公开课', '学习', '知识', '游戏',
    '手游', '端游', '电竞', 'AI', '人工智能', '大模型', '认知', '觉醒',
    '底层逻辑', '普通人', '翻身', '逆袭', '格局', '人性', '是什么', '到底',
    '硬核科普', 'ai', '深度解析', '知识科普', '科普视频', '短视频', '竖屏', '竖屏视频',
    '干货分享', '保姆级教程', '一个视频', '视频讲解', '系统讲解'
  ]);

  const STOP_CHARS = '的了呢吧啊呀嘛吗是在和与及或就都也很太更最我你他她它们这那哪些个不没要会能可以对于从到为以被把让给说看做完过还又非常真好坏';

  const cache = { latin: Object.create(null) };

  function latinRe(term) {
    if (!cache.latin[term]) {
      cache.latin[term] = new RegExp('(^|[^a-z0-9])' + U.escapeRegExp(term) + '($|[^a-z0-9])', 'i');
    }
    return cache.latin[term];
  }

  function hit(text, term) {
    if (!text) return false;
    if (ASCII_TERM.test(term) && !/[\u4e00-\u9fa5]/.test(term)) {
      return latinRe(term).test(text);
    }
    return text.toLowerCase().indexOf(term.toLowerCase()) !== -1;
  }

  function findTerms(text, terms) {
    const out = [];
    if (!text) return out;
    for (let i = 0; i < terms.length; i++) {
      if (hit(text, terms[i])) out.push(terms[i]);
    }
    return U.unique(out);
  }

  function clickbait(title) {
    const result = { score: 0, ids: [], hits: [] };
    if (!title) return result;
    for (let i = 0; i < CLICKBAIT_PATTERNS.length; i++) {
      const p = CLICKBAIT_PATTERNS[i];
      p.re.lastIndex = 0;
      const m = title.match(p.re);
      if (m && m.length) {
        result.score += p.weight;
        result.ids.push(p.id);
        Array.prototype.push.apply(result.hits, m.slice(0, 3));
      }
    }
    result.score = U.round(result.score, 2);
    result.hits = U.unique(result.hits.map(function (s) { return String(s).trim(); }));
    return result;
  }

  function aiSignals(text, title) {
    const t = text || '';
    const titleText = title || '';
    return {
      explicit: AI_DISCLOSURE.test(t),
      mention: AI_MENTION.test(titleText) || AI_MENTION.test(t),
      marketing: AI_MARKETING.test(titleText) || AI_MARKETING.test(t)
    };
  }

  function slopSignals(text, title) {
    const t = (title || '') + ' ' + (text || '');
    const terms = findTerms(t, SLOP_TERMS);
    const comboHits = [];
    for (let i = 0; i < SLOP_COMBO.length; i++) {
      const group = SLOP_COMBO[i];
      const matched = group.filter(function (w) { return hit(t, w); });
      if (matched.length >= 2) comboHits.push(matched.slice(0, 4));
    }
    return { terms: terms, combos: comboHits, score: terms.length + comboHits.length * 1.5 };
  }

  function isKnowledge(title, text) {
    const core = findTerms(title, KNOWLEDGE_CORE);
    const markers = [];
    for (let i = 0; i < KNOWLEDGE_MARKERS.length; i++) {
      const term = KNOWLEDGE_MARKERS[i];
      if (term.indexOf('[') !== -1) {
        try {
          if (new RegExp(term).test(title)) markers.push(term);
        } catch (e) { /* ignore */ }
      } else if (hit(title, term) || hit(text, term)) {
        markers.push(term);
      }
    }
    return { core: core, markers: U.unique(markers), score: core.length * 2 + markers.length };
  }


  const ruleCache = new Map();

  function compileRule(rule) {
    const raw = String(rule == null ? '' : rule).trim();
    if (!raw) return null;
    if (raw[0] === '/' && raw.length > 2) {
      const last = raw.lastIndexOf('/');
      if (last > 0) {
        const pattern = raw.slice(1, last);
        let flags = raw.slice(last + 1).replace(/[gy]/g, '');
        if (pattern.length > 200) return null;
        try {
          const re = new RegExp(pattern, flags);
          return { type: 'regex', rule: raw, re: re };
        } catch (e) {
          return null;
        }
      }
    }
    return { type: 'text', rule: raw, text: raw.toLowerCase() };
  }

  function parseRule(rule) {
    if (ruleCache.has(rule)) return ruleCache.get(rule);
    const parsed = compileRule(rule);
    ruleCache.set(rule, parsed);
    if (ruleCache.size > 500) {
      const first = ruleCache.keys().next().value;
      ruleCache.delete(first);
    }
    return parsed;
  }

  function ruleMatches(parsed, text) {
    if (!parsed || !text) return false;
    if (parsed.type === 'regex') {
      parsed.re.lastIndex = 0;
      return parsed.re.test(text);
    }
    return String(text).toLowerCase().indexOf(parsed.text) !== -1;
  }

  /** 返回第一条命中的自定义规则原文；支持普通子串和 /正则/flags。 */
  function firstMatch(text, rules) {
    const input = String(text == null ? '' : text);
    if (!input || !Array.isArray(rules)) return '';
    for (let i = 0; i < rules.length; i++) {
      const parsed = parseRule(rules[i]);
      if (!parsed) continue;
      if (ruleMatches(parsed, input)) return parsed.rule;
    }
    return '';
  }

  function lowInformation(title) {
    const t = U.cleanText(title);
    const cjk = (t.match(/[\u4e00-\u9fa5]/g) || []).length;
    const emoji = (t.match(/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}]/gu) || []).length;
    return {
      short: cjk > 0 && cjk <= 6,
      emojiHeavy: emoji >= 2,
      repeat: /(.)\1{3,}/.test(t),
      noTopic: cjk <= 4
    };
  }

  BLF.Keywords = {
    GAMING_STRONG: GAMING_STRONG,
    GAMING_WEAK: GAMING_WEAK,
    ENTERTAINMENT_STRONG: ENTERTAINMENT_STRONG,
    ENTERTAINMENT_WEAK: ENTERTAINMENT_WEAK,
    KNOWLEDGE_CORE: KNOWLEDGE_CORE,
    KNOWLEDGE_MARKERS: KNOWLEDGE_MARKERS,
    QUALITY_UPS: QUALITY_UPS,
    SLOP_TERMS: SLOP_TERMS,
    CLICKBAIT_PATTERNS: CLICKBAIT_PATTERNS,
    AI_DISCLOSURE: AI_DISCLOSURE,
    AI_MENTION: AI_MENTION,
    AI_MARKETING: AI_MARKETING,
    TOPIC_STOP_GRAMS: TOPIC_STOP_GRAMS,
    TOPIC_GENERIC_GRAMS: TOPIC_GENERIC_GRAMS,
    CLUSTER_STOP_TERMS: CLUSTER_STOP_TERMS,
    STOP_CHARS: STOP_CHARS,
    findTerms: findTerms,
    hit: hit,
    clickbait: clickbait,
    parseRule: parseRule,
    firstMatch: firstMatch,
    aiSignals: aiSignals,
    slopSignals: slopSignals,
    isKnowledge: isKnowledge,
    lowInformation: lowInformation
  };
})(typeof globalThis !== 'undefined' ? globalThis : this);
