/* B站学习净化器 · 账号画像聚合：只保存可解释的领域/主题统计，不保存原始关注与历史列表 */
(function (root) {
  'use strict';
  const BLF = (root.BLF = root.BLF || {});
  const U = BLF.U;
  const Domains = BLF.Domains;

  const STOP_TOPICS = /(默认收藏夹|我的收藏|收藏夹|稍后再看|^(默认|我的|收藏|视频|合集|教程|课程|学习|知识|科普|公开课|一个视频|入门到精通|完整课程|硬核科普|系列|全部|杂项)$)/;

  function addDomains(scores, text, weight) {
    if (!text) return;
    const hits = Domains.classify(text);
    hits.slice(0, 3).forEach(function (d) {
      scores[d.id] = (scores[d.id] || 0) + d.score * weight;
    });
  }

  function addTopics(counts, text, weight) {
    if (!text) return;
    const phrase = BLF.Topic.fromTitle(text);
    if (!phrase) return;
    phrase.split(/\s+/).forEach(function (term) {
      if (!term || term.length < 2 || term.length > 18) return;
      if (STOP_TOPICS.test(term)) return;
      counts[term] = (counts[term] || 0) + weight;
    });
  }

  function topDomainsOf(scores, limit) {
    const total = Object.keys(scores).reduce(function (s, id) { return s + scores[id]; }, 0);
    const out = Object.keys(scores).map(function (id) {
      const d = Domains.get(id);
      return {
        id: id,
        label: d ? d.label : id,
        color: d ? d.color : '#8b98ab',
        score: U.round(scores[id], 2),
        share: total ? U.round(scores[id] / total, 3) : 0
      };
    });
    out.sort(function (a, b) { return b.score - a.score; });
    return out.slice(0, limit || 10);
  }

  function aggregate(input, settings) {
    const nav = input.nav || {};
    const followings = Array.isArray(input.followings) ? input.followings : [];
    const folders = Array.isArray(input.folders) ? input.folders : [];
    const history = Array.isArray(input.history) ? input.history : [];
    const domainScores = Object.create(null);
    const topicCounts = Object.create(null);
    const groupMap = new Map();
    const folderSummaries = [];
    let favoriteCount = 0;

    followings.forEach(function (f) {
      const groups = String(f.tag || '').split(/[,，]/).map(function (s) { return s.trim(); }).filter(Boolean);
      if (!groups.length) groups.push('未分组');
      const groups_arr = Array.isArray(groups) ? groups : [groups];
      groups_arr.forEach(function (group) {
        if (!groupMap.has(group)) groupMap.set(group, { name: group, count: 0, scores: Object.create(null) });
        const g = groupMap.get(group);
        g.count++;
        addDomains(g.scores, (f.sign || '') + ' ' + (f.uname || ''), 1);
      });
      addDomains(domainScores, (f.sign || '') + ' ' + (f.tag || ''), 1.15);
      addDomains(domainScores, f.uname || '', 0.45);
      addTopics(topicCounts, f.sign || '', 0.7);
    });

    folders.forEach(function (folder) {
      const items = Array.isArray(folder.items) ? folder.items : [];
      const fscores = Object.create(null);
      const title = folder.title || '';
      addDomains(domainScores, title, 3.6);
      addDomains(fscores, title, 3.6);
      addTopics(topicCounts, title, 2.2);
      items.forEach(function (item) {
        favoriteCount++;
        const text = [item.title, item.intro].filter(Boolean).join(' ');
        addDomains(domainScores, text, 1.8);
        addDomains(fscores, text, 1.8);
        addTopics(topicCounts, item.title || '', 1.2);
      });
      const fd = topDomainsOf(fscores, 2).map(function (d) { return d.id; });
      folderSummaries.push({
        title: U.truncate(title || '未命名收藏夹', 30),
        count: Number(folder.media_count) || items.length || 0,
        domains: fd
      });
    });

    history.forEach(function (h) {
      addDomains(domainScores, (h.title || '') + ' ' + (h.author_name || ''), 0.75);
      addTopics(topicCounts, h.title || '', 0.6);
    });

    const domains = topDomainsOf(domainScores, 10);
    const topTopics = Object.keys(topicCounts)
      .sort(function (a, b) { return topicCounts[b] - topicCounts[a]; })
      .slice(0, 10);

    const groupSummaries = Array.from(groupMap.values()).map(function (g) {
      return {
        name: g.name,
        count: g.count,
        domains: topDomainsOf(g.scores, 2).map(function (d) { return d.id; })
      };
    }).sort(function (a, b) { return b.count - a.count; }).slice(0, 8);

    folderSummaries.sort(function (a, b) { return b.count - a.count; });
    const trimmedFolders = folderSummaries.slice(0, 8);

    const autoDeepen = Domains.suggestDeepen(domains, 2);
    const autoBroaden = Domains.suggestBroaden(domains.length ? domains : [], 2);
    const chosenDeepen = Domains.validIds(settings.explore && settings.explore.deepen);
    const chosenBroaden = Domains.validIds(settings.explore && settings.explore.broaden);

    return {
      version: 1,
      mid: nav.mid || 0,
      uname: nav.uname || '',
      syncedAt: Date.now(),
      sources: {
        followings: followings.length,
        folders: folders.length,
        favorites: favoriteCount,
        history: history.length
      },
      domains: domains,
      topTopics: topTopics,
      followGroups: groupSummaries,
      folders: trimmedFolders,
      deepen: chosenDeepen.length ? chosenDeepen : autoDeepen,
      broaden: chosenBroaden.length ? chosenBroaden : autoBroaden,
      auto: {
        deepen: autoDeepen,
        broaden: autoBroaden
      },
      manual: followings.length + favoriteCount + history.length === 0
    };
  }

  function fromSettings(settings) {
    const deepen = Domains.validIds(settings.explore && settings.explore.deepen);
    const broaden = Domains.validIds(settings.explore && settings.explore.broaden);
    const domains = Domains.validIds(deepen.concat(broaden)).map(function (id) {
      const d = Domains.get(id);
      return { id: id, label: d.label, color: d.color, score: 1, share: 1 / Math.max(1, deepen.length + broaden.length) };
    });
    return {
      version: 1,
      mid: 0,
      uname: '',
      syncedAt: 0,
      sources: { followings: 0, folders: 0, favorites: 0, history: 0 },
      domains: domains,
      topTopics: [],
      followGroups: [],
      folders: [],
      deepen: deepen,
      broaden: broaden,
      auto: { deepen: [], broaden: [] },
      manual: true
    };
  }

  function hash(profile) {
    if (!profile) return 'none';
    return U.hashString([
      profile.mid || 0,
      (profile.domains || []).map(function (d) { return d.id; }).slice(0, 8).join(','),
      (profile.topTopics || []).slice(0, 6).join(','),
      (profile.deepen || []).join(','),
      (profile.broaden || []).join(',')
    ].join('|'));
  }

  function summary(profile) {
    if (!profile) return '未同步';
    const bits = (profile.domains || []).slice(0, 3).map(function (d) {
      return d.label + ' ' + Math.round(d.share * 100) + '%';
    });
    return bits.join(' · ') || '暂无领域数据';
  }

  BLF.Profile = {
    aggregate: aggregate,
    fromSettings: fromSettings,
    hash: hash,
    summary: summary,
    topDomainsOf: topDomainsOf,
    STOP_TOPICS: STOP_TOPICS
  };
})(typeof globalThis !== 'undefined' ? globalThis : this);
