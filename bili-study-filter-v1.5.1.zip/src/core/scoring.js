/* B站学习净化器 · 内容评分与干预决策（无 DOM 依赖） */
(function (root) {
  'use strict';
  const BLF = (root.BLF = root.BLF || {});
  const U = BLF.U;
  const K = BLF.Keywords;
  const Topic = BLF.Topic;

  const SEV_RANK = { none: 0, low: 1, medium: 2, high: 3 };
  const TONE = {
    gaming: 'pink',
    vertical: 'cyan',
    ai: 'purple',
    slop: 'orange',
    clickbait: 'amber',
    entertainment: 'pink',
    short: 'gray',
    custom: 'red',
    knowledge: 'green',
    cluster: 'blue',
    focus: 'blue'
  };

  function textOf(item) {
    return [item.title, item.description, item.tags, item.typename, item.author]
      .filter(Boolean)
      .join(' ');
  }

  function whitelistHit(item, settings) {
    const mid = item.mid ? String(item.mid) : '';
    const names = (settings.whitelist && settings.whitelist.names) || [];
    const mids = (settings.whitelist && settings.whitelist.mids) || [];
    if (mid && mids.indexOf(mid) !== -1) return 'UP 主白名单（mid ' + mid + '）';
    if (item.author) {
      const a = item.author.trim().toLowerCase();
      for (let i = 0; i < names.length; i++) {
        if (names[i].trim().toLowerCase() === a) return 'UP 主白名单「' + item.author + '」';
      }
    }
    const allow = settings.customAllow || [];
    const allowText = [item.title, item.author, item.tags].filter(Boolean).join(' ');
    const allowHit = K.firstMatch(allowText, allow);
    if (allowHit) return '自定义放行「' + allowHit + '」';
    return '';
  }

  function customBlockHit(item, settings) {
    const list = settings.customBlock || [];
    const hay = [(item.title || ''), (item.author || ''), (item.tags || '')].join(' ');
    return K.firstMatch(hay, list);
  }

  function qualityOf(item, settings, features) {
    const f = features;
    const dur = item.durationSec || 0;
    let q = 48;

    q += U.clamp(U.log10(1 + dur / 60) * 17, 0, 34);
    if (item.views > 0) q += U.clamp(Math.log10(1 + item.views) * 2.2, 0, 12);
    if (item.likes > 0 && item.views > 0) q += U.clamp((item.likes / item.views) * 120, 0, 9);
    if (item.favorites > 0 && item.views > 0) q += U.clamp((item.favorites / item.views) * 260, 0, 11);
    if (item.danmaku > 0 && item.views > 0) q += U.clamp((item.danmaku / item.views) * 320, 0, 6);

    if (f.knowledge.core.length >= 2) q += 7;
    else if (f.knowledge.core.length === 1) q += 3;
    if (f.knowledge.markers.length >= 2) q += 4;
    else if (f.knowledge.markers.length === 1) q += 2;
    if (f.qualityUp) q += U.clamp(settings.thresholds.knownGoodBoost, 0, 40);

    q -= f.clickbait.score * 4.2;
    if (f.ai.explicit) q -= 7;
    if (f.gaming && dur > 0 && dur <= settings.thresholds.gamingShortMax) q -= 9;
    if (f.vertical && dur > 0 && dur <= settings.thresholds.verticalMax) q -= 5;
    if (f.slop.combos.length) q -= 8;

    if (dur > 0 && dur < 60) q -= 8;
    if (dur >= 600) q += 4;
    if (dur >= 1800) q += 3;

    const titleLen = (item.title || '').length;
    if (titleLen >= 8 && titleLen <= 48) q += 3;
    if (titleLen > 70) q -= 3;

    return Math.round(U.clamp(q, 0, 100));
  }

  function analyze(item, settings) {
    settings = settings || BLF.Settings.DEFAULT_SETTINGS;
    const title = U.cleanText(item.title || '');
    const text = textOf(item);
    const dur = Math.max(0, Number(item.durationSec) || 0);
    const th = settings.thresholds;
    const rules = settings.rules;
    const labels = [];
    const reasons = [];
    let severity = 'none';
    let category = 'ok';

    const whitelist = whitelistHit(item, settings);
    const customBlock = customBlockHit(item, settings);

    const gamingStrong = U.unique(K.findTerms(title, K.GAMING_STRONG).concat(
      K.findTerms(item.author || '', K.GAMING_STRONG),
      K.findTerms([item.tags, item.typename].filter(Boolean).join(' '), K.GAMING_STRONG)
    ));
    const gamingWeak = K.findTerms(title, K.GAMING_WEAK);
    const gaming = gamingStrong.length >= 1 || gamingWeak.length >= 2;
    const entStrong = K.findTerms(title, K.ENTERTAINMENT_STRONG);
    const entWeak = K.findTerms(title, K.ENTERTAINMENT_WEAK);
    const entertainment = entStrong.length >= 1 || entWeak.length >= 2;
    const knowledge = K.isKnowledge(title, text);
    const clickbait = K.clickbait(title);
    const ai = K.aiSignals(text, title);
    const slop = K.slopSignals(text, title);
    const lowInfo = K.lowInformation(title);
    const qualityUps = K.findTerms(item.author || '', (settings.qualityUps && settings.qualityUps.length)
      ? settings.qualityUps
      : K.QUALITY_UPS);
    const vertical = !!item.isVertical;

    const knowledgeStrong = knowledge.core.length >= 2 ||
      (knowledge.core.length >= 1 && knowledge.markers.length >= 2);
    const knowledgeVeryStrong = knowledge.core.length >= 2 && knowledge.markers.length >= 2 && dur >= 480;

    const features = {
      gaming: gaming,
      gamingStrong: gamingStrong,
      gamingWeak: gamingWeak,
      entertainment: entertainment,
      entStrong: entStrong,
      entWeak: entWeak,
      knowledge: knowledge,
      knowledgeStrong: knowledgeStrong,
      clickbait: clickbait,
      ai: ai,
      slop: slop,
      lowInfo: lowInfo,
      vertical: vertical,
      qualityUp: qualityUps.length > 0
    };

    function addLabel(id, label, sev, why) {
      if (labels.some(function (l) { return l.id === id; })) return;
      labels.push({
        id: id,
        text: label,
        tone: TONE[id] || 'gray',
        severity: sev,
        why: why || ''
      });
      if (why && reasons.indexOf(why) === -1) reasons.push(why);
      if (SEV_RANK[sev] > SEV_RANK[severity]) {
        severity = sev;
        category = id;
      }
    }

    if (whitelist) {
      return {
        action: 'ok',
        severity: 'none',
        category: 'whitelisted',
        quality: 100,
        labels: [{ id: 'knowledge', text: '白名单放行', tone: 'green', severity: 'none', why: whitelist }],
        hits: { gaming: [], knowledge: knowledge.core, clickbait: [], ai: [], slop: [] },
        reasons: [whitelist],
        topic: Topic.fromTitle(title),
        protected: true,
        features: features
      };
    }

    if (customBlock) {
      addLabel('custom', '自定义屏蔽', 'high', '命中自定义屏蔽词「' + customBlock + '」');
    }

    if (rules.gamingShorts && gaming) {
      const names = gamingStrong.concat(gamingWeak).slice(0, 4).join('、');
      if (dur > 0 && dur <= th.gamingShortMax && !knowledgeVeryStrong) {
        addLabel('gaming', '游戏短视频', 'high',
          '命中游戏特征：' + names + ' · 时长 ' + U.formatDuration(dur));
      } else if (dur > th.gamingShortMax) {
        addLabel('gaming', '游戏内容', 'low',
          '游戏相关（' + names + '），但时长 ' + U.formatDuration(dur) + '，未折叠');
      } else if (dur === 0) {
        addLabel('gaming', '游戏内容', 'low', '命中游戏特征：' + names);
      }
    }

    if (rules.verticalShorts && vertical) {
      if (dur > 0 && dur <= th.verticalMax) {
        addLabel('vertical', '竖屏短视频', 'high',
          '竖屏封面 · 时长 ' + U.formatDuration(dur) + ' ≤ ' + U.formatDuration(th.verticalMax));
      } else if (dur === 0) {
        addLabel('vertical', '竖屏内容', 'medium', '竖屏封面，时长未知');
      } else {
        addLabel('vertical', '竖屏内容', 'low', '竖屏封面 · 时长 ' + U.formatDuration(dur));
      }
    }

    if (rules.entertainmentShorts && entertainment && !knowledgeStrong) {
      if (dur > 0 && dur <= th.entertainmentMax) {
        addLabel('entertainment', '娱乐短视频', 'high',
          '娱乐向：' + entStrong.concat(entWeak).slice(0, 3).join('、') + ' · 时长 ' + U.formatDuration(dur));
      } else if (dur > 0 && dur <= th.entertainmentMax * 2) {
        addLabel('entertainment', '娱乐内容', 'low', '娱乐向内容，时长 ' + U.formatDuration(dur));
      }
    }

    if (rules.aiSlop) {
      const aiWhy = [];
      if (ai.explicit) aiWhy.push('AI 生成/合成声明');
      if (ai.marketing) aiWhy.push('AI 营销话术');
      if (ai.mention && !aiWhy.length) aiWhy.push('AI 相关标题');
      const whyBase = aiWhy.join('、');

      if (ai.explicit && !(knowledgeStrong && dur >= 300)) {
        if (dur <= th.shortMax || clickbait.score >= 1.2 || slop.score >= 2 || lowInfo.short) {
          addLabel('ai', '疑似 AI 营销', 'high',
            whyBase + ' · ' + (dur ? '时长 ' + U.formatDuration(dur) : '时长未知') +
            (clickbait.score ? ' · 标题党 ' + clickbait.score.toFixed(1) : ''));
        } else {
          addLabel('ai', 'AI 生成内容', 'medium', whyBase + ' · 时长 ' + U.formatDuration(dur));
        }
      } else if (ai.marketing && !knowledgeStrong) {
        addLabel('ai', 'AI 营销话术', 'high', whyBase + (clickbait.hits.length ? ' · ' + clickbait.hits.slice(0, 3).join('、') : ''));
      } else if (ai.mention && !knowledgeStrong) {
        if (dur > 0 && dur <= 120 && clickbait.score >= 0.9) {
          addLabel('ai', '疑似 AI 流水线', 'high', whyBase + ' · 超短 + 标题党');
        } else if (slop.score >= 3) {
          addLabel('ai', '疑似 AI 营销', 'high', whyBase + ' · 营销话术密集');
        } else if (dur > 0 && dur <= 60) {
          addLabel('ai', 'AI 相关短视频', 'medium', whyBase + ' · 时长 ' + U.formatDuration(dur));
        }
      } else if (ai.mention && knowledgeStrong && dur >= 300) {
        addLabel('knowledge', 'AI 知识内容', 'none', '知识向 AI 内容，已放行');
      }
    }

    if (rules.marketingSlop) {
      const slopNames = slop.terms.slice(0, 4).join('、');
      const story = /(注意看|这个男人|这个女人|小帅|小美|一口气看完|已完结|大结局)/.test(title);
      if (story) {
        addLabel('slop', '影视解说流水线', 'high', '命中短剧/影视解说模板：' + slopNames);
      } else if (slop.combos.length && !knowledgeStrong) {
        addLabel('slop', '营销号话术', 'high',
          '话术组合：' + slop.combos[0].join(' + '));
      } else if (slop.terms.length >= 3 && clickbait.score >= 0.9 && !knowledgeStrong) {
        addLabel('slop', '营销号内容', 'high', '高频营销词：' + slopNames);
      } else if (slop.terms.length >= 2 && !knowledgeStrong && (dur > 0 && dur <= th.shortMax)) {
        addLabel('slop', '低质营销内容', 'high', '营销词 + 短视频：' + slopNames);
      } else if (slop.terms.length >= 1 && clickbait.score >= th.clickbaitStrong) {
        addLabel('slop', '疑似营销号', 'medium', '营销词：' + slopNames + ' · 标题党');
      }
    }

    if (rules.clickbait && clickbait.score >= 1.2) {
      if (clickbait.score >= th.clickbaitStrong) {
        if (knowledgeVeryStrong) {
          addLabel('clickbait', '标题党', 'low', '标题党特征，但知识密度较高：' + clickbait.hits.slice(0, 4).join('、'));
        } else {
          addLabel('clickbait', '标题党', 'medium', '标题党特征 ' + clickbait.score.toFixed(1) + '：' + clickbait.hits.slice(0, 4).join('、'));
        }
      } else {
        addLabel('clickbait', '轻微标题党', 'low', '标题党特征：' + clickbait.hits.slice(0, 3).join('、'));
      }
    }

    const shortNonKnowledge = dur > 0 && dur <= th.shortMax && !knowledgeStrong;
    if (shortNonKnowledge && !vertical && !gaming && !entertainment) {
      if (dur <= 60) {
        addLabel('short', '超短视频', 'medium', '时长 ' + U.formatDuration(dur) + '，信息密度可能有限');
      } else {
        addLabel('short', '短视频', 'low', '时长 ' + U.formatDuration(dur) + ' ≤ ' + U.formatDuration(th.shortMax));
      }
    }

    if (lowInfo.noTopic && dur > 0 && dur <= 120 && !knowledgeStrong) {
      addLabel('short', '信息量偏低', 'medium', '标题过短、缺少主题信息');
    }

    if (knowledgeVeryStrong) {
      addLabel('knowledge', '知识向长视频', 'none',
        '知识标记：' + U.unique(knowledge.core.concat(knowledge.markers)).slice(0, 4).join('、'));
    }

    labels.sort(function (a, b) { return SEV_RANK[b.severity] - SEV_RANK[a.severity]; });

    if (customBlock) {
      severity = 'high';
      category = 'custom';
    }

    const action = severity === 'high' ? 'blur' : severity === 'medium' ? 'dim' : severity === 'low' ? 'badge' : 'ok';
    const quality = qualityOf(item, settings, features);

    return {
      action: action,
      severity: severity,
      category: category,
      quality: quality,
      labels: labels,
      hits: {
        gaming: gamingStrong.concat(gamingWeak),
        knowledge: U.unique(knowledge.core.concat(knowledge.markers)),
        clickbait: clickbait.hits,
        ai: aiWhyLabels(ai),
        slop: slop.terms
      },
      reasons: reasons,
      topic: Topic.fromTitle(title),
      protected: knowledgeVeryStrong,
      shortNonKnowledge: shortNonKnowledge,
      features: features
    };
  }

  function aiWhyLabels(ai) {
    const out = [];
    if (ai.explicit) out.push('AI 生成/合成');
    if (ai.marketing) out.push('AI 营销');
    if (ai.mention) out.push('AI 相关');
    return out;
  }

  /**
   * 结合用户「显示方式」得到最终视觉动作。
   * high: 模糊/隐藏/淡化；medium: 淡化；low: 角标。
   */
  function effectiveAction(decision, settings) {
    if (!decision || decision.severity === 'none' || decision.action === 'ok') return 'ok';
    if (decision.severity === 'high') {
      if (settings.mode === 'hide') return 'hide';
      if (settings.mode === 'dim') return 'dim';
      return 'blur';
    }
    if (decision.severity === 'medium') return 'dim';
    return 'badge';
  }

  function summary(decision) {
    if (!decision) return '';
    if (decision.severity === 'none') return '正常内容';
    return decision.labels.filter(function (l) { return l.severity !== 'none'; })
      .map(function (l) { return l.text; }).slice(0, 2).join(' · ');
  }

  BLF.Scoring = {
    analyze: analyze,
    effectiveAction: effectiveAction,
    qualityOf: qualityOf,
    summary: summary,
    SEV_RANK: SEV_RANK
  };
})(typeof globalThis !== 'undefined' ? globalThis : this);
