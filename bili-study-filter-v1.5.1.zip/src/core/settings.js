/* B站学习净化器 · 配置与预设 */
(function (root) {
  'use strict';
  const BLF = (root.BLF = root.BLF || {});
  const U = BLF.U;

  const DEFAULT_SETTINGS = {
    version: 1,
    enabled: true,
    mode: 'blur',              // blur | dim | hide
    focusMode: false,          // 专注模式：非知识向的短视频直接折叠
    rules: {
      gamingShorts: true,      // 游戏短视频
      verticalShorts: true,    // 竖屏/小视频
      aiSlop: true,            // 疑似 AI 营销号
      marketingSlop: true,     // 营销号/流水线内容
      clickbait: true,         // 标题党
      entertainmentShorts: true, // 娱乐短视频
      homogeneity: true,       // 同质选题聚合
      collapseShelves: false   // 折叠整个短视频专区（实验性）
    },
    thresholds: {
      shortMax: 180,           // 秒：短视频上限
      gamingShortMax: 300,     // 秒：游戏短视频上限
      verticalMax: 180,        // 秒：竖屏短视频上限
      entertainmentMax: 120,   // 秒：娱乐短视频上限
      clickbaitStrong: 2.4,    // 标题党强判定分
      homogeneityMin: 3,       // 同题聚类最少条数
      blurStrength: 7,         // px
      knownGoodBoost: 12       // 优质 UP 质量加分
    },
    explore: {
      enabled: true,
      useHistory: false,       // 是否把最近观看纳入画像（默认关闭）
      followPages: 3,          // 读取关注列表页数（每页 50）
      favFolders: 8,           // 读取收藏夹数量
      cocoonThreshold: 0.65,   // 单一领域占比超过这个值，提示信息茧房
      showCocoonChip: true,    // 在页面右下角显示“换换脑子”提示
      deepen: [],              // 深耕领域 id；空 = 从画像自动推荐
      broaden: [],             // 拓界领域 id；空 = 从画像自动推荐
      resultsPerLane: 5,
      cacheHours: 12
    },
    appearance: {
      background: 'none',     // none | color | gradient | image
      color: '#eef4fb',
      gradient: 'linear-gradient(135deg, #eef4fb 0%, #dfeaf7 55%, #f7f1f7 100%)',
      imageUrl: '',
      opacity: 0.8,
      blur: 0,
      dim: 0.06
    },
    homeClean: {
      live: true,              // 清理首页直播/推广单卡
      ads: true,               // 清理首页广告卡片
      reflow: true             // 隐藏后让首页网格紧凑回流
    },
    studyFeed: {
      enabled: true,
      hero: true,              // 首页顶部科技学习专区
      replaceBlocked: true,    // 被隐藏的视频位置用科技推荐补位
      hideCarousel: false,     // 隐藏首页顶部轮播（实验性）
      hideBanner: false,       // 收起首页大 banner（实验性）
      topics: ['cs', 'ee', 'tech', 'ai'],
      minDuration: 600,        // 秒：补位/学习池最短时长
      poolSize: 24,
      cacheHours: 12
    },
    archaeology: {
      minDuration: 600,        // 秒：考古视频最短时长
      cutoff: '2021-12-31',    // 只找这之前发布的
      begin: '2009-01-01',
      pages: 2,                // 每个关键词抓取页数
      cacheHours: 24,
      results: 12
    },
    whitelist: {
      mids: [],
      names: []
    },
    customBlock: [],           // 自定义屏蔽词（标题/UP）
    customAllow: [],           // 自定义放行词
    qualityUps: BLF.Keywords ? BLF.Keywords.QUALITY_UPS.slice() : [],
    ui: {
      showBadges: true,
      showPanel: true,
      panelCollapsed: true
    }
  };

  function clone(obj) {
    return JSON.parse(JSON.stringify(obj));
  }

  function isPlainObject(v) {
    return !!v && typeof v === 'object' && !Array.isArray(v);
  }

  function merge(base, patch) {
    const out = clone(base);
    if (!isPlainObject(patch)) return out;
    Object.keys(patch).forEach(function (key) {
      const val = patch[key];
      if (val === undefined) return;
      if (isPlainObject(val) && isPlainObject(out[key])) {
        out[key] = merge(out[key], val);
      } else {
        out[key] = Array.isArray(val) ? val.slice() : val;
      }
    });
    return out;
  }

  function cleanList(list, max) {
    if (!Array.isArray(list)) return [];
    const seen = Object.create(null);
    const out = [];
    list.forEach(function (item) {
      const s = String(item == null ? '' : item).trim();
      if (!s || seen[s.toLowerCase()]) return;
      seen[s.toLowerCase()] = true;
      out.push(s.slice(0, 200));
    });
    return out.slice(0, max || 200);
  }

  function normalize(raw) {
    const s = merge(DEFAULT_SETTINGS, raw || {});
    ['rules', 'thresholds', 'explore', 'appearance', 'homeClean', 'studyFeed', 'archaeology', 'whitelist', 'ui'].forEach(function (key) {
      if (!isPlainObject(s[key])) s[key] = clone(DEFAULT_SETTINGS[key]);
    });
    if (!Array.isArray(s.customBlock)) s.customBlock = [];
    if (!Array.isArray(s.customAllow)) s.customAllow = [];
    if (!Array.isArray(s.qualityUps)) s.qualityUps = DEFAULT_SETTINGS.qualityUps.slice();
    s.enabled = !!s.enabled;
    s.focusMode = !!s.focusMode;
    if (['blur', 'dim', 'hide'].indexOf(s.mode) === -1) s.mode = 'blur';

    const t = s.thresholds;
    t.shortMax = U.clamp(t.shortMax, 10, 7200);
    t.gamingShortMax = U.clamp(t.gamingShortMax, 10, 7200);
    t.verticalMax = U.clamp(t.verticalMax, 10, 3600);
    t.entertainmentMax = U.clamp(t.entertainmentMax, 10, 3600);
    t.clickbaitStrong = U.clamp(t.clickbaitStrong, 0.5, 8);
    t.homogeneityMin = Math.round(U.clamp(t.homogeneityMin, 2, 8));
    t.blurStrength = U.clamp(t.blurStrength, 2, 20);
    t.knownGoodBoost = U.clamp(t.knownGoodBoost, 0, 40);

    const ap = s.appearance;
    const bgModes = ['none', 'color', 'gradient', 'image'];
    ap.background = bgModes.indexOf(ap.background) !== -1 ? ap.background : 'none';
    ap.color = /^#[0-9a-f]{6}$/i.test(ap.color || '') ? ap.color : '#eef4fb';
    ap.gradient = (typeof ap.gradient === 'string' && /^(linear|radial)-gradient\(/i.test(ap.gradient) &&
      ap.gradient.length <= 300) ? ap.gradient : DEFAULT_SETTINGS.appearance.gradient;
    ap.imageUrl = (typeof ap.imageUrl === 'string' && /^(https?:\/\/|data:image\/)/i.test(ap.imageUrl) &&
      ap.imageUrl.length <= 500) ? ap.imageUrl : '';
    ap.opacity = U.clamp(ap.opacity, 0, 1);
    ap.blur = U.clamp(ap.blur, 0, 20);
    ap.dim = U.clamp(ap.dim, 0, 0.6);

    const hc = s.homeClean;
    hc.live = hc.live !== false;
    hc.ads = hc.ads !== false;
    hc.reflow = hc.reflow !== false;

    const sf = s.studyFeed;
    sf.enabled = sf.enabled !== false;
    sf.hero = sf.hero !== false;
    sf.replaceBlocked = sf.replaceBlocked !== false;
    sf.hideCarousel = !!sf.hideCarousel;
    sf.hideBanner = !!sf.hideBanner;
    const validStudy = ['cs', 'ee', 'tech', 'ai', 'math', 'physics'];
    sf.topics = U.unique((Array.isArray(sf.topics) ? sf.topics : []).filter(function (id) {
      return validStudy.indexOf(id) !== -1;
    }));
    if (!sf.topics.length) sf.topics = ['cs', 'ee', 'tech', 'ai'];
    sf.minDuration = Math.round(U.clamp(sf.minDuration, 300, 3600));
    sf.poolSize = Math.round(U.clamp(sf.poolSize, 8, 32));
    sf.cacheHours = U.clamp(sf.cacheHours, 1, 72);

    const ex = s.explore;
    ex.enabled = ex.enabled !== false;
    ex.useHistory = !!ex.useHistory;
    ex.showCocoonChip = ex.showCocoonChip !== false;
    ex.followPages = Math.round(U.clamp(ex.followPages, 1, 8));
    ex.favFolders = Math.round(U.clamp(ex.favFolders, 1, 12));
    ex.cocoonThreshold = U.clamp(ex.cocoonThreshold, 0.4, 0.95);
    ex.resultsPerLane = Math.round(U.clamp(ex.resultsPerLane, 3, 8));
    ex.cacheHours = U.clamp(ex.cacheHours, 1, 72);
    if (BLF.Domains) {
      ex.deepen = BLF.Domains.validIds(ex.deepen);
      ex.broaden = BLF.Domains.validIds(ex.broaden).filter(function (id) {
        return ex.deepen.indexOf(id) === -1;
      });
    } else {
      ex.deepen = Array.isArray(ex.deepen) ? ex.deepen.slice(0, 2) : [];
      ex.broaden = Array.isArray(ex.broaden) ? ex.broaden.slice(0, 2) : [];
    }

    const a = s.archaeology;
    a.minDuration = U.clamp(a.minDuration, 60, 7200);
    a.pages = Math.round(U.clamp(a.pages, 1, 3));
    a.cacheHours = U.clamp(a.cacheHours, 1, 168);
    a.results = Math.round(U.clamp(a.results, 6, 20));
    if (!/^\d{4}-\d{2}-\d{2}$/.test(a.cutoff)) a.cutoff = '2021-12-31';
    if (!/^\d{4}-\d{2}-\d{2}$/.test(a.begin)) a.begin = '2009-01-01';

    s.whitelist.mids = U.unique(cleanList(s.whitelist.mids, 300).map(function (x) {
      return x.replace(/[^\d]/g, '');
    }).filter(Boolean));
    s.whitelist.names = cleanList(s.whitelist.names, 300);
    s.customBlock = cleanList(s.customBlock, 200);
    s.customAllow = cleanList(s.customAllow, 200);
    s.qualityUps = cleanList(s.qualityUps, 200);
    s.ui.showBadges = s.ui.showBadges !== false;
    s.ui.showPanel = s.ui.showPanel !== false;
    s.ui.panelCollapsed = s.ui.panelCollapsed !== false;
    return s;
  }

  function preset(name) {
    if (name === 'focus') {
      return normalize(merge(DEFAULT_SETTINGS, {
        mode: 'blur',
        focusMode: true,
        thresholds: { shortMax: 300, gamingShortMax: 420, homogeneityMin: 2 },
        rules: { entertainmentShorts: true, homogeneity: true }
      }));
    }
    if (name === 'gentle') {
      return normalize(merge(DEFAULT_SETTINGS, {
        mode: 'dim',
        focusMode: false,
        thresholds: { shortMax: 120, gamingShortMax: 180, verticalMax: 120, entertainmentMax: 90, homogeneityMin: 4 },
        rules: { clickbait: false, entertainmentShorts: false }
      }));
    }
    return normalize(DEFAULT_SETTINGS);
  }

  async function load() {
    const raw = await BLF.Store.get('blfSettings', null);
    return normalize(raw || DEFAULT_SETTINGS);
  }

  async function save(settings) {
    const normalized = normalize(settings);
    await BLF.Store.set('blfSettings', normalized);
    return normalized;
  }

  BLF.Settings = {
    DEFAULT_SETTINGS: DEFAULT_SETTINGS,
    merge: merge,
    normalize: normalize,
    preset: preset,
    load: load,
    save: save
  };
})(typeof globalThis !== 'undefined' ? globalThis : this);
