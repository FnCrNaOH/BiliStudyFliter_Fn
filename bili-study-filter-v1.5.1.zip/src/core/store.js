/* B站学习净化器 · 存储适配层：扩展环境用 chrome.storage.local，demo 用 localStorage */
(function (root) {
  'use strict';
  const BLF = (root.BLF = root.BLF || {});

  const hasChrome = typeof chrome !== 'undefined' && chrome && chrome.storage && chrome.storage.local;
  const memory = Object.create(null);
  let ls = null;
  try {
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem('__blf_test__', '1');
      localStorage.removeItem('__blf_test__');
      ls = localStorage;
    }
  } catch (e) { ls = null; }

  const PREFIX = 'blf:';

  function readLocal(key) {
    if (ls) {
      try {
        const raw = ls.getItem(PREFIX + key);
        return raw == null ? undefined : JSON.parse(raw);
      } catch (e) { /* ignore */ }
    }
    return memory[key];
  }

  function writeLocal(key, value) {
    memory[key] = value;
    if (ls) {
      try { ls.setItem(PREFIX + key, JSON.stringify(value)); } catch (e) { /* quota */ }
    }
  }

  const Store = {
    isExtension: !!hasChrome,
    isDemo: !hasChrome,

    async get(key, fallback) {
      if (hasChrome) {
        try {
          const res = await chrome.storage.local.get(key);
          return res && res[key] !== undefined ? res[key] : fallback;
        } catch (e) {
          return fallback;
        }
      }
      const v = readLocal(key);
      return v === undefined ? fallback : v;
    },

    async set(key, value) {
      if (hasChrome) {
        const obj = {};
        obj[key] = value;
        try { await chrome.storage.local.set(obj); } catch (e) { /* ignore */ }
        return;
      }
      writeLocal(key, value);
    },

    async remove(key) {
      if (hasChrome) {
        try { await chrome.storage.local.remove(key); } catch (e) { /* ignore */ }
        return;
      }
      delete memory[key];
      if (ls) {
        try { ls.removeItem(PREFIX + key); } catch (e) { /* ignore */ }
      }
    },

    onChange(callback) {
      if (hasChrome && chrome.storage.onChanged) {
        chrome.storage.onChanged.addListener(function (changes, area) {
          if (area !== 'local') return;
          Object.keys(changes).forEach(function (key) {
            callback(key, changes[key].newValue, changes[key].oldValue);
          });
        });
      }
    }
  };

  BLF.Store = Store;
})(typeof globalThis !== 'undefined' ? globalThis : this);
