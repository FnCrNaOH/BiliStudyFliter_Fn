/* B站学习净化器 · 首页科技学习池：计算机 / 电子信息 / 科技 / AI 长视频 */
(function (root) {
  'use strict';
  const BLF = (root.BLF = root.BLF || {});
  const U = BLF.U;

  const CACHE_KEY = 'blfStudyPool';

  const TOPICS = [
    {
      id: 'cs', label: '计算机',
      query: '计算机科学 科普 入门',
      keywords: ['计算机', '编程', '算法', '软件', '操作系统', '数据结构', '代码', '程序', '互联网', '数据库', '编译']
    },
    {
      id: 'ee', label: '电子信息',
      query: '电子信息 科普 原理',
      keywords: ['电子', '电路', '通信', '信号', '芯片', '半导体', '电磁', '硬件', '元器件', '射频', '光通信']
    },
    {
      id: 'tech', label: '科技',
      query: '科技 科普 发展史',
      keywords: ['科技', '技术', '工程', '机器人', '航天', '能源', '材料', '制造', '航空', '工程史']
    },
    {
      id: 'ai', label: '人工智能',
      query: '人工智能 原理 科普',
      keywords: ['人工智能', '机器学习', '神经网络', '大模型', '深度学习', 'AI', 'ChatGPT']
    },
    {
      id: 'math', label: '数学',
      query: '数学 科普 思想',
      keywords: ['数学', '概率', '微积分', '线性代数', '几何', '数论']
    },
    {
      id: 'physics', label: '物理',
      query: '物理 科普 原理',
      keywords: ['物理', '量子', '相对论', '力学', '电磁', '热力学', '光学']
    }
  ];

  const BY_ID = Object.create(null);
  TOPICS.forEach(function (t) { BY_ID[t.id] = t; });

  const K12 = /(小学|初中|高中|中考|高考|八年级|七年级|九年级|初二|初三|高一|高二|高三|义务教育|人教版|北师大版|同步课程|教材解读|课程标准|儿童|幼儿|少儿|亲子|小朋友|3-15岁|准大一|志愿填报|自救指南|专业选择|考研规划)/;
  const ADVICE = /(专业\/行业|专业选择|选专业|志愿|就业|行业规划|学习路径|怎么学|大学专业|报考|保研|考研|转专业|薪资|求职|职业规划|专业.{0,8}(能学|怎么|就业|前景|选择))/;
  const ENTERTAINMENT_META = /(影视|电影|电视剧|综艺|娱乐|游戏|动画|鬼畜|搞笑)/;
  const ENTERTAINMENT_TITLE = /(格莱美|音乐现场|明星|综艺|电影解说|影视解说|电视剧|动漫解说|游戏实况|搞笑片段)/;

  function validTopics(ids) {
    const seen = Object.create(null);
    const out = [];
    (Array.isArray(ids) ? ids : []).forEach(function (id) {
      if (BY_ID[id] && !seen[id]) {
        seen[id] = true;
        out.push(id);
      }
    });
    return out;
  }

  function containsTerm(text, kw) {
    if (/^[a-z0-9+#.]+$/i.test(kw) && kw.length <= 4) {
      return new RegExp('(^|[^a-z0-9])' + kw.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '([^a-z0-9]|$)', 'i').test(text);
    }
    return text.toLowerCase().indexOf(kw.toLowerCase()) !== -1;
  }

  function topicForTitle(title, text) {
    let best = null;
    let bestScore = 0;
    const hay = title + ' ' + text;
    TOPICS.forEach(function (topic) {
      let score = 0;
      topic.keywords.forEach(function (kw) {
        if (containsTerm(hay, kw)) score += kw.length >= 3 ? 2 : 1;
      });
      if (score > bestScore) {
        bestScore = score;
        best = topic;
      }
    });
    return best;
  }

  function scoreItem(item, topic, settings) {
    const dur = item.durationSec || 0;
    if (dur < (settings.studyFeed.minDuration || 600)) return null;
    const title = item.title || '';
    const text = [title, item.tags, item.typename, item.description].filter(Boolean).join(' ');
    if (K12.test(title) || ADVICE.test(title) || ENTERTAINMENT_TITLE.test(title)) return null;
    if (ENTERTAINMENT_META.test([item.typename, item.tags].filter(Boolean).join(' '))) return null;

    const matched = topicForTitle(title, text);
    if (!matched) return null;
    let score = 24;
    score += U.clamp(U.log10(1 + dur / 60) * 9, 0, 15);
    score += U.clamp(Math.log10(1 + (item.views || 0)) * 1.2, 0, 6);
    if (item.views > 0) {
      score += U.clamp(((item.favorites || 0) / item.views) * 180, 0, 15);
      score += U.clamp(((item.likes || 0) / item.views) * 70, 0, 5);
    }
    const knowledge = BLF.Keywords.isKnowledge(title, text);
    if (knowledge.core.length >= 2) score += 6;
    else if (knowledge.core.length >= 1) score += 3;
    if (knowledge.markers.length) score += 3;
    if (/(公开课|课程|讲座|原理|推导|证明|系统|入门|进阶|史|纪录片)/.test(title)) score += 4;
    if (matched) score += 6;
    const hours = dur / 3600;
    if (hours > 10) score -= 12;
    else if (hours > 6) score -= 7;
    else if (hours > 4) score -= 3;
    else if (hours <= 2) score += 4;
    if (hours > 4 && (item.views || 0) < 50000) score -= 8;
    if (/全集|全\d+集|完整版|合集|速成|速通|保姆级/.test(title)) score -= 3;

    const clickbait = BLF.Keywords.clickbait(title);
    score -= clickbait.score * 6;
    const slop = BLF.Keywords.slopSignals(title, text);
    if (slop.combos.length) score -= 8;
    let decision;
    try {
      decision = BLF.Scoring.analyze(item, settings);
    } catch (e) {
      decision = { severity: 'none' };
    }
    if (decision.severity === 'high') return null;
    if (['gaming', 'entertainment', 'slop', 'vertical'].indexOf(decision.category) !== -1) return null;
    if (decision.severity === 'medium') score -= 4;
    if (item.durationSec >= 1800) score += 3;
    if (item.pubdate && U.ageYears(item.pubdate) >= 5) score += 2;

    return {
      score: Math.round(U.clamp(score, 0, 100)),
      topic: matched ? matched.id : topic.id,
      topicLabel: matched ? matched.label : topic.label,
      reason: (matched ? matched.label : topic.label) + ' · ' + U.formatDuration(dur) +
        (item.views > 0 && item.favorites / item.views >= 0.02
          ? ' · 收藏率 ' + (item.favorites / item.views * 100).toFixed(1) + '%'
          : '')
    };
  }

  async function loadCache() {
    const cache = await BLF.Store.get(CACHE_KEY, null);
    return cache && typeof cache === 'object' ? cache : null;
  }

  async function getPool(settings, options) {
    const opts = options || {};
    if (BLF.Store.isDemo) {
      throw BLF.Api.makeError('演示页不联网：正式安装后自动加载科技学习池', 'demo');
    }
    const sf = settings.studyFeed;
    const topics = validTopics(sf.topics);
    if (!topics.length) throw BLF.Api.makeError('请先在设置里选择至少一个科技领域', 'no-topics');
    const key = [topics.join(','), sf.minDuration, sf.poolSize].join('|');
    if (!opts.force) {
      const cache = await loadCache();
      if (cache && cache.key === key && cache.at &&
          Date.now() - cache.at < (sf.cacheHours || 12) * 3600 * 1000 &&
          Array.isArray(cache.items) && cache.items.length) {
        return Object.assign({}, cache, { cached: true });
      }
    }

    const raw = [];
    const errors = [];
    const list = topics.slice(0, 6);
    for (let i = 0; i < list.length; i++) {
      const topic = BY_ID[list[i]];
      if (opts.onProgress) opts.onProgress({ index: i + 1, total: list.length, label: topic.label });
      try {
        const data = await BLF.Api.searchPage({
          keyword: topic.query,
          page: 1,
          order: 'totalrank'
        });
        const result = data && Array.isArray(data.result) ? data.result : [];
        result.forEach(function (r) {
          const item = BLF.Archaeology.normalizeItem(r);
          if (!item) return;
          const scored = scoreItem(item, topic, settings);
          if (!scored) return;
          raw.push(Object.assign({}, item, {
            studyScore: scored.score,
            studyTopic: scored.topic,
            studyTopicLabel: scored.topicLabel,
            studyReason: scored.reason
          }));
        });
      } catch (e) {
        errors.push({ topic: topic.label, message: e && e.message });
      }
      if (i < list.length - 1) await U.sleep(460);
    }

    const seen = Object.create(null);
    const byTopic = Object.create(null);
    const items = [];
    raw.sort(function (a, b) { return b.studyScore - a.studyScore; });
    raw.forEach(function (item) {
      if (seen[item.bvid]) return;
      byTopic[item.studyTopic] = byTopic[item.studyTopic] || 0;
      if (byTopic[item.studyTopic] >= 6) return;
      seen[item.bvid] = true;
      byTopic[item.studyTopic]++;
      items.push(item);
    });

    const pool = {
      key: key,
      topics: topics,
      items: items.slice(0, Math.max(4, Math.min(40, sf.poolSize || 24))),
      errors: errors,
      at: Date.now()
    };
    if (pool.items.length) {
      await BLF.Store.set(CACHE_KEY, pool);
    }
    if (!pool.items.length && errors.length) {
      throw BLF.Api.makeError('科技学习池加载失败：' + errors[0].message, 'study-failed', { errors: errors });
    }
    return Object.assign({}, pool, { cached: false });
  }

  async function clearCache() {
    await BLF.Store.remove(CACHE_KEY);
  }

  BLF.StudyFeed = {
    TOPICS: TOPICS,
    BY_ID: BY_ID,
    validTopics: validTopics,
    getPool: getPool,
    clearCache: clearCache,
    scoreItem: scoreItem
  };
})(typeof globalThis !== 'undefined' ? globalThis : this);
