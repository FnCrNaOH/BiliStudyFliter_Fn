/* B站学习净化器 · 选题提取与中文 n-gram（无 DOM 依赖） */
(function (root) {
  'use strict';
  const BLF = (root.BLF = root.BLF || {});
  const U = BLF.U;
  const K = BLF.Keywords;

  const CJK = /[\u4e00-\u9fa5]/;
  const LATIN = /[a-zA-Z][a-zA-Z0-9+#.\-]{1,}/g;

  const IGNORE_SINGLE = new Set(['熵', '焓', '㶲']);

  function validGram(gram) {
    if (!gram || gram.length < 2) return false;
    if (K.TOPIC_STOP_GRAMS.has(gram) || K.TOPIC_GENERIC_GRAMS.has(gram)) return false;
    if (/^\d+$/.test(gram)) return false;
    let nonStop = 0;
    for (let i = 0; i < gram.length; i++) {
      if (K.STOP_CHARS.indexOf(gram[i]) === -1) nonStop++;
    }
    if (nonStop === 0) return false;
    if (gram.length === 2 && nonStop < 2) return false;
    return true;
  }

  /**
   * 生成候选词：2~4 字中文 n-gram + 英文词 + 少数关键单字（熵）。
   * 返回 Map<term, {term, pos, len, latin}>。
   */
  function candidateMap(title) {
    const map = new Map();
    if (!title) return map;
    const text = U.cleanText(title).normalize('NFKC');
    let runRe = /[\u4e00-\u9fa5]+/g;
    let m;
    while ((m = runRe.exec(text))) {
      const run = m[0];
      for (let n = 2; n <= 4; n++) {
        for (let i = 0; i + n <= run.length; i++) {
          const gram = run.slice(i, i + n);
          if (!validGram(gram)) continue;
          if (!map.has(gram)) {
            map.set(gram, { term: gram, pos: m.index + i, len: n, latin: false });
          }
        }
      }
      for (let i = 0; i < run.length; i++) {
        const ch = run[i];
        if (IGNORE_SINGLE.has(ch) && !map.has(ch)) {
          map.set(ch, { term: ch, pos: m.index + i, len: 1.4, latin: false });
        }
      }
    }
    LATIN.lastIndex = 0;
    let lm;
    while ((lm = LATIN.exec(text))) {
      const term = lm[0].toLowerCase();
      if (term.length < 2 || K.TOPIC_STOP_GRAMS.has(term)) continue;
      if (!map.has(term)) {
        map.set(term, { term: term, pos: lm.index, len: Math.min(8, term.length), latin: true });
      }
    }
    return map;
  }

  function candidateTerms(title) {
    return Array.from(candidateMap(title).values());
  }

  function knownTermsIn(title) {
    const found = [];
    const push = function (t) {
      if (!t || t.length < 2) {
        if (t && IGNORE_SINGLE.has(t)) found.push(t);
        return;
      }
      if (K.TOPIC_GENERIC_GRAMS.has(t)) return;
      if (title.indexOf(t) !== -1 || title.toLowerCase().indexOf(t.toLowerCase()) !== -1) found.push(t);
    };
    (K.KNOWLEDGE_CORE || []).forEach(push);
    (K.QUALITY_UPS || []).forEach(push);
    return U.unique(found);
  }

  const GENERIC_PHRASES = [
    '从入门到精通', '入门到精通', '完整课程', '完整版', '一个视频', '一节课',
    '一集看懂', '带你', '讲透', '讲清楚', '全解析', '深度解析', '系统学习',
    '硬核科普', '保姆级', '干货', '全集', '合集', '视频教程',
    '第[一二三四五六七八九十0-9]+讲', '第[一二三四五六七八九十0-9]+课'
  ];
  const GENERIC_RE = new RegExp(GENERIC_PHRASES.join('|'), 'g');

  function clickbaitStripped(title) {
    let t = String(title || '');
    (K.CLICKBAIT_PATTERNS || []).forEach(function (p) {
      p.re.lastIndex = 0;
      t = t.replace(p.re, ' ');
    });
    t = t.replace(GENERIC_RE, ' ');
    return t.replace(/[【】\[\]（）()「」『』<>《》|｜/\\]+/g, ' ');
  }

  /**
   * 从标题中提取用于考古搜索的选题短语。
   * 例："【硬核科普】熵与信息论到底有多神？" -> "信息论 熵"
   */
  function fromTitle(title) {
    const cleaned = clickbaitStripped(title);
    const map = candidateMap(cleaned);
    const known = knownTermsIn(cleaned);
    const scored = [];

    map.forEach(function (c) {
      let score = Math.pow(c.len, 1.7) * (1 + Math.min(c.pos, 40) / 120);
      if (known.indexOf(c.term) !== -1) score *= 1.9;
      if (c.latin) score *= 1.15;
      if (c.term.length >= 5) score *= 1.1;
      scored.push({ term: c.term, score: score, pos: c.pos, len: c.len });
    });

    known.forEach(function (term) {
      if (map.has(term)) return;
      scored.push({
        term: term,
        score: Math.pow(Math.max(2, term.length), 1.7) * 2.1,
        pos: cleaned.indexOf(term) === -1 ? 0 : cleaned.indexOf(term),
        len: term.length
      });
    });

    scored.sort(function (a, b) { return b.score - a.score; });

    const picked = [];
    const isSub = function (a, b) {
      const al = a.toLowerCase();
      const bl = b.toLowerCase();
      return al !== bl && (al.indexOf(bl) !== -1 || bl.indexOf(al) !== -1);
    };
    for (let i = 0; i < scored.length && picked.length < 3; i++) {
      const cand = scored[i];
      if (picked.some(function (p) { return isSub(cand.term, p.term); })) continue;
      if (cand.term.length < 2 && !IGNORE_SINGLE.has(cand.term)) continue;
      picked.push(cand);
    }

    picked.sort(function (a, b) { return a.pos - b.pos; });
    let out = picked.map(function (p) { return p.term; }).join(' ');
    out = out.replace(/\s+/g, ' ').trim().slice(0, 24);
    if (!out) {
      out = U.cleanText(title).replace(/[^\u4e00-\u9fa5a-zA-Z0-9]+/g, ' ').trim().slice(0, 16);
    }
    return out;
  }

  function fromSearchQuery(query) {
    if (!query) return '';
    const q = String(query)
      .replace(/^["'“”「」]+|["'“”「」]+$/g, '')
      .replace(/[|｜]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
    return q.slice(0, 40);
  }

  function cleanQuery(query) {
    return fromSearchQuery(query).replace(/[<>]/g, '').trim();
  }

  BLF.Topic = {
    candidateTerms: candidateTerms,
    candidateMap: candidateMap,
    knownTermsIn: knownTermsIn,
    fromTitle: fromTitle,
    fromSearchQuery: fromSearchQuery,
    cleanQuery: cleanQuery,
    validGram: validGram
  };
})(typeof globalThis !== 'undefined' ? globalThis : this);
