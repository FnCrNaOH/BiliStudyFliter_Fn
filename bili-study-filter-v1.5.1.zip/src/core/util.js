/* B站学习净化器 · 基础工具（无 DOM 依赖，可在 Node 中单测） */
(function (root) {
  'use strict';
  const BLF = (root.BLF = root.BLF || {});

  const U = {};

  U.clamp = function (n, min, max) {
    n = Number(n);
    if (!Number.isFinite(n)) return min;
    return Math.min(max, Math.max(min, n));
  };

  U.round = function (n, digits) {
    const p = Math.pow(10, digits || 0);
    return Math.round(n * p) / p;
  };

  U.log10 = function (n) {
    return Math.log(Math.max(1, Number(n) || 0)) / Math.LN10;
  };

  /**
   * B 站时长格式：321:43 表示 321 分 43 秒（不是 321 小时）；
   * 1:02:03 才是时:分:秒。
   */
  U.parseDuration = function (value) {
    if (value == null || value === '') return 0;
    if (typeof value === 'number') {
      return Number.isFinite(value) && value >= 0 ? Math.round(value) : 0;
    }
    const s = String(value).trim().replace(/\s+/g, '');
    if (/^\d+$/.test(s)) return parseInt(s, 10);
    const parts = s.split(':');
    if (parts.length < 2 || parts.length > 3) return 0;
    const nums = parts.map(function (p) { return Number(p); });
    if (nums.some(function (n) { return !Number.isFinite(n) || n < 0; })) return 0;
    if (nums.length === 3) return nums[0] * 3600 + nums[1] * 60 + nums[2];
    return nums[0] * 60 + nums[1];
  };

  U.formatDuration = function (sec) {
    sec = Math.max(0, Math.round(Number(sec) || 0));
    const h = Math.floor(sec / 3600);
    const m = Math.floor((sec % 3600) / 60);
    const s = sec % 60;
    if (h > 0) return h + ':' + String(m).padStart(2, '0') + ':' + String(s).padStart(2, '0');
    return m + ':' + String(s).padStart(2, '0');
  };

  U.parseCount = function (value) {
    if (typeof value === 'number') return Number.isFinite(value) ? Math.round(value) : 0;
    if (!value) return 0;
    const s = String(value).replace(/,/g, '').trim();
    const m = s.match(/([\d.]+)\s*(亿|万|w|W|k|K)?/);
    if (!m) return 0;
    const n = Number(m[1]);
    if (!Number.isFinite(n)) return 0;
    const unit = m[2];
    if (unit === '亿') return Math.round(n * 1e8);
    if (unit === '万' || unit === 'w' || unit === 'W') return Math.round(n * 1e4);
    if (unit === 'k' || unit === 'K') return Math.round(n * 1e3);
    return Math.round(n);
  };

  U.formatCount = function (n) {
    n = Number(n) || 0;
    if (n >= 1e8) return U.round(n / 1e8, 1) + '亿';
    if (n >= 1e4) return U.round(n / 1e4, 1) + '万';
    return String(Math.round(n));
  };

  U.decodeEntities = function (s) {
    return String(s == null ? '' : s)
      .replace(/&amp;/g, '&')
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .replace(/&quot;/g, '"')
      .replace(/&#39;|&apos;/g, "'")
      .replace(/&nbsp;/g, ' ')
      .replace(/&#x([0-9a-f]+);/gi, function (_, hex) {
        try { return String.fromCodePoint(parseInt(hex, 16)); } catch (e) { return ''; }
      })
      .replace(/&#(\d+);/g, function (_, dec) {
        try { return String.fromCodePoint(parseInt(dec, 10)); } catch (e) { return ''; }
      });
  };

  U.stripHtml = function (s) {
    return U.decodeEntities(String(s == null ? '' : s).replace(/<[^>]*>/g, ''));
  };

  U.cleanText = function (s) {
    return U.stripHtml(s)
      .replace(/[\u200b-\u200f\u202a-\u202e\ufeff]/g, '')
      .replace(/\s+/g, ' ')
      .trim();
  };

  U.normalizeTitle = function (s) {
    return U.cleanText(s)
      .normalize('NFKC')
      .toLowerCase()
      .replace(/[\s\u3000]+/g, '');
  };

  U.hashString = function (s) {
    let h = 0x811c9dc5;
    const str = String(s);
    for (let i = 0; i < str.length; i++) {
      h ^= str.charCodeAt(i);
      h = Math.imul(h, 0x01000193);
    }
    return (h >>> 0).toString(16).padStart(8, '0');
  };

  U.debounce = function (fn, wait) {
    let timer = null;
    return function () {
      const args = arguments;
      const self = this;
      clearTimeout(timer);
      timer = setTimeout(function () { fn.apply(self, args); }, wait);
    };
  };

  U.throttle = function (fn, wait) {
    let last = 0;
    let timer = null;
    return function () {
      const now = Date.now();
      const args = arguments;
      const self = this;
      const remain = wait - (now - last);
      if (remain <= 0) {
        clearTimeout(timer);
        timer = null;
        last = now;
        fn.apply(self, args);
      } else if (!timer) {
        timer = setTimeout(function () {
          last = Date.now();
          timer = null;
          fn.apply(self, args);
        }, remain);
      }
    };
  };

  U.uid = function (prefix) {
    return (prefix || 'id') + '-' + Math.random().toString(36).slice(2, 9);
  };

  U.escapeHtml = function (s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  };

  U.escapeRegExp = function (s) {
    return String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  };

  U.unique = function (arr) {
    return Array.from(new Set(arr || []));
  };

  U.jaccard = function (a, b) {
    if (!a || !b || !a.size || !b.size) return 0;
    let inter = 0;
    const small = a.size <= b.size ? a : b;
    const large = small === a ? b : a;
    small.forEach(function (v) { if (large.has(v)) inter++; });
    return inter / (a.size + b.size - inter);
  };

  U.containment = function (small, large) {
    if (!small || !large || !small.size) return 0;
    let inter = 0;
    small.forEach(function (v) { if (large.has(v)) inter++; });
    return inter / small.size;
  };

  U.titleSimilarity = function (a, b) {
    if (!a || !b) return 0;
    return 0.6 * U.jaccard(a, b) + 0.4 * Math.max(U.containment(a, b), U.containment(b, a));
  };

  U.formatDate = function (ts) {
    if (!ts) return '';
    const d = new Date(Number(ts) * 1000);
    if (isNaN(d.getTime())) return '';
    const p = function (n) { return String(n).padStart(2, '0'); };
    return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate());
  };

  U.formatDateTime = function (ts) {
    if (!ts) return '';
    const d = new Date(Number(ts) * 1000);
    if (isNaN(d.getTime())) return '';
    const p = function (n) { return String(n).padStart(2, '0'); };
    return U.formatDate(ts) + ' ' + p(d.getHours()) + ':' + p(d.getMinutes());
  };

  U.todayKey = function (date) {
    const d = date || new Date();
    const p = function (n) { return String(n).padStart(2, '0'); };
    return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate());
  };

  U.ageYears = function (ts, now) {
    if (!ts) return 0;
    return Math.max(0, ((now || Date.now()) / 1000 - Number(ts)) / (365.25 * 86400));
  };

  U.sleep = function (ms) {
    return new Promise(function (resolve) { setTimeout(resolve, ms); });
  };

  U.truncate = function (s, n) {
    s = String(s == null ? '' : s);
    return s.length > n ? s.slice(0, n - 1) + '…' : s;
  };

  U.toTs = function (dateStr, endOfDay) {
    if (!dateStr) return 0;
    const m = String(dateStr).match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if (!m) return 0;
    const d = new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]), endOfDay ? 23 : 0, endOfDay ? 59 : 0, endOfDay ? 59 : 0);
    return Math.floor(d.getTime() / 1000);
  };

  BLF.U = U;
})(typeof globalThis !== 'undefined' ? globalThis : this);
