/* B站学习净化器 · 设置页 */
(function () {
  'use strict';
  const BLF = window.BLF;
  const U = BLF.U;

  let settings = null;
  let profile = null;
  let syncingProfile = false;
  let saveTimer = null;
  let statusTimer = null;

  function $(sel, root) {
    if (sel && sel[0] !== '#' && sel[0] !== '.' && sel[0] !== '[') sel = '#' + sel;
    return (root || document).querySelector(sel);
  }
  function $$(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  function getPath(obj, path) {
    return path.split('.').reduce(function (acc, key) {
      return acc == null ? undefined : acc[key];
    }, obj);
  }

  function setPath(obj, path, value) {
    const keys = path.split('.');
    let cur = obj;
    for (let i = 0; i < keys.length - 1; i++) {
      if (!cur[keys[i]] || typeof cur[keys[i]] !== 'object') cur[keys[i]] = {};
      cur = cur[keys[i]];
    }
    cur[keys[keys.length - 1]] = value;
  }

  function status(text, saving) {
    const el = $('save-status');
    el.textContent = text;
    el.classList.toggle('is-saving', !!saving);
    clearTimeout(statusTimer);
    statusTimer = setTimeout(function () {
      el.textContent = '已同步';
      el.classList.remove('is-saving');
    }, 1600);
  }

  async function init() {
    settings = await BLF.Settings.load();
    profile = await BLF.Store.get('blfProfile', null);
    if (BLF.Store.isDemo) {
      try {
        await BLF.Store.set('blfStats', { day: U.todayKey(), flagged: 15, revealed: 2, archaeology: 3, blocked: 9 });
      } catch (e) { /* ignore */ }
    }
    try {
      const manifest = chrome.runtime.getManifest();
      $('version').textContent = 'v' + manifest.version;
    } catch (e) { /* demo/file */ }
    renderAll();
    bind();
    await renderStats();
    renderCache();
    renderStudyCache();
    renderProfileCard();
    BLF.Store.onChange(function (key, value) {
      if (key !== 'blfProfile') return;
      profile = value || null;
      renderProfileCard();
      renderDomainChips();
    });
  }

  function renderAll() {
    $$('[data-path]').forEach(function (el) {
      const path = el.getAttribute('data-path');
      const v = getPath(settings, path);
      if (el.type === 'checkbox') {
        el.checked = !!v;
      } else if (el.tagName === 'TEXTAREA') {
        el.value = Array.isArray(v) ? v.join('\n') : (v == null ? '' : String(v));
      } else if (el.tagName === 'SELECT') {
        el.value = v == null ? '' : String(v);
      } else {
        el.value = v == null ? '' : String(v);
        updateOutput(el, v);
      }
    });
    renderMode();
    renderTests();
    renderProfileCard();
    renderDomainChips();
    renderStudyTopics();
    renderAppearancePreview();
  }

  function renderMode() {
    $$('#mode-seg button').forEach(function (b) {
      b.classList.toggle('is-active', b.getAttribute('data-mode') === settings.mode);
    });
  }

  function updateOutput(el, value) {
    if (!el || !el.getAttribute) return;
    const path = el.getAttribute('data-path');
    const out = document.querySelector('[data-out="' + path + '"]');
    if (!out) return;
    const fmt = el.getAttribute('data-format');
    if (fmt === 'duration') out.textContent = U.formatDuration(Number(value) || 0);
    else if (fmt === 'decimal') out.textContent = (Math.round(Number(value) * 10) / 10).toFixed(1);
    else if (fmt === 'percent') out.textContent = Math.round((Number(value) || 0) * 100) + '%';
    else out.textContent = String(Number(value) || 0);
  }

  function bind() {
    $$('[data-path]').forEach(function (el) {
      const path = el.getAttribute('data-path');
      const evt = el.type === 'range' || el.tagName === 'TEXTAREA' ? 'input' : 'change';
      el.addEventListener(evt, function () {
        let value;
        if (el.type === 'checkbox') value = el.checked;
        else if (el.tagName === 'SELECT') value = el.value;
        else if (el.tagName === 'TEXTAREA') {
          value = el.value.split('\n').map(function (s) { return s.trim(); }).filter(Boolean);
        } else value = el.value;
        setPath(settings, path, value);
        if (el.type === 'range') updateOutput(el, value);
        saveSoon();
        if (path === 'enabled' || path === 'focusMode' || path.indexOf('rules.') === 0 || path.indexOf('thresholds.') === 0) {
          renderTests();
        }
        if (path.indexOf('appearance.') === 0) renderAppearancePreview();
      });
    });

    $$('#mode-seg button').forEach(function (b) {
      b.addEventListener('click', function () {
        settings.mode = b.getAttribute('data-mode');
        renderMode();
        saveSoon();
        renderTests();
      });
    });

    $('clear-arch-cache').addEventListener('click', async function () {
      await BLF.Store.remove('blfArchCache');
      renderCache();
      status('缓存已清除');
    });

    $('export-config').addEventListener('click', exportConfig);
    $('import-config').addEventListener('click', importConfig);
    $('reset-all').addEventListener('click', resetAll);

    $('sync-profile').addEventListener('click', syncProfileFromTab);
    $('clear-profile').addEventListener('click', clearProfile);
    $('auto-suggest').addEventListener('click', autoSuggestInterests);
    $('deepen-chips').addEventListener('click', function (e) { toggleDomain(e, 'deepen'); });
    $('broaden-chips').addEventListener('click', function (e) { toggleDomain(e, 'broaden'); });
    $('study-topics').addEventListener('click', function (e) {
      const btn = e.target.closest('[data-study-topic]');
      if (!btn) return;
      const id = btn.getAttribute('data-study-topic');
      const list = (settings.studyFeed.topics || []).slice();
      const at = list.indexOf(id);
      if (at >= 0) {
        if (list.length <= 1) { status('至少保留一个科技领域'); return; }
        list.splice(at, 1);
      } else {
        list.push(id);
      }
      settings.studyFeed.topics = list;
      renderStudyTopics();
      saveSoon();
    });
    $('refresh-study').addEventListener('click', refreshStudy);
    $$('#bg-presets [data-bg-preset]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        applyBgPreset(btn.getAttribute('data-bg-preset'));
      });
    });
    $('clear-study').addEventListener('click', async function () {
      await BLF.StudyFeed.clearCache();
      renderStudyCache();
      status('科技缓存已清除');
    });

    ['test-title', 'test-duration', 'test-author', 'test-vertical'].forEach(function (id) {
      const el = $(id);
      el.addEventListener('input', renderTests);
      el.addEventListener('change', renderTests);
    });
  }

  function renderAppearancePreview() {
    const el = $('bg-preview');
    if (!el || !settings || !settings.appearance) return;
    const ap = settings.appearance;
    let bg = 'linear-gradient(135deg, #2b3442 0%, #171e2a 100%)';
    if (ap.background === 'color') {
      bg = ap.color || '#eef4fb';
    } else if (ap.background === 'gradient') {
      bg = ap.gradient || bg;
    } else if (ap.background === 'image') {
      const safe = String(ap.imageUrl || '').replace(/["\\\n\r]/g, '');
      if (/^(https?:\/\/|data:image\/)/i.test(safe)) bg = 'url("' + safe + '") center / cover no-repeat';
      else bg = ap.gradient || bg;
    }
    el.style.background = bg;
    el.style.backgroundSize = 'cover';
    el.style.backgroundPosition = 'center';
  }

  function applyBgPreset(name) {
    if (!settings || !settings.appearance) return;
    const ap = settings.appearance;
    if (name === 'none') {
      ap.background = 'none';
    } else if (name === 'mist') {
      ap.background = 'gradient';
      ap.gradient = 'linear-gradient(135deg, #eef4fb 0%, #dfeaf7 55%, #f7f1f7 100%)';
    } else if (name === 'warm') {
      ap.background = 'gradient';
      ap.gradient = 'linear-gradient(135deg, #fbf7f0 0%, #f3ece2 55%, #f8f3ee 100%)';
    } else if (name === 'dark') {
      ap.background = 'gradient';
      ap.gradient = 'linear-gradient(135deg, #101522 0%, #1b2233 55%, #242d40 100%)';
    } else if (name === 'image') {
      ap.background = 'image';
      if (!ap.imageUrl) status('请在上方填写图片 URL');
    }
    saveSoon();
    renderAll();
    renderAppearancePreview();
  }

  function renderStudyTopics() {
    const wrap = $('study-topics');
    if (!wrap || !BLF.StudyFeed) return;
    const active = (settings.studyFeed && settings.studyFeed.topics) || [];
    wrap.innerHTML = BLF.StudyFeed.TOPICS.map(function (t) {
      return '<button type="button" class="chip' + (active.indexOf(t.id) !== -1 ? ' is-active' : '') +
        '" data-study-topic="' + t.id + '">' + t.label + '</button>';
    }).join('');
  }

  async function renderStudyCache() {
    const el = $('study-cache-status');
    if (!el) return;
    const cache = await BLF.Store.get('blfStudyPool', null);
    const n = cache && Array.isArray(cache.items) ? cache.items.length : 0;
    el.textContent = n ? n + ' 条科技视频 · 缓存 ' + (settings.studyFeed.cacheHours || 12) + 'h' : '暂无科技缓存';
  }

  function refreshStudy() {
    status('正在刷新科技池…', true);
    findBiliTab(function (tab, err) {
      if (!tab) {
        status(err || '请先打开一个 B 站页面');
        return;
      }
      try {
        chrome.tabs.sendMessage(tab.id, { type: 'blf:refresh-study' }, function (res) {
          if (chrome.runtime.lastError) {
            status('刷新失败：' + chrome.runtime.lastError.message);
            return;
          }
          if (res && res.ok) {
            status('科技池已刷新 · ' + (res.count || 0) + ' 条');
            renderStudyCache();
          } else {
            status((res && res.error) || '刷新失败');
          }
        });
      } catch (e) {
        status('刷新失败：' + e.message);
      }
    });
  }

  function renderProfileCard() {
    if (!settings) return;
    const statusEl = $('profile-status');
    const summaryEl = $('profile-summary');
    if (!statusEl || !summaryEl) return;
    if (syncingProfile) {
      statusEl.textContent = '正在读取账号数据…（关注 / 收藏夹）';
      summaryEl.textContent = '请求会带上你当前的 B 站登录态；原始列表不会保存。';
    } else if (!profile) {
      statusEl.textContent = '未同步账号画像';
      summaryEl.textContent = '同步后显示关注/收藏的领域占比；也可以在下方手动选择深耕/拓界领域。';
    } else {
      const when = profile.syncedAt ? U.formatDate(Math.floor(profile.syncedAt / 1000)) : '';
      const name = profile.uname ? '@' + profile.uname : '你的账号';
      const src = profile.sources || {};
      statusEl.textContent = (profile.manual ? '手动兴趣（未同步账号）' : '已同步 ' + name + (when ? ' · ' + when : ''));
      const domains = (profile.domains || []).slice(0, 4).map(function (d) {
        return d.label + ' ' + Math.round((d.share || 0) * 100) + '%';
      });
      summaryEl.textContent = (domains.join(' · ') || '没有识别出明显领域') +
        (profile.manual ? '' : ' ｜ 关注 ' + (src.followings || 0) + ' · 收藏夹 ' + (src.folders || 0) + ' · 收藏 ' + (src.favorites || 0) +
        (src.history ? ' · 历史 ' + src.history : ''));
    }
    const syncBtn = $('sync-profile');
    if (syncBtn) {
      syncBtn.disabled = syncingProfile;
      syncBtn.textContent = syncingProfile ? '同步中…' : '同步账号画像';
    }
    const details = $('profile-details');
    const groupsEl = $('profile-groups');
    const foldersEl = $('profile-folders');
    if (details && groupsEl && foldersEl) {
      const groups = (profile && profile.followGroups) || [];
      const folders = (profile && profile.folders) || [];
      const has = !!(profile && !profile.manual && (groups.length || folders.length));
      details.hidden = !has;
      if (has) {
        const label = function (ids) {
          return (ids || []).map(function (id) {
            const d = BLF.Domains.get(id);
            return d ? d.label : id;
          }).join('、');
        };
        groupsEl.innerHTML = groups.length
          ? '<div class="profile-detail-row"><b>关注分组</b><span></span></div>' + groups.map(function (g) {
            return '<div class="profile-detail-row"><b>' + U.escapeHtml(g.name) + '</b><span>' +
              g.count + ' 位 · ' + U.escapeHtml(label(g.domains)) + '</span></div>';
          }).join('')
          : '';
        foldersEl.innerHTML = folders.length
          ? '<div class="profile-detail-row" style="margin-top:6px"><b>收藏夹</b><span></span></div>' + folders.map(function (f) {
            return '<div class="profile-detail-row"><b>' + U.escapeHtml(f.title) + '</b><span>' +
              f.count + ' 条 · ' + U.escapeHtml(label(f.domains)) + '</span></div>';
          }).join('')
          : '';
      } else {
        groupsEl.innerHTML = '';
        foldersEl.innerHTML = '';
      }
    }
  }

  function renderDomainChips() {
    if (!settings || !window.BLF.Domains) return;
    const deep = settings.explore.deepen || [];
    const broad = settings.explore.broaden || [];
    const deepEl = $('deepen-chips');
    const broadEl = $('broaden-chips');
    if (!deepEl || !broadEl) return;
    const make = function (role, active) {
      return BLF.Domains.LIST.map(function (d) {
        return '<button class="chip' + (active.indexOf(d.id) !== -1 ? ' is-active' : '') +
          '" data-domain="' + d.id + '" data-role="' + role + '">' + U.escapeHtml(d.label) + '</button>';
      }).join('');
    };
    deepEl.innerHTML = make('deepen', deep);
    broadEl.innerHTML = make('broaden', broad);
  }

  function toggleDomain(event, role) {
    const btn = event.target.closest ? event.target.closest('[data-domain]') : null;
    if (!btn) return;
    const id = btn.getAttribute('data-domain');
    const list = settings.explore[role].slice();
    const idx = list.indexOf(id);
    if (idx === -1) {
      list.push(id);
      const other = role === 'deepen' ? 'broaden' : 'deepen';
      settings.explore[other] = settings.explore[other].filter(function (x) { return x !== id; });
    } else {
      list.splice(idx, 1);
    }
    settings.explore[role] = list;
    saveSoon();
    renderDomainChips();
  }

  function autoSuggestInterests() {
    if (!profile) { status('先同步账号画像'); return; }
    let deep = (profile.auto && profile.auto.deepen) || [];
    let broad = (profile.auto && profile.auto.broaden) || [];
    if (!deep.length) deep = BLF.Domains.suggestDeepen(profile.domains || [], 2);
    if (!broad.length) broad = BLF.Domains.suggestBroaden(profile.domains || [], 2);
    settings.explore.deepen = BLF.Domains.validIds(deep).slice(0, 2);
    settings.explore.broaden = BLF.Domains.validIds(broad).filter(function (id) {
      return settings.explore.deepen.indexOf(id) === -1;
    }).slice(0, 2);
    saveSoon();
    renderDomainChips();
    renderProfileCard();
    status('已按画像填入兴趣');
  }

  function findBiliTab(callback) {
    if (typeof chrome === 'undefined' || !chrome.tabs || !chrome.tabs.query) {
      callback(null, '预览页不支持同步');
      return;
    }
    try {
      chrome.tabs.query({
        url: ['*://www.bilibili.com/*', '*://search.bilibili.com/*', '*://space.bilibili.com/*']
      }, function (tabs) {
        if (chrome.runtime.lastError) {
          callback(null, '请先打开一个 B 站标签页');
          return;
        }
        if (!tabs || !tabs.length) {
          callback(null, '请先打开一个 B 站标签页');
          return;
        }
        callback(tabs[0], null);
      });
    } catch (e) {
      callback(null, '无法查找 B 站标签页');
    }
  }

  function syncProfileFromTab() {
    if (syncingProfile) return;
    findBiliTab(function (tab, err) {
      if (!tab) { status(err || '没有可用的 B 站标签页'); return; }
      syncingProfile = true;
      renderProfileCard();
      try {
        chrome.tabs.sendMessage(tab.id, { type: 'blf:sync-profile' }, async function (res) {
          syncingProfile = false;
          if (chrome.runtime.lastError) {
            status('同步失败：请刷新 B 站页面后重试');
            renderProfileCard();
            return;
          }
          if (!res || !res.ok) {
            status((res && res.error && res.error.message) || '同步失败');
            renderProfileCard();
            return;
          }
          profile = res.profile || await BLF.Store.get('blfProfile', null);
          renderProfileCard();
          renderDomainChips();
          status('账号画像已同步');
        });
      } catch (e) {
        syncingProfile = false;
        renderProfileCard();
        status('同步失败：' + (e && e.message ? e.message : '未知错误'));
      }
    });
  }

  async function clearProfile() {
    if (!confirm('清除本机的账号画像和探索缓存？不会影响 B 站账号本身。')) return;
    await BLF.Store.remove('blfProfile');
    await BLF.Store.remove('blfExploreCache');
    profile = null;
    renderProfileCard();
    status('画像已清除');
  }

  function saveSoon() {
    status('保存中…', true);
    clearTimeout(saveTimer);
    saveTimer = setTimeout(save, 320);
  }

  async function save() {
    if (!settings) return;
    settings = BLF.Settings.normalize(settings);
    await BLF.Store.set('blfSettings', settings);
    status('已保存');
    renderCache();
    renderStudyCache();
    renderProfileCard();
    renderDomainChips();
  }

  async function renderStats() {
    const stored = await BLF.Store.get('blfStats', null);
    const today = U.todayKey();
    const s = stored && stored.day === today ? stored : { flagged: 0, revealed: 0, archaeology: 0 };
    $('today-flagged').textContent = String(s.flagged || 0);
    $('today-revealed').textContent = String(s.revealed || 0);
    $('today-arch').textContent = String(s.archaeology || 0);
  }

  async function renderCache() {
    const cache = await BLF.Store.get('blfArchCache', {});
    const n = cache && typeof cache === 'object' ? Object.keys(cache).length : 0;
    $('cache-count').textContent = n ? n + ' 条缓存' : '暂无缓存';
  }

  function decisionActionLabel(action) {
    return { blur: '模糊', dim: '淡化', hide: '隐藏', badge: '仅角标', ok: '放行' }[action] || action;
  }

  function renderTests() {
    if (!settings) return;
    const box = $('test-result');
    const title = $('test-title').value.trim();
    if (!title) {
      box.innerHTML = '<div class="tester__empty">修改标题或时长，实时查看判定结果。</div>';
      return;
    }
    const item = {
      id: 'test',
      bvid: 'BVtest',
      title: title,
      author: $('test-author').value.trim(),
      mid: 0,
      durationSec: U.parseDuration($('test-duration').value),
      views: 0,
      danmaku: 0,
      likes: 0,
      favorites: 0,
      isVertical: $('test-vertical').checked,
      context: 'feed',
      tags: '',
      description: ''
    };
    const decision = BLF.Scoring.analyze(item, settings);
    const action = BLF.Scoring.effectiveAction(decision, settings);
    const labels = decision.labels || [];
    const why = decision.reasons || [];
    box.innerHTML =
      '<div class="result-top">' +
        '<span class="result-action" data-a="' + action + '">' + decisionActionLabel(action) + '</span>' +
        '<span class="result-score">学习价值 ' + decision.quality + ' / 100 · 强度 ' + decision.severity + '</span>' +
      '</div>' +
      '<div class="result-title">' + U.escapeHtml(title) + '</div>' +
      '<div class="result-labels">' + labels.map(function (l) {
        return '<span class="pill" data-tone="' + U.escapeHtml(l.tone || 'gray') + '">' + U.escapeHtml(l.text) + '</span>';
      }).join('') + '</div>' +
      (why.length ? '<div class="result-why">' + why.slice(0, 5).map(function (w) {
        return '<div>· ' + U.escapeHtml(w) + '</div>';
      }).join('') + '</div>' : '');
  }

  function exportConfig() {
    const payload = {
      type: 'bili-study-filter-settings',
      version: 1,
      exportedAt: new Date().toISOString(),
      settings: settings
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'bili-study-filter-settings.json';
    document.body.appendChild(a);
    a.click();
    setTimeout(function () {
      URL.revokeObjectURL(a.href);
      a.remove();
    }, 1000);
    status('已导出');
  }

  async function importConfig() {
    const raw = $('import-json').value.trim();
    if (!raw) { status('没有内容可导入'); return; }
    let data;
    try {
      data = JSON.parse(raw);
    } catch (e) {
      status('JSON 格式错误');
      return;
    }
    const incoming = data && data.settings ? data.settings : data;
    if (!incoming || typeof incoming !== 'object') { status('配置无效'); return; }
    if (!confirm('导入会覆盖当前配置，确定继续？')) return;
    settings = BLF.Settings.normalize(incoming);
    await BLF.Store.set('blfSettings', settings);
    renderAll();
    $('import-json').value = '';
    status('已导入');
  }

  async function resetAll() {
    if (!confirm('恢复默认设置？白名单和自定义词也会清空。')) return;
    settings = BLF.Settings.normalize(JSON.parse(JSON.stringify(BLF.Settings.DEFAULT_SETTINGS)));
    await BLF.Store.set('blfSettings', settings);
    renderAll();
    status('已恢复默认');
  }

  init().catch(function (err) {
    console.error(err);
    status('初始化失败');
  });
})();
