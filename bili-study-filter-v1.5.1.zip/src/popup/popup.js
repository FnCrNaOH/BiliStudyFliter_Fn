/* B站学习净化器 · Popup */
(function () {
  'use strict';
  const BLF = window.BLF;
  const U = BLF.U;

  let settings = null;
  let pageInfo = null;
  let tabId = null;

  function $(id) { return document.getElementById(id); }

  async function init() {
    settings = await BLF.Settings.load();
    renderSettings();
    const preview = typeof chrome === 'undefined' || !chrome.tabs || !chrome.tabs.query;
    if (preview) {
      try {
        await BLF.Store.set('blfStats', { day: U.todayKey(), flagged: 14, revealed: 2, archaeology: 3, blocked: 9 });
      } catch (e) { /* ignore */ }
      await renderStats();
      pageInfo = {
        contextLabel: '首页推荐',
        topic: '信息论',
        stats: { scanned: 20, flagged: 14, clusters: 2 }
      };
      renderPage();
      $('open-panel').disabled = true;
      $('open-arch').disabled = true;
      $('open-explore').disabled = true;
      return;
    }
    await renderStats();
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    const tab = tabs && tabs[0];
    tabId = tab ? tab.id : null;
    if (tab && /https?:\/\/[^/]*bilibili\.com\//.test(tab.url || '')) {
      pageInfo = await getPageInfo();
      renderPage();
    } else {
      renderNoPage('当前标签页不是 B 站');
    }
  }

  function getPageInfo() {
    return new Promise(function (resolve) {
      if (typeof tabId !== 'number') { resolve(null); return; }
      try {
        chrome.tabs.sendMessage(tabId, { type: 'blf:page-info' }, function (res) {
          if (chrome.runtime.lastError) { resolve(null); return; }
          resolve(res || null);
        });
      } catch (e) { resolve(null); }
    });
  }

  async function renderStats() {
    const stored = await BLF.Store.get('blfStats', null);
    const today = U.todayKey();
    const stats = stored && stored.day === today ? stored : { flagged: 0, revealed: 0, archaeology: 0 };
    $('stat-flagged').textContent = String(stats.flagged || 0);
    $('stat-revealed').textContent = String(stats.revealed || 0);
    $('stat-arch').textContent = String(stats.archaeology || 0);
  }

  function renderSettings() {
    const enabled = !!settings.enabled;
    const sw = $('enabled');
    sw.classList.toggle('is-on', enabled);
    sw.setAttribute('aria-pressed', enabled ? 'true' : 'false');
    $('mode').querySelectorAll('button').forEach(function (b) {
      b.classList.toggle('is-active', b.getAttribute('data-mode') === settings.mode);
    });
    document.querySelectorAll('.rule').forEach(function (b) {
      const key = b.getAttribute('data-rule');
      const on = key === 'focusMode' ? settings.focusMode : settings.rules[key];
      b.classList.toggle('is-active', !!on);
    });
  }

  function renderPage() {
    const info = pageInfo;
    $('page-sub').textContent = info
      ? info.contextLabel + (info.topic ? ' · ' + info.topic : '')
      : '已连接 B 站，刷新页面后生效';
    if (!info) { renderNoPage('请刷新 B 站页面以连接扩展'); return; }
    $('hero').classList.toggle('is-off', !settings.enabled);
    $('hero-count').textContent = settings.enabled ? String((info.stats && info.stats.flagged) || 0) : '—';
    let line = '扫描 ' + ((info.stats && info.stats.scanned) || 0) + ' 个视频 · ' +
      ((info.stats && info.stats.clusters) || 0) + ' 个同题组' +
      (info.paused ? ' · 本页已暂停' : '');
    if (info.diversity && info.diversity.topLabel) {
      line += ' · ' + info.diversity.topLabel + ' ' + Math.round((info.diversity.topShare || 0) * 100) + '%';
    }
    $('hero-page').textContent = line;
  }

  function renderNoPage(message) {
    $('page-sub').textContent = message;
    $('hero').classList.add('is-off');
    $('hero-count').textContent = '—';
    $('hero-page').textContent = '只在 bilibili.com 页面工作';
    $('open-panel').disabled = true;
    $('open-arch').disabled = true;
    $('open-explore').disabled = true;
  }

  async function save() {
    settings = BLF.Settings.normalize(settings);
    await BLF.Store.set('blfSettings', settings);
    renderSettings();
  }

  async function refreshPageInfo() {
    if (tabId == null) return;
    pageInfo = await getPageInfo();
    renderPage();
  }

  $('enabled').addEventListener('click', async function () {
    settings.enabled = !settings.enabled;
    await save();
    renderSettings();
    if (settings.enabled && tabId != null) {
      try { chrome.tabs.sendMessage(tabId, { type: 'blf:open-panel' }); } catch (e) { /* ignore */ }
    }
    setTimeout(refreshPageInfo, 350);
  });

  $('mode').addEventListener('click', async function (e) {
    const btn = e.target.closest('[data-mode]');
    if (!btn) return;
    settings.mode = btn.getAttribute('data-mode');
    await save();
  });

  document.querySelectorAll('.rule').forEach(function (btn) {
    btn.addEventListener('click', async function () {
      const key = btn.getAttribute('data-rule');
      if (key === 'focusMode') settings.focusMode = !settings.focusMode;
      else settings.rules[key] = !settings.rules[key];
      await save();
      setTimeout(refreshPageInfo, 200);
    });
  });

  $('open-panel').addEventListener('click', function () {
    if (tabId == null) return;
    try {
      chrome.tabs.sendMessage(tabId, { type: 'blf:open-panel' }, function () { window.close(); });
    } catch (e) { window.close(); }
  });

  $('open-arch').addEventListener('click', function () {
    if (tabId == null) return;
    const topic = pageInfo && pageInfo.topic;
    try {
      chrome.tabs.sendMessage(tabId, { type: 'blf:open-archaeology', topic: topic }, function () { window.close(); });
    } catch (e) { window.close(); }
  });

  $('open-explore').addEventListener('click', function () {
    if (tabId == null) return;
    try {
      chrome.tabs.sendMessage(tabId, { type: 'blf:open-explore' }, function () { window.close(); });
    } catch (e) { window.close(); }
  });

  $('open-options').addEventListener('click', function () {
    chrome.runtime.openOptionsPage();
  });

  init().catch(function (err) {
    console.error(err);
    renderNoPage('初始化失败：' + (err && err.message ? err.message : '未知错误'));
  });
})();
