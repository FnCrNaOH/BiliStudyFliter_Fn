import { readFileSync } from 'node:fs';
import vm from 'node:vm';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import test from 'node:test';
import assert from 'node:assert/strict';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const FILES = [
  'src/core/util.js',
  'src/core/keywords.js',
  'src/core/store.js',
  'src/core/settings.js',
  'src/core/topic.js',
  'src/core/scoring.js',
  'src/core/cluster.js',
  'src/core/archaeology.js',
  'src/core/api.js'
];

const ctx = {
  console,
  URLSearchParams,
  URL,
  Date,
  Math,
  JSON,
  Number,
  String,
  Object,
  Array,
  Set,
  Map,
  RegExp,
  Promise,
  parseInt,
  parseFloat,
  isNaN,
  Intl,
  setTimeout,
  clearTimeout
};
ctx.globalThis = ctx;
ctx.window = {
  _listeners: {},
  _requests: [],
  _mode: 'ok',
  addEventListener(type, fn) {
    this._listeners[type] = this._listeners[type] || [];
    this._listeners[type].push(fn);
  },
  postMessage(msg) {
    if (!msg || msg.__blf !== 'req') return;
    this._requests.push(msg.url);
    const mode = this._mode;
    setTimeout(() => {
      const url = new URL(msg.url);
      const keyword = url.searchParams.get('keyword');
      let payload;
      if (mode === '412') {
        payload = { __blf: 'res', id: msg.id, ok: false, httpStatus: 412, code: -412, message: '风控' };
      } else {
        payload = {
          __blf: 'res',
          id: msg.id,
          ok: true,
          httpStatus: 200,
          code: 0,
          message: 'OK',
          data: {
            numResults: 3,
            result: [
              {
                bvid: 'BVold', title: '信息论 公开课 第一讲', author: '老师', mid: 1,
                duration: '60:00', pubdate: 1546300800, play: 1000000,
                favorites: 50000, like: 30000, video_review: 1000,
                description: '系统讲解信息论', tag: '公开课'
              },
              {
                bvid: 'BVolder', title: '信息熵的直观理解', author: 'UP', mid: 2,
                duration: '20:00', pubdate: 1577836800, play: 100000,
                favorites: 1000, like: 2000, video_review: 100,
                description: '', tag: ''
              },
              {
                bvid: 'BVnew', title: '2024 最新信息论课程', author: 'UP', mid: 3,
                duration: '60:00', pubdate: 1704067200, play: 5000000,
                favorites: 100000, like: 100000, video_review: 10000,
                description: '', tag: ''
              }
            ]
          }
        };
      }
      try {
        ctx.window._listeners.message.forEach(fn => fn({ source: ctx.window, data: payload }));
      } catch (e) {
        console.error('FAKE RESPONSE HANDLER ERROR', e);
      }
    }, 0);
  }
};
vm.createContext(ctx);
for (const file of FILES) {
  vm.runInContext(readFileSync(path.join(ROOT, file), 'utf8'), ctx, { filename: file });
}
const BLF = ctx.BLF;
const { Api, Settings, Store, U } = BLF;
Store.isDemo = false;

function settings() {
  const s = Settings.normalize(Settings.merge(Settings.DEFAULT_SETTINGS, {
    archaeology: { pages: 1, minDuration: 600, cacheHours: 24, results: 12 }
  }));
  return s;
}

test('考古 API 客户端：检索、过滤、排序与缓存', async () => {
  await Api.clearCache();
  const s = settings();
  let progress = 0;
  const first = await Api.archaeology('信息论', s, {
    force: true,
    onProgress: () => { progress++; }
  });
  assert.equal(progress, 1);
  assert.equal(first.cached, false);
  assert.equal(first.total, 2);
  assert.equal(first.tooNew, 1);
  assert.equal(first.items[0].bvid, 'BVold');
  assert.equal(first.items.length, 2);
  assert.match(ctx.window._requests[0], new RegExp('pubtime_end_s=' + U.toTs(s.archaeology.cutoff, true)));
  assert.match(ctx.window._requests[0], /keyword=%E4%BF%A1%E6%81%AF%E8%AE%BA/);

  const second = await Api.archaeology('信息论', s, { force: false });
  assert.equal(second.cached, true);
  assert.equal(ctx.window._requests.length, 1);
  assert.equal(await Api.cacheCount(), 1);
});

test('考古 API 客户端：412 风控错误带提示', async () => {
  await Api.clearCache();
  ctx.window._mode = '412';
  const s = settings();
  await assert.rejects(
    () => Api.archaeology('熵', s, { force: true }),
    (err) => {
      assert.equal(err.code, -412);
      assert.match(err.message, /风控/);
      return true;
    }
  );
  ctx.window._mode = 'ok';
});
