import { readFileSync } from 'node:fs';
import vm from 'node:vm';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import test from 'node:test';
import assert from 'node:assert/strict';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const FILES = [
  'src/core/util.js',
  'src/core/keywords.js',
  'src/core/settings.js',
  'src/core/topic.js',
  'src/core/scoring.js',
  'src/core/cluster.js',
  'src/core/archaeology.js'
];

const ctx = {
  console,
  URLSearchParams,
  URL,
  Date,
  Math,
  JSON,
  Number,
  String,
  Object,
  Array,
  Set,
  Map,
  RegExp,
  parseInt,
  parseFloat,
  isNaN,
  Intl
};
ctx.globalThis = ctx;
vm.createContext(ctx);
for (const file of FILES) {
  const code = readFileSync(path.join(ROOT, file), 'utf8');
  vm.runInContext(code, ctx, { filename: file });
}
const BLF = ctx.BLF;
const { U, Keywords: K, Scoring, Cluster, Topic, Archaeology, Settings } = BLF;

function item(overrides = {}) {
  return Object.assign({
    id: 'BVtest',
    bvid: 'BVtest',
    title: '普通视频',
    author: 'UP',
    mid: 1,
    durationSec: 600,
    views: 10000,
    danmaku: 100,
    likes: 500,
    favorites: 200,
    pubdate: 1600000000,
    isVertical: false,
    context: 'feed',
    tags: '',
    description: '',
    url: 'https://www.bilibili.com/video/BVtest'
  }, overrides);
}

function settings(overrides = {}) {
  return Settings.normalize(Settings.merge(Settings.DEFAULT_SETTINGS, overrides));
}

test('时长解析：B站 MM:SS 与 HH:MM:SS 两种格式', () => {
  assert.equal(U.parseDuration('321:43'), 321 * 60 + 43);
  assert.equal(U.parseDuration('15:1'), 15 * 60 + 1);
  assert.equal(U.parseDuration('1:02:03'), 3723);
  assert.equal(U.parseDuration('0:45'), 45);
  assert.equal(U.parseDuration('12:05'), 725);
  assert.equal(U.parseDuration(600), 600);
  assert.equal(U.parseDuration(''), 0);
});

test('播放量/弹幕量解析与格式化', () => {
  assert.equal(U.parseCount('128.5万'), 1285000);
  assert.equal(U.parseCount('1.2亿'), 120000000);
  assert.equal(U.parseCount('8600'), 8600);
  assert.equal(U.parseCount('3.2k'), 3200);
  assert.equal(U.parseCount('--'), 0);
  assert.equal(U.formatDuration(19303), '5:21:43');
  assert.equal(U.formatDuration(725), '12:05');
  assert.equal(U.formatCount(1285000), '128.5万');
});

test('标题清洗：HTML 高亮与实体', () => {
  assert.equal(U.cleanText('<em class="keyword">信息</em>熵 &amp; 编码'), '信息熵 & 编码');
  assert.equal(U.cleanText('  A\n\tB  '), 'A B');
});

test('标题党特征识别', () => {
  const a = K.clickbait('注意看，这个男人叫小帅');
  assert.ok(a.score >= 1.6);
  const b = K.clickbait('震惊！99%的人不知道的真相');
  assert.ok(b.score >= 2);
  const c = K.clickbait('信息论入门：熵、互信息与信道容量');
  assert.equal(c.score, 0);
});

test('游戏短视频：短则模糊，长则仅标注', () => {
  const short = Scoring.analyze(item({ title: '王者荣耀 新英雄 五杀高能名场面', durationSec: 151 }), settings());
  assert.equal(short.severity, 'high');
  assert.equal(short.category, 'gaming');
  assert.equal(Scoring.effectiveAction(short, settings()), 'blur');

  const long = Scoring.analyze(item({ title: '王者荣耀 十年发展史纪录片', durationSec: 3600 }), settings());
  assert.equal(long.severity, 'low');
  assert.notEqual(Scoring.effectiveAction(long, settings()), 'blur');
});

test('竖屏短视频直接高优先级', () => {
  const d = Scoring.analyze(item({ title: '哈哈哈哈这猫也太离谱了', durationSec: 45, isVertical: true }), settings());
  assert.equal(d.severity, 'high');
  assert.ok(d.labels.some(l => l.id === 'vertical'));
});

test('AI 营销号与正规 AI 课程区分', () => {
  const slop = Scoring.analyze(item({
    title: 'AI 生成！盘点 2025 年最离谱的 AI 工具，看完我沉默了',
    durationSec: 72,
    author: 'AI前沿观察'
  }), settings());
  assert.equal(slop.severity, 'high');
  assert.equal(slop.category, 'ai');

  const course = Scoring.analyze(item({
    title: 'ChatGPT 从入门到精通：提示词工程完整课程',
    durationSec: 3320,
    author: 'AI学习实验室'
  }), settings());
  assert.equal(course.severity, 'none');
  assert.equal(Scoring.effectiveAction(course, settings()), 'ok');
});

test('营销号话术与影视解说模板', () => {
  const a = Scoring.analyze(item({ title: '每天一个认知觉醒：普通人翻身的底层逻辑', durationSec: 58 }), settings());
  assert.equal(a.severity, 'high');
  assert.equal(a.category, 'slop');

  const b = Scoring.analyze(item({ title: '注意看，这个男人叫小帅，一口气看完人类简史', durationSec: 200 }), settings());
  assert.equal(b.severity, 'high');
  assert.ok(b.labels.some(l => l.id === 'slop'));
});

test('知识向长视频不被误伤', () => {
  const d = Scoring.analyze(item({
    title: '【MIT公开课】线性代数 第一讲：方程组的几何解释',
    durationSec: 2352,
    author: 'MIT OpenCourseWare'
  }), settings());
  assert.equal(d.severity, 'none');
  assert.ok(d.quality >= 80);
});

test('白名单与自定义屏蔽词', () => {
  const s = settings({ whitelist: { names: ['AI前沿观察'], mids: [] } });
  const d = Scoring.analyze(item({
    title: 'AI 生成！盘点最离谱的 AI 工具',
    durationSec: 72,
    author: 'AI前沿观察'
  }), s);
  assert.equal(d.severity, 'none');
  assert.equal(d.category, 'whitelisted');

  const s2 = settings({ customBlock: ['原神'] });
  const d2 = Scoring.analyze(item({ title: '原神 版本前瞻', durationSec: 600 }), s2);
  assert.equal(d2.category, 'custom');
  assert.equal(d2.severity, 'high');

  const s3 = settings({ customBlock: ['/^(原神|崩坏)\\s*[0-9.]*/i'] });
  const d3 = Scoring.analyze(item({ title: '崩坏 3.2 版本前瞻', durationSec: 600 }), s3);
  assert.equal(d3.category, 'custom');
  assert.equal(d3.severity, 'high');

  const s4 = settings({ customBlock: ['/[/'] });
  const d4 = Scoring.analyze(item({ title: '普通视频', durationSec: 600 }), s4);
  assert.notEqual(d4.category, 'custom');
});

test('显示方式与专注模式', () => {
  const high = { severity: 'high', action: 'blur' };
  const medium = { severity: 'medium', action: 'dim' };
  const low = { severity: 'low', action: 'badge' };
  assert.equal(Scoring.effectiveAction(high, settings({ mode: 'blur' })), 'blur');
  assert.equal(Scoring.effectiveAction(high, settings({ mode: 'dim' })), 'dim');
  assert.equal(Scoring.effectiveAction(high, settings({ mode: 'hide' })), 'hide');
  assert.equal(Scoring.effectiveAction(medium, settings({ mode: 'blur' })), 'dim');
  assert.equal(Scoring.effectiveAction(low, settings({ mode: 'hide' })), 'badge');

  const d = Scoring.analyze(item({ title: '随便聊聊', durationSec: 90 }), settings({ focusMode: true }));
  assert.equal(d.shortNonKnowledge, true);
});

test('选题提取：去掉标题党后保留关键词', () => {
  assert.match(Topic.fromTitle('【硬核科普】熵与信息论到底有多神？'), /信息论/);
  assert.match(Topic.fromTitle('注意看，这个男人叫小帅，一口气看完人类简史'), /人类简史/);
  assert.match(Topic.fromTitle('ChatGPT 从入门到精通：提示词工程完整课程'), /chatgpt|提示词/i);
  assert.ok(Topic.fromTitle('【4K】这个视频告诉你一切').length > 0);
});

test('同质选题聚类：4 条信息论 + 3 条量子力学', () => {
  const items = [
    { id: 'entropy1', title: '为什么熵增定律让人绝望？信息论视角下的宇宙终局', durationSec: 1112, quality: 80, views: 3200000, url: '' },
    { id: 'entropy2', title: '熵与信息论：从香农到热力学第二定律', durationSec: 2530, quality: 94, views: 5600000, url: '' },
    { id: 'entropy3', title: '信息论入门：熵、互信息与信道容量', durationSec: 3753, quality: 95, views: 1800000, url: '' },
    { id: 'entropy4', title: '【硬核科普】信息熵到底是什么？一个视频讲透', durationSec: 725, quality: 85, views: 900000, url: '' },
    { id: 'quantum1', title: '量子力学到底有多诡异？', durationSec: 1330, quality: 90, views: 4100000, url: '' },
    { id: 'quantum2', title: '量子力学入门：波函数与薛定谔方程', durationSec: 2100, quality: 92, views: 2300000, url: '' },
    { id: 'quantum3', title: '量子纠缠的本质，一个视频讲清楚', durationSec: 4200, quality: 96, views: 5200000, url: '' },
    { id: 'other1', title: '这也太离谱了', durationSec: 120, quality: 40, views: 1000, url: '' },
    { id: 'other1b', title: '离谱操作合集', durationSec: 120, quality: 40, views: 1000, url: '' },
    { id: 'other1c', title: '真的太离谱了', durationSec: 120, quality: 40, views: 1000, url: '' },
    { id: 'other2', title: '猫咪的一百种睡姿', durationSec: 180, quality: 40, views: 2000, url: '' }
  ];
  const result = Cluster.analyze(items, { minSize: 3 });
  assert.equal(result.groups.length, 2);
  const entropy = result.groups.find(g => g.itemIds.includes('entropy3'));
  const quantum = result.groups.find(g => g.itemIds.includes('quantum3'));
  assert.ok(entropy, '应当找到信息论同题组');
  assert.ok(quantum, '应当找到量子力学同题组');
  assert.equal(entropy.size, 4);
  assert.equal(quantum.size, 3);
  assert.equal(entropy.bestId, 'entropy3');
  assert.equal(quantum.bestId, 'quantum3');
  assert.equal(result.byId.entropy1.isBest, false);
  assert.equal(result.byId.entropy3.isBest, true);
});

test('考古：URL 构造、年代/时长过滤与排序', () => {
  const apiUrl = Archaeology.buildApiUrl({
    keyword: '信息论',
    page: 2,
    beginSec: 946684800,
    endSec: 1609430400
  });
  assert.match(apiUrl, /^https:\/\/api\.bilibili\.com\/x\/web-interface\/search\/type\?/);
  assert.match(apiUrl, /keyword=%E4%BF%A1%E6%81%AF%E8%AE%BA/);
  assert.match(apiUrl, /pubtime_end_s=1609430400/);

  const webUrl = Archaeology.buildWebUrl({ keyword: '熵', beginSec: 1, endSec: 2 });
  assert.match(webUrl, /^https:\/\/search\.bilibili\.com\/all\?/);

  const now = Date.UTC(2026, 0, 1);
  const ranked = Archaeology.rank([
    { bvid: 'BVold', title: '信息论 公开课 第一讲 熵与互信息', durationSec: 3600, views: 1000000, favorites: 80000, likes: 40000, pubdate: 1451606400 },
    { bvid: 'BVnew', title: '信息论 2024 最新讲解', durationSec: 3600, views: 5000000, favorites: 200000, likes: 100000, pubdate: 1704067200 },
    { bvid: 'BVshort', title: '一分钟讲信息论', durationSec: 300, views: 1000000, favorites: 1000, likes: 1000, pubdate: 1451606400 },
    { bvid: 'BVold2', title: '信息熵的直观理解', durationSec: 1800, views: 100000, favorites: 3000, likes: 2000, pubdate: 1577836800 }
  ], { cutoffTs: 1609430400, minDuration: 600, now });

  assert.equal(ranked.items.length, 2);
  assert.equal(ranked.tooNew, 1);
  assert.equal(ranked.tooShort, 1);
  assert.equal(ranked.items[0].bvid, 'BVold');
  assert.ok(ranked.items[0].archScore >= ranked.items[1].archScore);
  assert.ok(ranked.items[0].archReasons.length >= 2);
});

test('配置归一化：阈值夹取、列表去重', () => {
  const s = Settings.normalize(Settings.merge(Settings.DEFAULT_SETTINGS, {
    thresholds: { shortMax: 999999, homogeneityMin: 1, blurStrength: 100 },
    whitelist: { names: ['A', 'A ', 'B'], mids: ['123', 'abc123'] },
    customBlock: [' 词 ', '词', '']
  }));
  assert.equal(s.thresholds.shortMax, 7200);
  assert.equal(s.thresholds.homogeneityMin, 2);
  assert.equal(s.thresholds.blurStrength, 20);
  assert.equal(JSON.stringify(s.whitelist.names), JSON.stringify(['A', 'B']));
  assert.equal(JSON.stringify(s.whitelist.mids), JSON.stringify(['123']));
  assert.equal(JSON.stringify(s.customBlock), JSON.stringify(['词']));
});
