import { readFileSync } from 'node:fs';
import vm from 'node:vm';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import test from 'node:test';
import assert from 'node:assert/strict';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const FILES = [
  'src/core/util.js',
  'src/core/keywords.js',
  'src/core/store.js',
  'src/core/domains.js',
  'src/core/settings.js',
  'src/core/topic.js',
  'src/core/profile.js',
  'src/core/scoring.js',
  'src/core/archaeology.js',
  'src/core/explore.js',
  'src/core/account.js'
];

const ctx = {
  console,
  URLSearchParams,
  URL,
  Date,
  Math,
  JSON,
  Number,
  String,
  Object,
  Array,
  Set,
  Map,
  RegExp,
  Promise,
  parseInt,
  parseFloat,
  isNaN,
  Intl,
  setTimeout,
  clearTimeout
};
ctx.globalThis = ctx;
vm.createContext(ctx);
for (const file of FILES) {
  vm.runInContext(readFileSync(path.join(ROOT, file), 'utf8'), ctx, { filename: file });
}
const BLF = ctx.BLF;
const { Domains, Profile, Explore, Settings, Store, Account, U } = BLF;
Store.isDemo = false;

function settings(overrides = {}) {
  return Settings.normalize(Settings.merge(Settings.DEFAULT_SETTINGS, overrides));
}

function item(overrides = {}) {
  return Object.assign({
    id: 'BVx',
    bvid: 'BVx',
    title: '线性代数 系统 公开课 矩阵与特征值',
    author: '老师',
    durationSec: 3600,
    views: 1000000,
    likes: 30000,
    favorites: 50000,
    danmaku: 1000,
    pubdate: 1580000000,
    description: '',
    tags: '',
    url: 'https://www.bilibili.com/video/BVx'
  }, overrides);
}

test('领域分类：数学/物理/计算机/设计/娱乐', () => {
  assert.equal(Domains.topDomain('线性代数 矩阵 特征值').id, 'math');
  assert.equal(Domains.topDomain('量子力学 薛定谔方程').id, 'physics');
  assert.equal(Domains.topDomain('Python 算法 数据结构').id, 'cs');
  const design = Domains.classify('游戏设计 交互设计');
  assert.ok(design.some(d => d.id === 'design'));
  assert.equal(Domains.topDomain('美食 探店 vlog').id, 'entertainment');
});

test('信息茧房指标：单一领域 vs 均衡分布', () => {
  const cocoon = Domains.diversity([
    '王者荣耀 五杀', '原神 抽卡', '游戏攻略', '电竞比赛',
    '游戏解说', '手游上分', '独立游戏推荐'
  ], 0.65);
  assert.equal(cocoon.classified, 7);
  assert.equal(cocoon.top.id, 'gaming');
  assert.equal(cocoon.isCocoon, true);
  assert.ok(cocoon.topShare >= 0.9);

  const mixed = Domains.diversity([
    '线性代数 矩阵', '微积分 极限', '概率论 统计',
    'Python 算法', '操作系统 原理', '数据库 索引',
    '历史 文明', '哲学 入门'
  ], 0.65);
  assert.ok(mixed.classified >= 7);
  assert.equal(mixed.isCocoon, false);
  assert.ok(mixed.entropy > 0.5);
});

test('画像聚合：领域、主题、关注分组、不保存原始列表', () => {
  const s = settings({
    explore: { followPages: 1, favFolders: 2 }
  });
  const profile = Profile.aggregate({
    nav: { mid: 123, uname: 'tester' },
    followings: [
      { uname: '李永乐老师', sign: '物理与数学科普', tag: '学习' },
      { uname: '某游戏主播', sign: '王者荣耀 上分', tag: '游戏' }
    ],
    folders: [
      {
        id: 1,
        title: '数学与信息论',
        items: [
          { title: '线性代数 系统讲解', intro: '矩阵' },
          { title: '信息论 熵与互信息', intro: '' }
        ]
      }
    ],
    history: [
      { title: '量子力学 公开课', author_name: '老师' }
    ]
  }, s);

  assert.equal(profile.mid, 123);
  assert.equal(profile.sources.followings, 2);
  assert.equal(profile.sources.favorites, 2);
  assert.ok(profile.domains.some(d => d.id === 'math'));
  assert.ok(profile.domains.some(d => d.id === 'physics'));
  assert.ok(profile.topTopics.includes('信息论') || profile.topTopics.some(t => t.indexOf('信息论') !== -1));
  assert.ok(profile.deepen.length >= 1);
  assert.ok(profile.broaden.length >= 1);
  assert.equal(profile.manual, false);
  assert.ok(profile.followGroups.some(g => g.name === '学习'));

  const saved = JSON.stringify(profile);
  assert.equal(saved.indexOf('李永乐老师'), -1);
  assert.equal(saved.indexOf('某游戏主播'), -1);
  assert.equal(saved.indexOf('线性代数 系统讲解'), -1);
  assert.equal(saved.indexOf('量子力学 公开课'), -1);
});

test('画像校准：本页偏多/偏少与盲区', () => {
  const feed = Domains.diversity([
    '王者荣耀 五杀', '原神 抽卡', '游戏攻略', '电竞比赛',
    '游戏解说', '手游上分', '独立游戏推荐'
  ], 0.65);
  const profileDomains = [
    { id: 'math', label: '数学', share: 0.34 },
    { id: 'cs', label: '计算机', share: 0.26 },
    { id: 'gaming', label: '游戏', share: 0.17 }
  ];
  const cal = Domains.compareProfile(profileDomains, feed, 2);
  assert.ok(cal.over.some(d => d.id === 'gaming' && d.delta > 0.2));
  assert.ok(cal.under.some(d => d.id === 'math' && d.delta < -0.2));
  assert.ok(cal.blindspots.length >= 1);
});

test('手动兴趣画像与稳定 hash', () => {
  const s = settings({ explore: { deepen: ['math', 'cs'], broaden: ['biology'] } });
  const p = Profile.fromSettings(s);
  assert.equal(p.manual, true);
  assert.deepEqual(JSON.parse(JSON.stringify(p.deepen)), ['math', 'cs']);
  assert.equal(p.broaden.length, 1);
  assert.equal(Profile.hash(p), Profile.hash(Profile.fromSettings(s)));
});

test('探索查询生成：深耕/拓界/经典，最多 5 条', () => {
  const s = settings({ explore: { deepen: ['math'], broaden: ['biology'] } });
  const p = Profile.aggregate({
    nav: { mid: 1, uname: 'u' },
    followings: [{ uname: 'UP', sign: '数学 信息论', tag: '学习' }],
    folders: [{ id: 1, title: '数学', items: [{ title: '信息论 熵' }] }],
    history: []
  }, s);
  p.topTopics = ['信息论'];
  const queries = Explore.buildQueries(p, s);
  assert.ok(queries.length >= 3 && queries.length <= 5);
  assert.ok(queries.some(q => q.lane === 'deepen'));
  assert.ok(queries.some(q => q.lane === 'broaden'));
  assert.ok(queries.some(q => q.lane === 'classic' && q.endSec > 0 && q.beginSec > 0));
  assert.ok(queries.some(q => q.keyword.indexOf('信息论') !== -1));
});

test('探索排序：目标领域优先，过滤短视频与高优先级游戏', () => {
  const s = settings({ explore: { deepen: ['math'], broaden: ['biology'], resultsPerLane: 5 } });
  const profile = {
    domains: [{ id: 'math', label: '数学', share: 0.5 }],
    topTopics: ['信息论'],
    deepen: ['math'],
    broaden: ['biology']
  };
  const items = [
    item({ bvid: 'mathLong', title: '线性代数 公开课 矩阵与特征值', durationSec: 3600 }),
    item({ bvid: 'bioLong', title: '生物学 通识 入门 细胞与基因', durationSec: 1800, url: 'https://www.bilibili.com/video/BVbio' }),
    item({ bvid: 'gamingShort', title: '王者荣耀 五杀 高能', durationSec: 120 }),
    item({ bvid: 'mathShort', title: '数学 速成', durationSec: 300 }),
    item({ bvid: 'mathK12', title: '全120集 八年级上册数学 名师讲解', durationSec: 3600 }),
    item({ bvid: 'bioKids', title: '儿童科普启蒙纪录片：微生物', durationSec: 1800 }),
    item({ bvid: 'bioShort', title: '生物 一分钟', durationSec: 180 })
  ];
  const deep = Explore.rankLane(items, 'deepen', ['math'], profile, s, 5);
  assert.equal(deep.length, 1);
  assert.equal(deep[0].bvid, 'mathLong');
  assert.ok(deep[0].exploreReasons.some(r => r.indexOf('深耕') !== -1));

  const broad = Explore.rankLane(items, 'broaden', ['biology'], profile, s, 5);
  assert.equal(broad.length, 1);
  assert.equal(broad[0].bvid, 'bioLong');
  assert.ok(broad[0].exploreReasons.some(r => r.indexOf('拓界') !== -1));
});

test('探索缓存过滤：排除当前页已出现视频', () => {
  const lanes = {
    deepen: [{ bvid: 'a' }, { bvid: 'b' }],
    broaden: [{ bvid: 'c' }],
    classic: []
  };
  const filtered = Explore.filterLanes(lanes, ['a', 'c']);
  assert.deepEqual(JSON.parse(JSON.stringify(filtered.deepen)), [{ bvid: 'b' }]);
  assert.equal(filtered.broaden.length, 0);
});

test('账号同步：登录态、关注、收藏、画像落盘（mock API）', async () => {
  await Store.remove('blfProfile');
  const calls = [];
  BLF.Api = {
    getJson: async function (url) {
      calls.push(url);
      if (url.indexOf('/x/web-interface/nav') !== -1) {
        return { isLogin: true, mid: 456, uname: '测试用户' };
      }
      if (url.indexOf('/x/relation/followings') !== -1) {
        return { list: [{ mid: 1, uname: '数学UP', sign: '线性代数 科普', tag: '学习' }] };
      }
      if (url.indexOf('/x/v3/fav/folder/created/list-all') !== -1) {
        return { list: [{ id: 9, title: '数学收藏', media_count: 1 }] };
      }
      if (url.indexOf('/x/v3/fav/resource/list') !== -1) {
        return { medias: [{ title: '信息论 熵', intro: '互信息', duration: 3600, bvid: 'BVfav' }] };
      }
      if (url.indexOf('/x/web-interface/history/cursor') !== -1) {
        return { list: [{ title: '量子力学 公开课', author_name: '老师' }] };
      }
      throw new Error('unexpected url ' + url);
    }
  };
  const s = settings({
    explore: { followPages: 1, favFolders: 1, useHistory: true, deepen: [], broaden: [] }
  });
  const p = await Account.sync(s, {});
  assert.equal(p.mid, 456);
  assert.equal(p.sources.followings, 1);
  assert.equal(p.sources.favorites, 1);
  assert.equal(p.sources.history, 1);
  assert.ok(p.domains.some(d => d.id === 'math'));
  assert.ok(calls.some(u => u.indexOf('/x/relation/followings') !== -1));
  const saved = await Store.get('blfProfile', null);
  assert.ok(saved && saved.mid === 456);
});

test('账号同步：未登录给出明确错误', async () => {
  BLF.Api = {
    getJson: async function () {
      const err = new Error('需要先登录 B 站，才能读取账号画像');
      err.code = 'login-required';
      throw err;
    }
  };
  const s = settings();
  await assert.rejects(() => Account.sync(s, {}), /登录 B 站/);
});
