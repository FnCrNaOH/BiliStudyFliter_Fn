import { readFileSync } from 'node:fs';
import vm from 'node:vm';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import test from 'node:test';
import assert from 'node:assert/strict';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const FILES = [
  'src/core/util.js',
  'src/core/keywords.js',
  'src/core/store.js',
  'src/core/domains.js',
  'src/core/settings.js',
  'src/core/topic.js',
  'src/core/scoring.js',
  'src/core/archaeology.js',
  'src/core/api.js',
  'src/core/study.js'
];

const ctx = {
  console,
  URLSearchParams,
  URL,
  Date,
  Math,
  JSON,
  Number,
  String,
  Object,
  Array,
  Set,
  Map,
  RegExp,
  Promise,
  parseInt,
  parseFloat,
  isNaN,
  Intl,
  setTimeout,
  clearTimeout
};
ctx.globalThis = ctx;
vm.createContext(ctx);
for (const f of FILES) {
  vm.runInContext(readFileSync(path.join(ROOT, f), 'utf8'), ctx, { filename: f });
}
const { BLF } = ctx;
BLF.Store.isDemo = false;

function settings() {
  return BLF.Settings.normalize({
    studyFeed: { topics: ['cs'], minDuration: 600, poolSize: 8 }
  });
}

function item(over = {}) {
  return Object.assign({
    bvid: 'BV1Study1', title: '计算机科学导论：从二进制到操作系统',
    author: 'Crash Course', durationSec: 2400, views: 800000,
    favorites: 60000, likes: 42000, pubdate: 1680000000,
    tags: '计算机 科普', typename: '科学科普', description: '',
    cover: '//i0.hdslb.com/a.jpg'
  }, over);
}

test('科技领域白名单', () => {
  assert.deepEqual(Array.from(BLF.StudyFeed.validTopics(['cs', 'ee', 'nope'])), ['cs', 'ee']);
});

test('科技长视频打分：长内容加分，短视频/K12 过滤', () => {
  const s = settings();
  const good = BLF.StudyFeed.scoreItem(item(), BLF.StudyFeed.BY_ID.cs, s);
  assert.ok(good);
  assert.equal(good.topic, 'cs');
  assert.ok(good.score >= 60);

  assert.equal(BLF.StudyFeed.scoreItem(item({ durationSec: 120 }), BLF.StudyFeed.BY_ID.cs, s), null);
  assert.equal(BLF.StudyFeed.scoreItem(item({ title: '八年级上册 计算机基础 同步课程' }), BLF.StudyFeed.BY_ID.cs, s), null);
});

test('科技池抓取、去重、缓存', async () => {
  let cache = null;
  BLF.Store = {
    isDemo: false,
    get: async function (key) { return key === 'blfStudyPool' ? cache : null; },
    set: async function (key, value) { if (key === 'blfStudyPool') cache = value; },
    remove: async function () { cache = null; }
  };
  BLF.Api = {
    makeError: function (message, code) { const e = new Error(message); e.code = code; return e; },
    searchPage: async function () {
      return {
        result: [
          { bvid: 'BV1Study1', title: '计算机科学导论：从二进制到操作系统', author: 'Crash Course', duration: '40:00', play: 800000, favorites: 60000, like: 42000, pubdate: 1680000000, pic: '//i0.hdslb.com/a.jpg', tag: '计算机 科普', typename: '科学科普', arcurl: 'https://www.bilibili.com/video/BV1Study1' },
          { bvid: 'BV1Study1', title: '计算机科学导论（重复）', author: 'Crash Course', duration: '40:00', play: 800000, favorites: 60000, like: 42000, pubdate: 1680000000, pic: '//i0.hdslb.com/a.jpg', tag: '计算机 科普', typename: '科学科普', arcurl: 'https://www.bilibili.com/video/BV1Study1' },
          { bvid: 'BV1Study2', title: '计算机科学导论：从二进制到操作系统（续）', author: 'Crash Course', duration: '45:00', play: 500000, favorites: 30000, like: 20000, pubdate: 1680000000, pic: '//i0.hdslb.com/b.jpg', tag: '计算机 科普', typename: '科学科普', arcurl: 'https://www.bilibili.com/video/BV1Study2' }
        ]
      };
    }
  };
  BLF.Archaeology.normalizeItem = function (raw) {
    return {
      bvid: raw.bvid, title: raw.title, author: raw.author, durationSec: 2400,
      views: raw.play, favorites: raw.favorites, likes: raw.like,
      pubdate: raw.pubdate, cover: raw.pic, tags: raw.tag, typename: raw.typename,
      description: '', url: raw.arcurl
    };
  };
  const s = settings();
  const first = await BLF.StudyFeed.getPool(s, {});
  assert.equal(first.cached, false);
  assert.equal(first.items.length, 2);
  assert.equal(new Set(first.items.map(i => i.bvid)).size, 2);
  assert.ok(cache && cache.items.length === 2);

  const second = await BLF.StudyFeed.getPool(s, {});
  assert.equal(second.cached, true);
  assert.equal(second.items.length, 2);
});
